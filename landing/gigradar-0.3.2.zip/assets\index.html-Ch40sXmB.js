import{S as v,g as L,o as T,s as q,a as U}from"./share-modal-DFpAcbF4.js";import{h as K,g as Q,t as a,s as V,a as G,D as R}from"./metrics-CxlbnKT_.js";import{P as W,g as J}from"./extpay-core-6aOhiK5e.js";import"./extpay-vendor-CwkHEbPA.js";const f=document.querySelector("#app"),A=`
  <svg viewBox="0 0 24 24" fill="none" class="h-6 w-6 flex-none" aria-hidden="true">
    <rect x="1.25" y="1.25" width="21.5" height="21.5" rx="6.5" fill="url(#gr-logo-g)" stroke="#10B981" stroke-opacity=".35"/>
    <path d="M13.4 4.8 7.2 12.9h3.6l-1.1 6.3 6.9-8.7h-3.9l.7-5.7z" fill="#0D0F12"/>
    <defs>
      <linearGradient id="gr-logo-g" x1="2" y1="2" x2="22" y2="22">
        <stop stop-color="#34D399"/><stop offset="1" stop-color="#059669"/>
      </linearGradient>
    </defs>
  </svg>`,E=`
  <svg viewBox="0 0 16 16" fill="none" class="h-4 w-4 flex-none" aria-hidden="true">
    <circle cx="8" cy="8" r="7" class="fill-brand-500/20"/>
    <path d="M5 8.2l2.1 2.1L11.2 6" stroke="#10B981" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`,N=`
  <svg viewBox="0 0 16 16" fill="none" class="h-4 w-4 flex-none" aria-hidden="true">
    <rect x="3.2" y="7" width="9.6" height="6.6" rx="1.8" class="stroke-amber-300/80 fill-amber-300/10" stroke-width="1.3"/>
    <path d="M5.4 7V5.4a2.6 2.6 0 015.2 0V7" class="stroke-amber-300/80" stroke-width="1.3" stroke-linecap="round"/>
    <circle cx="8" cy="10.3" r="1" class="fill-amber-300"/>
  </svg>`,B=`
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="h-3.5 w-3.5 flex-none" aria-hidden="true">
    <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>`;async function X(){var g;try{return(((g=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0])==null?void 0:g.url)||"").includes("upwork.com")}catch{return!1}}async function Y(){if(!f)return;const g=await K(),S=await Q();g?await h(S):C();function C(){var e;f&&(f.innerHTML=`
      <div class="relative overflow-hidden p-5 text-center animate-fade-up">
        <!-- Ambient radial glow -->
        <div class="pointer-events-none absolute -top-12 left-1/2 h-36 w-60 -translate-x-1/2 rounded-full bg-brand-500/20 blur-3xl"></div>

        <div class="relative mx-auto mb-3.5 flex h-14 w-14 items-center justify-center rounded-2xl border border-brand-500/40 bg-gradient-to-b from-brand-500/20 to-brand-500/5 shadow-[0_0_24px_rgba(16,185,129,0.3)]">
          ${A}
        </div>

        <h1 class="bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-base font-black tracking-tight text-transparent">
          ${a("onboarding_title","en")}
        </h1>
        <p class="mt-1 text-xs leading-relaxed text-slate-400 max-w-[280px] mx-auto">
          ${a("onboarding_subtitle","en")}
        </p>

        <div class="mt-4 flex flex-col gap-1.5 text-left max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
          ${v.map(s=>`
            <button data-set-lang="${s.code}"
              class="group relative flex items-center gap-3 overflow-hidden rounded-xl border border-white/5 bg-panel/80 p-2.5 text-left shadow-card transition-all duration-150 hover:border-brand-500/50 hover:bg-brand-500/[0.08] hover:shadow-[0_0_16px_rgba(16,185,129,0.15)] active:scale-[0.98]">
              <span class="flex-none select-none">${L(s.code)}</span>
              <div class="min-w-0 flex-1">
                <div class="flex items-center gap-1.5">
                  <span class="text-xs font-bold text-white group-hover:text-brand-300 transition-colors truncate">${s.nativeName}</span>
                  ${s.nativeName!==s.name?`<span class="text-[10px] text-slate-400 truncate">(${s.name})</span>`:""}
                </div>
                <span class="block text-[10px] font-medium text-slate-400 group-hover:text-slate-300 transition-colors truncate">${s.sublabel}</span>
              </div>
              <div class="flex h-6 w-6 flex-none items-center justify-center rounded-lg border border-white/10 bg-white/5 font-mono text-[10px] font-extrabold text-slate-300 group-hover:border-brand-400/50 group-hover:bg-brand-500/20 group-hover:text-brand-300 transition-all">
                ${s.code.toUpperCase()}
              </div>
            </button>
          `).join("")}
        </div>

        <div class="mt-4 flex items-center justify-center gap-1.5 text-[10px] font-medium text-slate-500">
          <svg viewBox="0 0 16 16" fill="none" class="h-3 w-3 text-brand-400" aria-hidden="true">
            <path d="M8 1.5l5.5 2v4.2c0 3.2-2.3 5.9-5.5 6.8-3.2-.9-5.5-3.6-5.5-6.8V3.5L8 1.5z" class="fill-brand-500/20" stroke="#10B981" stroke-width="1.3"/>
            <path d="M5.6 7.9l1.7 1.7 3.1-3.4" stroke="#34D399" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <span>${a("onboarding_local_note","en")} · <button id="onboarding-settings" type="button" class="underline hover:text-brand-300 transition-colors">${a("onboarding_change_settings","en")}</button></span>
        </div>
      </div>
    `,(e=document.getElementById("onboarding-settings"))==null||e.addEventListener("click",()=>{chrome.runtime.openOptionsPage()}),f.querySelectorAll("button[data-set-lang]").forEach(s=>{s.addEventListener("click",async()=>{const m=s.dataset.setLang;await V(m),h(m)})}))}async function h(e){var I,j,P,O;if(!f)return;const s=await X(),m=v.find(t=>t.code===e)||v[0];f.innerHTML=`
      <header class="flex h-13 items-center justify-between border-b border-edge/80 bg-gradient-to-b from-white/[.04] to-transparent px-4 animate-fade-up">
        <div class="flex items-center gap-2.5">
          ${A}
          <div class="flex flex-col">
            <span class="text-sm font-black tracking-tight text-white leading-none">GigRadar</span>
            <span class="text-[9.5px] font-medium text-mute tracking-tight mt-0.5">${a("client_inspector_sub",e)}</span>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <!-- Custom Modern Glassy Language Popover -->
          <div class="relative">
            <button id="lang-btn" type="button" aria-haspopup="true" aria-expanded="false"
              class="group flex items-center gap-1.5 rounded-full border border-edge bg-raised/90 py-1 pl-2 pr-2.5 text-[11px] font-bold text-slate-200 shadow-sm transition-all duration-150 hover:border-brand-500/60 hover:bg-raised hover:text-white active:scale-95">
              <span class="flex-none select-none">${L(m.code)}</span>
              <span class="font-mono text-[10px] font-extrabold uppercase tracking-wider text-brand-300">${m.code}</span>
              <svg id="lang-chevron" class="h-2.5 w-2.5 text-slate-400 transition-transform duration-200 group-hover:text-slate-200" fill="none" viewBox="0 0 10 6">
                <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </button>

            <!-- Custom In-Popup Dropdown Flyout -->
            <div id="lang-dropdown" class="hidden absolute right-0 top-full mt-2 w-56 rounded-2xl border border-white/10 bg-[#12161f] p-1.5 shadow-[0_12px_36px_rgba(0,0,0,0.85)] backdrop-blur-xl z-50 animate-fade-up">
              <div class="px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-white/5 mb-1">
                ${a("change_language",e)}
              </div>
              <div class="max-h-56 overflow-y-auto space-y-0.5 custom-scrollbar pr-0.5">
                ${v.map(t=>`
                  <button type="button" data-select-lang="${t.code}"
                    class="w-full flex items-center gap-2.5 rounded-xl px-2.5 py-1.5 text-left text-xs font-medium transition-all ${t.code===e?"bg-brand-500/20 text-white border border-brand-500/40 shadow-sm":"text-slate-300 hover:bg-white/5 hover:text-white border border-transparent"}">
                    <span class="flex-none select-none">${L(t.code)}</span>
                    <div class="min-w-0 flex-1">
                      <div class="flex items-center gap-1.5">
                        <span class="font-semibold text-white truncate">${t.nativeName}</span>
                        ${t.nativeName!==t.name?`<span class="text-[10px] text-slate-400 truncate font-normal">(${t.name})</span>`:""}
                      </div>
                    </div>
                    ${t.code===e?'<svg viewBox="0 0 16 16" fill="none" class="h-3.5 w-3.5 flex-none text-brand-400"><path d="M3.5 8.5L6.5 11.5L12.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>':""}
                  </button>
                `).join("")}
              </div>
            </div>
          </div>

          <!-- Quick Settings Gear Button in Header -->
          <button id="header-settings" type="button" title="${a("settings_title",e)}" aria-label="${a("settings_title",e)}"
            class="group flex h-7 w-7 items-center justify-center rounded-full border border-edge bg-raised/90 text-slate-300 shadow-sm transition-all duration-150 hover:border-brand-500/60 hover:bg-brand-500/15 hover:text-brand-300 active:scale-95">
            <span class="transition-transform duration-300 group-hover:rotate-45">${B}</span>
          </button>
        </div>
      </header>

      ${s?"":`
      <div id="upwork-cta-banner" class="mx-3.5 mt-2.5 flex items-center justify-between rounded-2xl border border-brand-500/35 bg-gradient-to-r from-brand-500/15 via-panel to-panel p-2.5 shadow-sm animate-fade-up">
        <div class="flex items-center gap-2">
          <div class="flex h-7 w-7 flex-none items-center justify-center rounded-xl bg-brand-500/20 border border-brand-400/30 text-brand-300">
            <svg viewBox="0 0 16 16" fill="none" class="h-3.5 w-3.5" aria-hidden="true">
              <path d="M6 3.5h7m0 0v7m0-7L3.5 13" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <div class="flex flex-col">
            <span class="text-xs font-bold text-white leading-tight">${a("ready_for_upwork",e)}</span>
            <span class="text-[10px] text-slate-400">${a("ready_for_upwork_desc",e)}</span>
          </div>
        </div>
        <button id="open-feed-btn" type="button" class="flex-none rounded-xl bg-brand-500 px-3 py-1.5 text-[11px] font-extrabold text-slate-950 shadow hover:bg-brand-400 active:scale-95 transition-all">
          ${a("open_feed_btn",e)}
        </button>
      </div>`}

      <section id="saved-card" class="relative overflow-hidden mx-3.5 mt-2.5 rounded-2xl border border-brand-500/30 bg-gradient-to-br from-[#10291f] via-panel to-panel p-3 shadow-card animate-fade-up">
        <span class="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-brand-400/50 to-transparent"></span>
        <div class="pointer-events-none absolute -right-6 -top-6 h-20 w-20 rounded-full bg-brand-500/15 blur-2xl"></div>

        <div class="flex items-center justify-between">
          <div class="flex items-center gap-1.5 text-[10px] font-extrabold uppercase tracking-widest text-slate-300">
            <svg viewBox="0 0 16 16" fill="none" class="h-3.5 w-3.5" aria-hidden="true">
              <path d="M8 1.5l5.5 2v4.2c0 3.2-2.3 5.9-5.5 6.8-3.2-.9-5.5-3.6-5.5-6.8V3.5L8 1.5z" class="fill-brand-500/20" stroke="#10B981" stroke-width="1.3"/>
              <path d="M5.6 7.9l1.7 1.7 3.1-3.4" stroke="#34D399" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            ${a("connects_protected",e)}
          </div>
          <div class="flex items-center gap-1.5">
            <button id="share-savings-btn" type="button" class="inline-flex items-center gap-1 rounded-full border border-brand-400/40 bg-brand-500/20 px-2 py-0.5 text-[9px] font-bold text-brand-300 hover:bg-brand-500/30 active:scale-95 transition-all shadow-sm">
              <svg viewBox="0 0 16 16" fill="currentColor" class="h-2.5 w-2.5 flex-none text-brand-300" aria-hidden="true">
                <path d="M13.5 1a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 2.5a2.5 2.5 0 0 1 2.5-2.5 2.5 2.5 0 0 1 2.5 2.5c0 1.25-.92 2.3-2.12 2.47l-5.6 2.8a2.5 2.5 0 0 1 0 .46l5.6 2.8c1.2-.17 2.12.88 2.12 2.47a2.5 2.5 0 1 1-5 0c0-.16.02-.31.05-.46l-5.6-2.8A2.5 2.5 0 1 1 5.5 8c0 .16-.02.31-.05.46l5.6 2.8A2.5 2.5 0 0 1 11 13.5"/>
              </svg>
              <span>${a("share_savings_btn",e)}</span>
            </button>
            <span id="plan-pill" class="inline-flex items-center gap-1 rounded-full border border-brand-400/30 bg-brand-400/10 px-2 py-0.5 text-[9px] font-bold text-brand-300">
              <span class="h-1.5 w-1.5 rounded-full bg-brand-400 animate-pulse-dot"></span> LIVE
            </span>
          </div>
        </div>

        <div class="mt-2 flex items-baseline gap-2">
          <span id="saved-count" class="font-mono text-2xl font-black tracking-tight text-white tabular-nums">0</span>
          <span class="text-xs font-bold text-brand-400">Connects</span>
        </div>

        <div class="mt-1 flex items-center gap-1.5 flex-wrap">
          <span id="saved-usd" class="inline-flex items-center gap-1 rounded-md bg-white/5 border border-white/10 px-1.5 py-0.5 text-[10.5px] font-semibold text-emerald-300 tabular-nums">
            $0.00 ${a("saved_usd_label",e)}
          </span>
          <span id="saved-roi-pill" class="hidden items-center gap-1 rounded-md bg-emerald-500/15 border border-emerald-400/30 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300">
          </span>
          <span id="saved-desc" class="text-[10px] text-mute truncate">${a("skip_to_protect",e)}</span>
        </div>
      </section>

      <ul class="mt-2.5 space-y-1.5 px-3.5 animate-fade-up">
        <li class="flex items-center gap-2.5 rounded-xl border border-white/[0.04] bg-panel/60 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:bg-raised">
          ${E}
          <span class="flex-1">${a("feat_score",e)}</span>
          <span class="rounded bg-brand-500/10 px-1.5 py-0.5 font-mono text-[9px] font-bold text-brand-300">0-100</span>
        </li>
        <li class="flex items-center gap-2.5 rounded-xl border border-white/[0.04] bg-panel/60 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:bg-raised">
          ${E}
          <span class="flex-1">${a("feat_warnings",e)}</span>
          <span class="rounded bg-brand-500/10 px-1.5 py-0.5 font-mono text-[9px] font-bold text-brand-300">${a("connects_saved_active",e)}</span>
        </li>
        <li data-pro-feature class="flex items-center gap-2.5 rounded-xl border border-amber-400/20 bg-amber-400/[0.04] px-3 py-1.5 text-xs font-medium transition-colors hover:bg-amber-400/[0.08]">
          ${N}
          <span data-gradient class="flex-1 bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 bg-clip-text font-semibold text-transparent">${a("feat_name",e)}</span>
          <span data-pro-tag class="rounded bg-amber-400/20 px-1.5 py-0.5 text-[8.5px] font-black uppercase tracking-wider text-amber-300 border border-amber-400/30">PRO</span>
        </li>
        <li data-pro-feature class="flex items-center gap-2.5 rounded-xl border border-amber-400/20 bg-amber-400/[0.04] px-3 py-1.5 text-xs font-medium transition-colors hover:bg-amber-400/[0.08]">
          ${N}
          <span data-gradient class="flex-1 bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 bg-clip-text font-semibold text-transparent">${a("feat_hook",e)}</span>
          <span data-pro-tag class="rounded bg-amber-400/20 px-1.5 py-0.5 text-[8.5px] font-black uppercase tracking-wider text-amber-300 border border-amber-400/30">PRO</span>
        </li>
      </ul>

      <div class="mt-2.5 space-y-1.5 px-3.5 animate-fade-up">
        <button id="upgrade"
          class="group relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 py-2.5 text-xs font-black tracking-tight text-slate-950 shadow-[0_0_24px_rgba(16,185,129,0.35)] transition-all duration-200 hover:shadow-[0_0_32px_rgba(16,185,129,0.55)] hover:scale-[1.01] active:scale-[0.98]">
          <span class="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent animate-shimmer"></span>
          <span class="absolute inset-x-0 top-0 h-px bg-white/70"></span>
          <div class="relative flex items-center justify-center gap-1.5">
            <svg viewBox="0 0 16 16" fill="currentColor" class="h-4 w-4 flex-none text-slate-950">
              <path d="M9.5 1.5L3.5 9h4l-1 5.5 6-7.5h-4l1-5.5z"/>
            </svg>
            <span>${a("get_pro",e)} — ${W} ${a("early_bird",e)}</span>
          </div>
        </button>

        <p id="cta-subtext" class="text-center text-[10px] font-medium text-slate-400">
          ${a("cta_guarantee",e)}
        </p>

        <p id="status-note" class="text-center text-[9.5px] font-medium text-slate-500">
          ${a("pro_price_note",e)}
        </p>

        <button id="pro-active" hidden
          class="w-full rounded-xl border border-amber-400/40 bg-amber-400/10 py-2 text-xs font-extrabold text-amber-300 shadow-[0_0_20px_rgba(251,191,36,0.2)] transition-all hover:bg-amber-400/20 active:scale-[0.99]">
          ★ ${a("pro_active",e)}
        </button>

        <button id="open-settings"
          class="w-full flex items-center justify-center gap-2 rounded-xl border border-edge bg-raised/80 py-2 text-xs font-semibold text-slate-300 shadow-sm transition-colors hover:border-brand-500/50 hover:bg-raised hover:text-white active:scale-[0.99]">
          ${B}
          <span>${a("open_settings",e)}</span>
        </button>
      </div>

      <footer class="mt-2.5 flex items-center justify-between border-t border-edge/80 bg-white/[0.01] px-4 py-2 text-[11px] text-mute">
        <a id="footer-settings" href="#" class="group flex items-center gap-1.5 rounded-lg px-1.5 py-0.5 text-slate-400 transition-colors hover:text-brand-300 hover:bg-white/5">
          <span class="text-slate-400 group-hover:text-brand-300 transition-colors">${B}</span>
          <span>${a("settings_byok",e)}</span>
        </a>
        <div class="flex items-center gap-2">
          <span class="inline-flex items-center gap-1 text-[10px] ${s?"text-brand-400":"text-slate-400"} font-medium">
            <span class="h-1.5 w-1.5 rounded-full ${s?"bg-brand-400 animate-pulse-dot":"bg-slate-500"}"></span>
            ${s?a("active_on_upwork",e):a("ready_for_upwork",e)}
          </span>
          <span id="version" class="font-mono text-[10.5px] text-slate-500 tabular-nums"></span>
        </div>
      </footer>
    `;const c=document.getElementById("plan-pill"),p=document.getElementById("upgrade"),w=document.getElementById("pro-active"),b=document.getElementById("open-settings"),x=document.getElementById("cta-subtext"),y=document.getElementById("lang-btn"),n=document.getElementById("lang-dropdown"),d=document.getElementById("lang-chevron");y==null||y.addEventListener("click",t=>{t.stopPropagation();const r=n==null?void 0:n.classList.toggle("hidden");d==null||d.classList.toggle("rotate-180",!r)}),document.addEventListener("click",t=>{!(n!=null&&n.classList.contains("hidden"))&&!(n!=null&&n.contains(t.target))&&(n==null||n.classList.add("hidden"),d==null||d.classList.remove("rotate-180"))}),document.addEventListener("keydown",t=>{t.key==="Escape"&&!(n!=null&&n.classList.contains("hidden"))&&(n==null||n.classList.add("hidden"),d==null||d.classList.remove("rotate-180"))}),n==null||n.querySelectorAll("button[data-select-lang]").forEach(t=>{t.addEventListener("click",async r=>{r.stopPropagation();const o=t.dataset.selectLang;o&&o!==e?(await V(o),h(o)):(n==null||n.classList.add("hidden"),d==null||d.classList.remove("rotate-180"))})});const l=document.getElementById("status-note"),M=document.getElementById("version");M&&(M.textContent=`v${chrome.runtime.getManifest().version}`),(async()=>{const t=await G(),r=document.getElementById("saved-count"),o=document.getElementById("saved-usd"),i=document.getElementById("saved-roi-pill"),k=document.getElementById("saved-desc");if(r&&o&&k){r.textContent=String(t);const u=t*R;if(t>0){if(o.textContent=`~$${u.toFixed(2)} ${a("saved_usd_label",e)}`,k.textContent=a("connects_saved_sub",e),i)if(i.classList.remove("hidden"),i.classList.add("inline-flex"),u>=9.99){const $=(u/9.99).toFixed(1);i.textContent=`⚡ ${$}x ${a("roi_pro_label",e)}`}else{const $=Math.round(u/9.99*100);i.textContent=`⚡ ${$}% ${a("roi_of_pro_label",e)}`}x&&u>=9.99&&(x.textContent=`⚡ ~$${u.toFixed(2)} ${a("saved_usd_label",e)} — ${a("pro_paid_itself",e)}`)}else o.textContent=`$0.00 ${a("saved_usd_label",e)}`,k.textContent=a("skip_to_protect",e),i&&(i.classList.add("hidden"),i.classList.remove("inline-flex"))}})();function F(){document.querySelectorAll("li[data-pro-feature]").forEach(t=>{t.classList.remove("border-amber-400/20","bg-amber-400/[0.04]"),t.classList.add("border-white/[0.04]","bg-panel/60","text-slate-200");const r=t.firstElementChild;r&&(r.outerHTML=E);const o=t.querySelector("[data-pro-tag]");o&&o.remove();const i=t.querySelector("[data-gradient]");i&&(i.className="flex-1 text-slate-200 font-medium")})}async function z(){let t;try{t=await q()}catch{t=await J()}!p||!w||!b||(t?(c&&(c.className="inline-flex items-center gap-1 rounded-full border border-amber-400/50 bg-amber-400/10 px-2 py-0.5 text-[9px] font-black tracking-wider text-amber-300 shadow-[0_0_12px_rgba(251,191,36,0.25)]",c.innerHTML=`<span>★</span> <span>${a("pro",e)}</span>`),p.hidden=!0,x&&(x.hidden=!0),l&&(l.hidden=!0),w.hidden=!1,b.hidden=!1,F()):(c&&(c.className="inline-flex items-center gap-1 rounded-full border border-brand-400/30 bg-brand-400/10 px-2 py-0.5 text-[9px] font-bold text-brand-300",c.innerHTML=`
            <span class="h-1.5 w-1.5 rounded-full bg-brand-400 animate-pulse-dot"></span> LIVE`),p.hidden=!1,x&&(x.hidden=!1),l&&(l.textContent=a("pro_price_note",e),l.hidden=!1),w.hidden=!0,b.hidden=!1))}function H(){U()||l&&(l.textContent="Payment window unavailable — verify the ExtensionPay extension ID in src/monetization/extpay.ts.",l.hidden=!1)}const _=t=>{t&&t.preventDefault(),chrome.runtime.openOptionsPage()};p==null||p.addEventListener("click",H),b==null||b.addEventListener("click",_),(I=document.getElementById("header-settings"))==null||I.addEventListener("click",_),(j=document.getElementById("footer-settings"))==null||j.addEventListener("click",_),(P=document.getElementById("open-feed-btn"))==null||P.addEventListener("click",()=>{chrome.tabs.create({url:"https://www.upwork.com/nx/search/jobs/"})}),(O=document.getElementById("share-savings-btn"))==null||O.addEventListener("click",async()=>{const t=await G(),r=t*R,o=r>=9.99?(r/9.99).toFixed(1):void 0;T({connectsSaved:t,dollarsSaved:r,proRoiMultiplier:o,locale:e},e)}),z()}}Y();
