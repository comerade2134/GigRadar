import{Q as Ct,q as St,S as we,k as Et,p as $t,b as Ye,x as At,g as Ft,R as It,l as _t,m as Tt,T as Lt,e as Rt,f as Dt,j as ge,i as Re,h as Q,U as jt,I as zt,t as Pt,H as Mt,V as De,W as je,n as We,X as be,o as ze,Y as ie,Z as ve,_ as Ze,$ as W,a0 as ke,a1 as Je,a2 as Bt,a3 as Ht,a4 as Nt,a5 as qt,a6 as Ut}from"./bid-intelligence-C4nmXGvU.js";import{g as Ot,P as Gt,e as M}from"./extpay-core-6aOhiK5e.js";import{t as f,g as Xe,b as Qe,a as Vt,D as Kt,c as Yt,C as Wt}from"./metrics-CxlbnKT_.js";import{g as Zt,a as Jt,i as et,s as me}from"./proposal-autofill-5UUXaOwO.js";const Xt=[{category:"telegram",regex:/\b(?:t\.me\/[A-Za-z0-9_]{3,}|telegram(?:\.me)?\/[A-Za-z0-9_]{3,}|\btg\s*[:\-]\s*@\w[\w.]{2,}|(?:contact|message|reach|ping|dm)(?:\s+(?:me|us|out))?\s+(?:on|via|at|through)\s+telegram)\b/i},{category:"whatsapp",regex:/\b(?:wa\.me\/\d{6,}|whatsapp(?:\s+(?:me|us|at|on))?\s*(?:[:\-]|\+?\d{7,})|(?:contact|message|reach|ping)(?:\s+(?:me|us|out))?\s+(?:on|via|at|through)\s+whatsapp)\b/i},{category:"off-platform-email",regex:/\b[\w.%-]+\s*(?:@|\[\s*at\s*\]|\(\s*at\s*\)|\s+at\s+)\s*(?:gmail|yahoo|hotmail|outlook|protonmail|gmx|mail\.ru|yandex)\s*(?:\.|\[\s*dot\s*\]|\(\s*dot\s*\)|\s+dot\s+)\s*(?:com|net|org|ru|co)/i},{category:"plain-personal-email",regex:/\b[\w.%+-]+@(?:gmail|yahoo|hotmail|outlook|protonmail|gmx)\.(?:com|net|org|co)\b/i},{category:"free-work-request",regex:/\b(?:(?:free|unpaid)\s+(?:sample|trial|test\s*(?:task|project|work)?|spec\s*(?:test|work|project)?|mockup|demo)|(?:complete|do|deliver|submit)\s+(?:a\s+)?(?:free|unpaid)\s+(?:sample|test\s*task|spec)|(?:small|quick)\s+(?:unpaid\s+)?(?:test\s*task|spec\s*(?:work|task))\s+(?:first|before|to\s+start)|(?:paid\s+after|only\s+pay(?:ing)?\s+(?:after|once|if))[^.\n]{0,40}(?:approv|satisfi))/i},{category:"off-platform-steer",regex:/\b(?:(?:payment|pay|communicat\w*|chat|interview)\s+(?:outside|off)[\s-]*(?:of\s+)?upwork|(?:move|take|continue|migrate)\s+(?:this\s+|the\s+)?(?:conversation|communication|discussion|project|work|payment)s?\s+(?:outside|off)[\s-]*(?:of\s+)?upwork|(?:western\s+union|money\s?gram|crypto(?:currency)?|bitcoin|btc|usdt)\b)/i}];function Qt(e,t){const n=Math.max(0,t-48),o=Math.min(e.length,t+96),r=e.slice(n,o).replace(/\s+/g," ").trim();return r.length>120?`${r.slice(0,119)}…`:r}function Pe(e,t){const n=Math.max(0,t-50),o=e.slice(n,t),r=Math.max(o.lastIndexOf("."),o.lastIndexOf(`
`),o.lastIndexOf("!"),o.lastIndexOf("?")),a=r>=0?o.slice(r+1):o;return/\b(?:never|not|don't|do\s+not|won't|will\s+not|refuse|avoid|against|prohibit\w*|strictly\s+no|beware\s+of|scam\w*|report)\b/i.test(a)}function en(e,t){const n=Math.max(0,t-30),o=e.slice(n,t);return/\bfeel\s+free(?:\s+to)?\b/i.test(o)}function se(e){if(!e||e.length<8)return{matched:!1,matches:[]};const t=[];for(const n of Xt){const o=n.regex.exec(e);if(o){if(n.category==="off-platform-steer"&&Pe(e,o.index)||n.category==="free-work-request"&&(en(e,o.index)||Pe(e,o.index)))continue;t.push({category:n.category,snippet:Qt(e,o.index)})}}return{matched:t.length>0,matches:t}}const tn="🚨 Potential Scam / Off-Platform Trap — Risk of Account Ban",nn=["difficult","scope creep","refund","dispute","unreasonable","unresponsive","unfair","held payment"],on=.2,rn=2;function Ce(e){const t=e.map(a=>a.toLowerCase()).filter(a=>a.length>12);if(t.length<rn)return null;let n=0;const o=new Set;for(const a of t){const s=nn.find(i=>a.includes(i));s&&(n+=1,o.add(s))}if(n===0)return{level:"clean",negativeRatio:0,negativeCount:0,scanned:t.length,keywordsHit:[]};const r=n/t.length;return{level:r>on?"negative":"clean",negativeRatio:r,negativeCount:n,scanned:t.length,keywordsHit:[...o]}}const an="🚩 Client Temperament: High dispute rate in past contracts",ee={hireRate:.4,spend:.3,verified:.2,recency:.1},q=[[0,0],[1e3,.25],[1e4,.5],[5e4,.75],[1e5,1]];function sn(e){if(e<=0)return 0;if(e>=q[q.length-1][0])return 1;for(let t=1;t<q.length;t++){const[n,o]=q[t],[r,a]=q[t-1];if(e<=n)return a+(e-r)/(n-r)*(o-a)}return 1}function ln(e){if(e>=1e3){const t=e/1e3;return`$${t>=100?Math.round(t):t.toFixed(1)}k`}return`$${Math.round(e)}`}function cn(e){return e<=7?1:e<=30?.8:e<=90?.5:e<=180?.3:e<=365?.15:.05}function dn(e){return e<=1?"<1 day ago":e<30?`${Math.round(e)} days ago`:e<365?`${Math.round(e/30)} mo ago`:`${Math.round(e/365)} yr ago`}function le(e){const t=[{label:"Hire rate",weight:ee.hireRate,value:e.hireRatePct==null?null:Math.min(Math.max(e.hireRatePct,0),100)/100,display:e.hireRatePct==null?null:`${Math.round(e.hireRatePct)}%`},{label:"Total spend",weight:ee.spend,value:e.totalSpendUsd==null?null:sn(e.totalSpendUsd),display:e.totalSpendUsd==null?null:ln(e.totalSpendUsd)},{label:"Payment verified",weight:ee.verified,value:e.paymentVerified==null?null:e.paymentVerified?1:0,display:e.paymentVerified==null?null:e.paymentVerified?"Yes":"No"},{label:"Recent hiring",weight:ee.recency,value:e.daysSinceLastHire!=null?cn(e.daysSinceLastHire):e.totalSpendUsd===0&&e.hireRatePct===0?0:null,display:e.daysSinceLastHire!=null?dn(e.daysSinceLastHire):e.totalSpendUsd===0&&e.hireRatePct===0?"Never":null}],n=t.filter(i=>i.value!=null),o=n.reduce((i,c)=>i+c.weight,0),r=n.length>0&&o>0;let a=0;if(r){const i=n.reduce((c,u)=>c+u.weight*u.value,0);a=Math.round(i/o*100)}const s=r?a>=70?"HIGH":a>=40?"MEDIUM":"LOW":"LOW";return{score:a,tier:s,scored:r,components:t}}function ce(e){var i;const{signals:t,proposalCount:n}=e,o=[];e.scamMatched&&o.push({level:"danger",text:tn}),t.hireRatePct!=null&&t.hireRatePct<25&&o.push({level:"danger",text:`Low hire rate (${Math.round(t.hireRatePct)}%) — most proposals die here`}),t.paymentVerified===!1&&o.push({level:"danger",text:"Payment method unverified — payout risk"}),n!=null&&n>=50&&o.push({level:"warn",text:`${n>=9999?"50+":n} proposals — crowded bid pool`}),t.totalSpendUsd===0&&o.push({level:"warn",text:"Client has never paid on Upwork ($0 spent)"});const r=e.activity;(r==null?void 0:r.interviewingCount)!=null&&r.interviewingCount>=3?o.push({level:"danger",text:`⛔ Inactive / ${r.interviewingCount}+ Freelancers Already Interviewing`}):r!=null&&r.invitesSentCount!=null&&r.invitesSentCount>10&&r.interviewingCount===0&&o.push({level:"warn",text:"⚠️ Low Conversion / Mass Inviting"});const a=e.trueRate,s=e.budget;if((s==null?void 0:s.type)==="hourly"&&s.maxUsd!=null&&(a==null?void 0:a.medianHourlyUsd)!=null&&a.medianHourlyUsd>0){const c=s.maxUsd;c>=a.medianHourlyUsd*1.5&&o.push({level:"warn",text:`Listed budget inflated vs actual payouts (${Me(c)} listed vs ${Me(a.medianHourlyUsd)} median paid)`})}return((i=e.sentiment)==null?void 0:i.level)==="negative"&&o.push({level:"danger",text:an}),o}function Me(e){return`$${e%1===0?e.toFixed(0):e.toFixed(2)}/hr`}function tt(e,t,n=!1,o="en"){if(n)return{level:"danger",text:`🚨 ${f("alert_scam_warning",o)}`};const r=e.hireRatePct,a=e.totalSpendUsd;return r!=null&&r>70&&e.paymentVerified===!0&&(a??0)>1e4?{level:"high",text:`🔥 ${f("alert_high_intent",o)}`}:r!=null&&r<30?{level:"warn",text:`⚠️ ${f("alert_low_hire",o)} (${Math.round(r)}%)`}:t!=null&&t>=50&&(a??0)<1e4?{level:"danger",text:`⛔ ${f("alert_saturation",o)}`}:e.paymentVerified===!1?{level:"warn",text:`⚠️ ${f("alert_unverified",o)}`}:null}const pn=new Set(["great","good","best","fast","quick","easy","sir","madam","highly","really","very","truly","definitely","excellent","amazing","awesome","fantastic","wonderful","brilliant","perfect","professional","super","thanks","thank","hello","hi","hey","working","worked","would","will","such","this","that","job","project","client","freelancer","contractor","buyer","seller","customer","vendor","employer","employee","founder","owner","manager","upwork","communication","quality","skills","deadlines","work","time","day","week","month","year","recommendations","recommend","hiring","again","him","her","he","she","they","them","you","we","my","our","his","their","these","those","there","here","what","when","where","how","why","all","any","one","two","new","old","however","overall","also","everyone","everybody","anyone","anybody","somebody","someone","guys","folks","mate","bro","dude","friend","friends","team","group","staff","management","people","person","both","either","neither","much","many","lots","plenty","first","second","third","next","last","previous","final","please","kindly","cheers","regards","congrats","congratulations","kudos","india","usa","ukraine","pakistan","bangladesh","indonesia","philippines","nigeria","kenya","russia","brazil","mexico","canada","germany","france","spain","italy","poland","turkey","egypt","china","japan","vietnam","australia","america","britain","england","europe","inc","llc","ltd","company","studio","agency","solutions","technologies","technology","labs","media","digital","developer","designer","support","service","services","budget","payment","feedback","review","rating","experience","opportunity","position","role","task","contract","interview","meeting","deadline","requirement","feature","design","website","application","software","system","platform","business"]),_="([A-Z][a-z]{2,15})",un=[new RegExp(`\\b(?:[Tt]hanks|[Tt]hank\\s+you)[:,\\s]+${_}\\b`),new RegExp(`\\b${_}\\s+(?:was|is|has been)\\s+(?:a|an|such a|really|so|very)?\\s*(?:great|excellent|amazing|awesome|fantastic|wonderful|brilliant|super|professional|pleasure)`),new RegExp(`\\b[Ww]orking\\s+with\\s+${_}\\b`),new RegExp(`\\b[Ww]orked\\s+with\\s+${_}\\b`),new RegExp(`\\b(?:[Ww]ith|[Ff]or)\\s+${_}\\s+(?:i|we)\\s+(?:had|felt|always)`),new RegExp(`\\b[Hh]ighly\\s+recommend\\s+${_}\\b`),new RegExp(`\\b${_}\\s+(?:provided|gave|delivered|communicated|understood)`),new RegExp(`\\b${_}\\s+(?:was|is)\\s+(?:very|so|really|super)?\\s*(?:helpful|responsive|friendly|patient|supportive)`),new RegExp(`\\b${_}\\s+(?:is|was)\\s+(?:a|an|such a)\\s+(?:great|wonderful|excellent|amazing|awesome|fantastic|super)\\s+client`),new RegExp(`\\b[Gg]reat\\s+communication\\s+(?:with|from)\\s+${_}\\b`),new RegExp(`\\b[Tt]hanks[,:]?(?:\\s+go(?:es)?)?\\s+to\\s+${_}\\b`),new RegExp(`\\b[Kk]udos\\s+to\\s+${_}\\b`)];function gn(e){const t=new Map;for(const n of e){if(!n)continue;const o=new Map;for(const r of un){const a=r.exec(n);if(!a)continue;const s=a[1],i=s.toLowerCase();pn.has(i)||o.has(i)||o.set(i,s)}for(const[r,a]of o.entries()){const s=t.get(r);s?s.votes+=1:t.set(r,{display:a,votes:1})}}return t}function bn(e){return[...gn(e).values()].sort((t,n)=>n.votes-t.votes)}function de(e){const t=bn(e);if(t.length===0)return null;const n=t[0];let o=n.votes>=3?.9:n.votes===2?.72:.45;return t.length>1&&n.votes>t[1].votes&&(o=Math.min(.95,o+.05)),o<.6?null:{name:n.display,confidence:o,votes:n.votes,alternates:t.slice(1,4).map(r=>r.display)}}function Z(e,t,n){return(e==null?void 0:e.meta.jobId)===t?e:n}function mn(e,t,n){var d;const o=((d=t.nameGuess)==null?void 0:d.name)??(e==null?void 0:e.clientName)??null,r=t.meta.descriptionSnippet||(e==null?void 0:e.description)||"",a=t.meta.url||(e==null?void 0:e.url),s=t.budget??(e==null?void 0:e.budget)??null,i=t.signals.hireRatePct??(e==null?void 0:e.hireRatePct)??null,c=t.signals.totalSpendUsd??(e==null?void 0:e.totalSpendUsd)??null,u=t.signals.paymentVerified??(e==null?void 0:e.paymentVerified)??null,b=t.meta.proposalCount??(e==null?void 0:e.proposalCount)??null;return{title:t.meta.title||(e==null?void 0:e.title)||"Upwork job",...a?{url:a}:{},...r?{description:r}:{},clientName:o,budget:s,hireRatePct:i,totalSpendUsd:c,paymentVerified:u,proposalCount:b,savedAt:n}}const Be=new Set(["upwork.com","google.com","github.com","gitlab.com","loom.com","figma.com","slack.com","zoom.us","calendly.com","youtube.com","youtu.be","vimeo.com","bit.ly","tinyurl.com","dropbox.com","notion.so","notion.site","trello.com","asana.com","jira.com","atlassian.net","airtable.com","apple.com","microsoft.com","linkedin.com","twitter.com","x.com","instagram.com","facebook.com","medium.com","wikipedia.org","wordpress.org","w3.org"]),fn=[{name:"Shopify",pattern:/\bshopify\b/i},{name:"WordPress",pattern:/\bwordpress\b/i},{name:"WooCommerce",pattern:/\bwoocommerce\b/i},{name:"Webflow",pattern:/\bwebflow\b/i},{name:"Magento",pattern:/\bmagento\b/i},{name:"Wix",pattern:/\bwix\b/i},{name:"Squarespace",pattern:/\bsquarespace\b/i},{name:"BigCommerce",pattern:/\bbigcommerce\b/i},{name:"React",pattern:/\breact(?:\.js)?\b/i},{name:"Next.js",pattern:/\bnext(?:\.js)?\b/i},{name:"Vue.js",pattern:/\bvue(?:\.js)?\b/i},{name:"Nuxt.js",pattern:/\bnuxt(?:\.js)?\b/i},{name:"Angular",pattern:/\bangular\b/i},{name:"Svelte",pattern:/\bsvelte\b/i},{name:"Tailwind CSS",pattern:/\btailwind(?:css)?\b/i},{name:"TypeScript",pattern:/\btypescript\b/i},{name:"JavaScript",pattern:/\bjavascript\b/i},{name:"Node.js",pattern:/\bnode(?:\.js)?\b/i},{name:"Python",pattern:/\bpython\b/i},{name:"Django",pattern:/\bdjango\b/i},{name:"FastAPI",pattern:/\bfastapi\b/i},{name:"PHP",pattern:/\bphp\b/i},{name:"Laravel",pattern:/\blaravel\b/i},{name:"Ruby on Rails",pattern:/\b(?:ruby on rails|rails)\b/i},{name:"Go / Golang",pattern:/\b(?:golang|go language)\b/i},{name:"Java / Spring",pattern:/\b(?:spring boot|java spring)\b/i},{name:".NET / C#",pattern:/(?:^|[^\w])(?:c#|\.net|dotnet|csharp)(?:[^\w]|$)/i},{name:"C / C++",pattern:/(?:^|[^\w])(?:c\+\+|cpp|\bc language\b)(?:[^\w]|$)/i},{name:"Delphi",pattern:/\bdelphi\b/i},{name:"Assembly / Rev Eng",pattern:/\b(?:assembly|assembler|reverse engineering|disassembly)\b/i},{name:"Airtable",pattern:/\bairtable\b/i},{name:"Salesforce",pattern:/\bsalesforce\b/i},{name:"GraphQL",pattern:/\bgraphql\b/i},{name:"REST API",pattern:/\b(?:rest api|restful)\b/i},{name:"React Native",pattern:/\breact native\b/i},{name:"Flutter",pattern:/\bflutter\b/i},{name:"iOS / Swift",pattern:/\b(?:swift|swiftui|ios app)\b/i},{name:"Android / Kotlin",pattern:/\b(?:kotlin|android app)\b/i},{name:"PostgreSQL",pattern:/\b(?:postgresql|postgres)\b/i},{name:"MySQL",pattern:/\bmysql\b/i},{name:"MongoDB",pattern:/\bmongodb\b/i},{name:"Redis",pattern:/\bredis\b/i},{name:"Supabase",pattern:/\bsupabase\b/i},{name:"Firebase",pattern:/\bfirebase\b/i},{name:"AWS",pattern:/\b(?:aws|amazon web services)\b/i},{name:"Google Cloud",pattern:/\b(?:gcp|google cloud)\b/i},{name:"Docker",pattern:/\bdocker\b/i},{name:"Kubernetes",pattern:/\b(?:kubernetes|k8s)\b/i},{name:"Figma",pattern:/\bfigma\b/i},{name:"HubSpot",pattern:/\bhubspot\b/i},{name:"Klaviyo",pattern:/\bklaviyo\b/i},{name:"Stripe",pattern:/\bstripe\b/i},{name:"Zapier / Make",pattern:/\b(?:zapier|make\.com|integromat)\b/i}],hn=[{category:"unpaid",label:"Payment Withheld / Unpaid",pattern:/\b(dispute|unpaid|did not pay|refused to pay|refused payment|ended without paying|no payment|milestone refund|withheld|held hostage|chargeback|arbitration|refused release)\b/i},{category:"scope_creep",label:"Scope Creep / Endless Revisions",pattern:/\b(scope creep|endless revisions|unreasonable demands|unrealistic expectation|kept adding|never satisfied|demanded extra work|unpaid work|without extra pay|moving goalposts)\b/i},{category:"rude",label:"Hostile / Disrespectful Behavior",pattern:/\b(rude|disrespectful|toxic|hostile|arrogant|unprofessional|insulting|verbally abusive|nightmare client|screamed|abusive)\b/i},{category:"ghosting",label:"Unresponsive / Ghosting",pattern:/\b(ghosted|unresponsive|stopped replying|disappeared for weeks|went silent|no response for months|abandoned the project)\b/i},{category:"harsh_rating",label:"Severe Review Warning",pattern:/\b(do not recommend|stay away|avoid this client|run away|terrible experience|worst client|disaster client|beware of this client)\b/i}],xn=[{label:"⚡ Fast Payer",pattern:/\b(fast pay|prompt pay|paid immediately|released milestone immediately|pays quickly|quick to pay|instant payment)\b/i},{label:"📋 Clear Requirements",pattern:/\b(clear instructions|clear specs|clear requirements|well defined|knows what they want|great brief|organized)\b/i},{label:"💬 Great Communicator",pattern:/\b(great communication|responsive|responsive client|easy to communicate|clear communication|quick response)\b/i},{label:"🔄 High Repeat Hire Potential",pattern:/\b(long-term|repeatedly|worked together for|multiple contracts|second time working|third time working|work together again|hire again)\b/i},{label:"🤝 Flexible & Respectful",pattern:/\b(reasonable deadlines|flexible|understanding client|patient|respectful|pleasure to work)\b/i}],He=/\b(?:https?:\/\/)?(?:www\.)?([a-zA-Z0-9-]{3,40}\.(?:com|io|co|org|net|app|ai|dev|store|agency|tech|co\.uk|de|uk|ca|me|cc))\b/gi,Ne=new Set(["upwork","freelancer","client","looking","project","job","please","thanks","great","working","highly","developer","designer","experience","contract","position","opportunity"]);function yn(e,t){var d,m,g;let n=null,o=null,r=!1,a=!1;const s=t.matchAll(He);for(const p of s){const l=(d=p[1])==null?void 0:d.toLowerCase().trim();if(l&&!Be.has(l)){n=l,a=!0;break}}if(!n)for(const p of e){const l=p.matchAll(He);for(const y of l){const h=(m=y[1])==null?void 0:m.toLowerCase().trim();if(h&&!Be.has(h)){n=h,r=!0;break}}if(n)break}const i=[/(?:we are|at|welcome to)\s+([A-Z][A-Za-z0-9&'. -]{1,30}?\s+(?:LLC|Inc\b|Inc\.|Ltd\b|Ltd\.|GmbH|Corp\b|Corp\.))\b/i,/(?:we are|at|welcome to)\s+([A-Z][A-Za-z0-9&'. -]{2,30}?)(?=[,.;!\n]|\s+and|\s+we|\s+is|\s+looking)/i,/\b([A-Z][A-Za-z0-9&'. -]{1,30}?\s+(?:LLC|Inc\b|Inc\.|Ltd\b|Ltd\.|GmbH|Corp\b|Corp\.))\b/,/\b(?:our company|our agency|our brand|our store|our app|our platform)\s+(?:called|named|is)\s+([A-Z][A-Za-z0-9&'. -]{2,28})/i];for(const p of i){const l=p.exec(t);if(l!=null&&l[1]){let y=l[1].trim().replace(/[.,;:]$/,"");if(y=y.replace(/^(?:we are|our company is|welcome to|at|the)\s+/i,"").trim(),y.length>=3&&!Ne.has(y.toLowerCase())){o=y,a=!0;break}}}const c=[/working with\s+([A-Z][a-z]+)\s+and\s+(?:the\s+)?([A-Z][A-Za-z0-9&'. -]{1,30}\s+(?:team|crew|agency|group|company))\b/i,/working with\s+([A-Z][a-z]+)\s+and\s+(?:the\s+)?([A-Z][A-Za-z0-9&'. -]{2,25})/i,/working for\s+([A-Z][A-Za-z0-9&'. -]{1,30}\s+(?:team|group|company|LLC|Inc|Ltd))\b/i,/working for\s+([A-Z][A-Za-z0-9&'. -]{2,25})/i,/helped\s+([A-Z][A-Za-z0-9&'. -]{2,25})\s+(?:build|scale|launch|grow)/i,/part of the\s+([A-Z][A-Za-z0-9&'. -]{1,30}\s+team)/i];for(const p of e)for(const l of c){const y=l.exec(p),h=(g=(y==null?void 0:y[2])??(y==null?void 0:y[1]))==null?void 0:g.trim().replace(/[.,;:]$/,"");if(h&&h.length>=3&&!Ne.has(h.toLowerCase())){o?o.toLowerCase()===h.toLowerCase()&&(r=!0):(o=h,r=!0);break}}if(!o&&!n)return null;let u="description";a&&r?u="both":r?u="feedback":u="description";let b=.65;return o&&n?b=.95:a&&r?b=.9:(n||o&&/(?:LLC|Inc|Ltd|GmbH|Corp|Agency|Studio)/i.test(o))&&(b=.85),{name:o,domain:n,source:u,confidence:b}}function wn(e){const t=[],n=new Set;for(const o of e){const r=o.trim();if(r.length<15)continue;const a=/★\s*([1-5](?:\.\d{1,2})?)|(?:rating\s*(?:is|:)?\s*)([1-5](?:\.\d{1,2})?)/i.exec(r),s=a?parseFloat(a[1]??a[2]):null;for(const i of hn)if(i.pattern.test(r)){const u=r.split(new RegExp("(?<=[.!?])\\s+")).map(d=>d.trim()).filter(Boolean).find(d=>i.pattern.test(d))??r.slice(0,160),b=u.length>180?`${u.slice(0,177)}…`:u;n.has(b.toLowerCase())||(n.add(b.toLowerCase()),t.push({category:i.category,label:i.label,snippet:b,rating:s}));break}s!=null&&s<=3.5&&!n.has(r.slice(0,60).toLowerCase())&&(n.add(r.slice(0,60).toLowerCase()),t.push({category:"harsh_rating",label:`Low Rating (${s.toFixed(1)}★)`,snippet:r.length>180?`${r.slice(0,177)}…`:r,rating:s}))}return t.slice(0,5)}function vn(e){const t=new Set;for(const n of e){for(const o of xn)o.pattern.test(n)&&t.add(o.label);if(t.size>=4)break}return Array.from(t)}function kn(e,t){const n=`${t}
${e.join(`
`)}`,o=new Set;for(const r of fn)if(r.pattern.test(n)&&o.add(r.name),o.size>=10)break;return Array.from(o)}function X(e){const t=e.feedbacks||[],n=e.description||"",o=e.contractTitles||[];return{company:yn(t,n),reviewRedFlags:wn(t),praiseHighlights:vn(t),techStack:kn(o,n),summary:null}}const Cn=`
  :host { all: initial; }
  * { box-sizing: border-box; }
  .gr-badge {
    display: inline-flex; align-items: center; gap: 7px;
    margin-top: 8px;
    padding: 5px 12px 5px 9px;
    border-radius: 9px;
    background: #0A0E14;
    border: 1px solid #1E2530;
    color: #F3F4F6;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, Helvetica, Arial, sans-serif;
    font-size: 11.5px; line-height: 1;
    cursor: pointer; user-select: none;
    box-shadow: 0 2px 8px rgba(0, 0, 0, .5), inset 0 1px 0 rgba(255, 255, 255, .05);
    transition: transform 0.22s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.22s cubic-bezier(0.16, 1, 0.3, 1), border-color 0.2s ease, background 0.2s ease;
    width: max-content;
    will-change: transform;
  }
  .gr-badge:hover {
    transform: translateY(-1px) scale(1.02);
    border-color: #2E3846;
    box-shadow: 0 6px 20px rgba(0, 0, 0, .6), 0 0 12px rgba(16, 185, 129, .12);
  }
  .gr-badge:active { transform: translateY(0) scale(.98); }
  .gr-dot { width: 6px; height: 6px; border-radius: 999px; flex: none; }
  .gr-high   .gr-dot { background: #34D399; box-shadow: 0 0 10px rgba(52, 211, 153, .8), 0 0 3px #10B981; }
  .gr-medium .gr-dot { background: #F59E0B; box-shadow: 0 0 10px rgba(245, 158, 11, .75); }
  .gr-low    .gr-dot { background: #EF4444; box-shadow: 0 0 10px rgba(239, 68, 68, .75); }
  .gr-high   { border-color: rgba(16, 185, 129, .38); background: linear-gradient(180deg, #0E1519, #0A0E14); }
  .gr-high:hover { border-color: rgba(52, 211, 153, .7); box-shadow: 0 6px 20px rgba(0, 0, 0, .6), 0 0 16px rgba(16, 185, 129, .25); }
  .gr-medium { border-color: rgba(245, 158, 11, .38); background: linear-gradient(180deg, #15130E, #0A0E14); }
  .gr-medium:hover { border-color: rgba(245, 158, 11, .7); box-shadow: 0 6px 20px rgba(0, 0, 0, .6), 0 0 16px rgba(245, 158, 11, .2); }
  .gr-low    { border-color: rgba(239, 68, 68, .35); background: linear-gradient(180deg, #170E11, #0A0E14); }
  .gr-low:hover { border-color: rgba(239, 68, 68, .7); box-shadow: 0 6px 20px rgba(0, 0, 0, .6), 0 0 16px rgba(239, 68, 68, .2); }
  .gr-brand {
    font-weight: 800; font-size: 10.5px; letter-spacing: .04em; text-transform: uppercase;
    background: linear-gradient(90deg, #34D399, #10B981);
    -webkit-background-clip: text; background-clip: text;
    color: transparent;
  }
  .gr-score { font-weight: 800; font-size: 12.5px; color: #FFFFFF; font-variant-numeric: tabular-nums; }
  .gr-tier  { font-weight: 700; font-size: 9.5px; letter-spacing: .08em; text-transform: uppercase; color: #94A3B8; }
  .gr-provisional { font-weight: 800; font-size: 8px; letter-spacing: .06em; color: #FCD34D; }
  .gr-flag {
    margin-left: 1px; padding: 2px 6.5px; border-radius: 5px;
    background: rgba(245, 158, 11, .14); border: 1px solid rgba(245, 158, 11, .32);
    color: #FCD34D; font-size: 9.5px; font-weight: 800; font-variant-numeric: tabular-nums;
  }
  .gr-neutral { border-color: #1E2530; background: #0A0E14; }
  .gr-neutral .gr-dot {
    background: #94A3B8;
    border: 1px solid #475569;
    box-shadow: none;
  }
  .gr-hint { font-weight: 600; font-size: 9.5px; letter-spacing: .02em; color: #94A3B8; }
  .gr-alert {
    display: flex; align-items: center; gap: 6px;
    margin-top: 5px;
    padding: 5.5px 11px;
    border-radius: 7px;
    border: 1px solid transparent;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, Helvetica, Arial, sans-serif;
    font-size: 11px; font-weight: 800; letter-spacing: -.01em; line-height: 1.35;
    width: max-content; max-width: 100%;
    cursor: pointer; user-select: none;
    box-shadow: 0 2px 8px rgba(0, 0, 0, .45);
    transition: transform 0.22s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.22s cubic-bezier(0.16, 1, 0.3, 1);
    will-change: transform;
  }
  .gr-alert:hover { transform: translateY(-1px) scale(1.02); }
  .gr-a-high   { background: rgba(16, 185, 129, .13); border-color: rgba(52, 211, 153, .45); color: #34D399; box-shadow: 0 0 14px rgba(16, 185, 129, .2), 0 2px 8px rgba(0, 0, 0, .4); }
  .gr-a-danger { background: rgba(239, 68, 68, .12);  border-color: rgba(239, 68, 68, .42);  color: #FCA5A5; }
  .gr-a-warn   { background: rgba(245, 158, 11, .12); border-color: rgba(245, 158, 11, .38); color: #FCD34D; }
  .gr-team-alert {
    display: flex; align-items: center; gap: 7px;
    margin-top: 5px;
    padding: 6px 12px;
    border-radius: 8px;
    background: rgba(139, 92, 246, 0.14);
    border: 1px solid rgba(139, 92, 246, 0.45);
    color: #DDD6FE;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, Helvetica, Arial, sans-serif;
    font-size: 11px; font-weight: 700; line-height: 1.35;
    width: max-content; max-width: 100%;
    cursor: pointer; user-select: none;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.45), 0 0 12px rgba(139, 92, 246, 0.2);
    transition: transform 0.22s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.22s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .gr-team-alert:hover {
    transform: translateY(-1px) scale(1.02);
    border-color: rgba(167, 139, 250, 0.7);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.6), 0 0 16px rgba(139, 92, 246, 0.35);
  }
  .gr-team-dot {
    width: 7px; height: 7px; border-radius: 999px;
    background: #A78BFA;
    box-shadow: 0 0 8px #8B5CF6;
    animation: gr-pulse 2s infinite ease-in-out;
  }
  @keyframes gr-pulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.4; transform: scale(0.85); }
  }
`;function nt(e,t,n){const o=document.createElement("div");o.dataset.gigradarBadge="",o.style.cssText="width:100%;display:block";const r=o.attachShadow({mode:"closed"}),a=document.createElement("style");a.textContent=Cn;const s=t.locale||"en",i=t.score==null||t.tier==null,c=document.createElement("div");c.className=`gr-badge ${i?"gr-neutral":`gr-${t.tier.toLowerCase()}`}`,c.setAttribute("role","button"),c.tabIndex=0;const u=t.tier==="HIGH"?"badge_high_intent":t.tier==="MEDIUM"?"badge_medium_intent":"badge_low_intent",b=t.tier?f(u,s):"";c.setAttribute("aria-label",i?f("badge_click_to_inspect",s):`GigRadar client score ${t.score} of 100, ${b}${t.provisional?`, ${f("badge_provisional",s).toLowerCase()}`:""}`),c.addEventListener("keydown",l=>{(l.key==="Enter"||l.key===" ")&&(l.preventDefault(),l.stopPropagation(),n())});const d=t.flagCount>0?`<span class="gr-flag">⚠ ${t.flagCount}</span>`:"";if(c.innerHTML=i?['<span class="gr-dot"></span>','<span class="gr-brand">GigRadar</span>','<span class="gr-score">--</span>',`<span class="gr-hint">${f("badge_click_to_inspect",s)}</span>`,d].join(""):['<span class="gr-dot"></span>','<span class="gr-brand">GigRadar</span>',`<span class="gr-score">${t.score}</span>`,`<span class="gr-tier">${b}</span>`,t.provisional?`<span class="gr-provisional">${f("badge_provisional",s)}</span>`:"",d].join(""),r.append(a,c),t.alert){const l=document.createElement("div");l.className=`gr-alert gr-a-${t.alert.level}`,l.textContent=t.alert.text,l.setAttribute("role","button"),l.tabIndex=0,l.setAttribute("aria-label",t.alert.text),l.addEventListener("click",y=>{y.preventDefault(),y.stopPropagation(),n()}),l.addEventListener("keydown",y=>{(y.key==="Enter"||y.key===" ")&&(y.preventDefault(),y.stopPropagation(),n())}),r.append(l)}if(t.teamAlert){const l=document.createElement("div");l.className="gr-team-alert";const y=t.teamAlert.status==="applied"?"team_member_applied":t.teamAlert.status==="drafting"?"team_member_drafting":"team_member_viewing",h=f(y,s);l.innerHTML=`<span class="gr-team-dot"></span><span>👥 TEAM: <b>${t.teamAlert.memberName}</b> ${h} (${t.teamAlert.timeAgo})</span>`,l.setAttribute("role","button"),l.tabIndex=0,l.setAttribute("aria-label",`Team alert: ${t.teamAlert.memberName} ${h} ${t.teamAlert.timeAgo}`),l.addEventListener("click",S=>{S.preventDefault(),S.stopPropagation(),n()}),l.addEventListener("keydown",S=>{(S.key==="Enter"||S.key===" ")&&(S.preventDefault(),S.stopPropagation(),n())}),r.append(l)}e.querySelectorAll("[data-gigradar-badge]").forEach(l=>l.remove());const m=Ct(e),g=(m==null?void 0:m.link)??St(e,we.titleLink),p=(g==null?void 0:g.closest('h2, h3, h4, [class*="title"], [data-test*="title"]'))??(g==null?void 0:g.parentElement);return p&&e.contains(p)?p.insertAdjacentElement("afterend",o):e.prepend(o),o.addEventListener("click",l=>{l.preventDefault(),l.stopPropagation(),n()}),o}function ot(e){const t=e.flags.filter(r=>r.level==="danger"),n=e.flags.filter(r=>r.level==="warn"),o=[];e.signals.hireRatePct!=null&&o.push(`${Math.round(e.signals.hireRatePct)}% hire rate`),e.signals.totalSpendUsd!=null&&o.push(e.signals.totalSpendUsd>0?`${Sn(e.signals.totalSpendUsd)} spent`:"$0 spent"),e.signals.paymentVerified===!0&&o.push("payment verified"),e.proposalCount!=null&&o.push(e.proposalCount>=50?"50+ proposals":`${e.proposalCount} proposals`);for(const r of e.flags)if(o.includes(r.text)||o.push(r.text),o.length>=3)break;if(t.length>0){const r=t[0].text.toLowerCase();let a="Protect your Connects — avoid submitting proposals until risk factors are resolved.";return r.includes("payment")||r.includes("unverified")?a="Do not submit proposals or share work until the client verifies payment and funds an escrow milestone.":(r.includes("scam")||r.includes("telegram")||r.includes("whatsapp"))&&(a="Critical risk of off-platform contact — report this listing and never communicate outside Upwork."),{action:"SKIP",risk:"HIGH",summary:"High risk — protect your Connects",reasons:o.slice(0,3),recommendation:a}}return e.score.scored?e.score.score>=70&&n.length===0?{action:"BID",risk:"LOW",summary:"Strong client signals — worth a tailored proposal",reasons:o.slice(0,3),recommendation:"Lead with the result you can deliver in the first two weeks."}:e.score.score<40||n.length>=2?{action:"SKIP",risk:"HIGH",summary:"Weak signals — keep your Connects",reasons:o.slice(0,3),recommendation:"Skip unless the project is an unusually strong fit."}:{action:"CONSIDER",risk:"MEDIUM",summary:"Mixed signals — inspect the details before bidding",reasons:o.slice(0,3),recommendation:"Resolve the warning signals before you commit Connects."}:{action:"CONSIDER",risk:"MEDIUM",summary:"Not enough client data to decide confidently",reasons:o.slice(0,3),recommendation:"Open the full client profile before spending Connects."}}function Sn(e){return e>=1e3?`$${(e/1e3).toFixed(e>=1e4?0:1)}k`:`$${Math.round(e)}`}let Se="en";Xe().then(e=>{Se=e});Qe(e=>{Se=e});const En=`
  :host { all: initial; }
  * { box-sizing: border-box; }
  .backdrop {
    position: absolute; inset: 0;
    background: rgba(2, 6, 23, 0);
    pointer-events: auto;
    transition: background 0.28s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .open .backdrop { background: rgba(2, 6, 23, .65); backdrop-filter: blur(2px); }
  .panel {
    position: absolute; top: 0; right: 0; bottom: 0;
    width: min(420px, 94vw);
    background: #0A0E14;
    border-left: 1px solid #1E2530;
    box-shadow: -16px 0 48px rgba(0, 0, 0, .65);
    display: flex; flex-direction: column;
    transform: translateX(102%);
    transition: transform 0.32s cubic-bezier(0.16, 1, 0.3, 1);
    will-change: transform;
    pointer-events: auto;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, Helvetica, Arial, sans-serif;
    color: #F3F4F6;
  }
  .open .panel { transform: translateX(0); }
  .head {
    padding: 18px 20px 16px;
    border-bottom: 1px solid #1E2530;
    display: flex; align-items: flex-start; gap: 14px;
    background: linear-gradient(135deg, #0E131C, #0A0E14);
  }
  .score-ring {
    flex: none;
    width: 64px; height: 64px;
    border-radius: 16px;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    font-weight: 800; font-size: 22px; line-height: 1;
    font-variant-numeric: tabular-nums;
    color: #F3F4F6;
    border: 1px solid #1E2530;
  }
  .score-ring small { font-size: 8.5px; font-weight: 700; letter-spacing: .12em; margin-top: 3px; opacity: .75; }
  .tier-high   { background: rgba(16,185,129,.10); border-color: rgba(52,211,153,.45); box-shadow: 0 0 22px rgba(16,185,129,.18); }
  .tier-medium { background: rgba(245,158,11,.10); border-color: rgba(245,158,11,.45); box-shadow: 0 0 22px rgba(245,158,11,.15); }
  .tier-low    { background: rgba(239,68,68,.10); border-color: rgba(239,68,68,.45); box-shadow: 0 0 22px rgba(239,68,68,.15); }
  .tier-nodata {
    background: #0E1218;
    border-color: #1E2530;
    color: #94A3B8;
    box-shadow: none;
  }
  .job-title { font-size: 14px; font-weight: 700; line-height: 1.35; margin: 0 0 5px; color: #F3F4F6; }
  .job-sub { font-size: 12px; color: #94A3B8; margin: 0; }
  .head-actions {
    margin-left: auto; flex: none;
    display: flex; align-items: center; gap: 6px;
  }
  .settings-btn {
    width: 30px; height: 30px;
    border-radius: 9px; border: 1px solid #1E2530;
    background: #121620; cursor: pointer;
    display: flex; align-items: center; justify-content: center;
    color: #94A3B8;
    transition: all 0.18s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .settings-btn svg { width: 14px; height: 14px; display: block; }
  .settings-btn:hover { background: #1A202C; color: #34D399; border-color: #2E3846; transform: scale(1.05); }
  .settings-btn:active { transform: scale(0.95); }
  .close-btn {
    width: 30px; height: 30px;
    border-radius: 9px; border: 1px solid #1E2530;
    background: #121620; cursor: pointer;
    font-size: 14px; line-height: 1; color: #94A3B8;
    display: flex; align-items: center; justify-content: center;
    transition: all 0.18s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .close-btn:hover { background: #1A202C; color: #F3F4F6; border-color: #2E3846; transform: scale(1.05); }
  .close-btn:active { transform: scale(0.95); }
  .body { overflow-y: auto; padding: 18px 20px 28px; flex: 1; }
  .body::-webkit-scrollbar { width: 6px; }
  .body::-webkit-scrollbar-track { background: transparent; }
  .body::-webkit-scrollbar-thumb { background: #1E2530; border-radius: 999px; }
  .body::-webkit-scrollbar-thumb:hover { background: #2E3846; }
  h3.sec {
    font-size: 10px; font-weight: 800; letter-spacing: .12em;
    text-transform: uppercase; color: #64748B;
    margin: 20px 0 9px;
  }
  table.signals { width: 100%; border-collapse: collapse; border-radius: 10px; overflow: hidden; border: 1px solid #1E2530; }
  table.signals td { padding: 9px 12px; font-size: 13px; border-bottom: 1px solid #171C25; vertical-align: middle; background: #0E1218; }
  table.signals tr:last-child td { border-bottom: none; }
  table.signals td:first-child { color: #CBD5E1; font-weight: 600; width: 36%; }
  .bar { height: 5px; border-radius: 999px; background: #1E2530; overflow: hidden; }
  .bar > i { display: block; height: 100%; border-radius: 999px; background: linear-gradient(90deg, #059669, #34D399); box-shadow: 0 0 8px rgba(16,185,129,.4); }
  .val { text-align: right; font-weight: 700; white-space: nowrap; font-variant-numeric: tabular-nums; width: 24%; }
  .na { color: #475569; font-weight: 500; font-size: 11.5px; }
  ul.flags { list-style: none; margin: 0; padding: 0; display: grid; gap: 7px; }
  ul.flags li {
    font-size: 12.5px; line-height: 1.45;
    padding: 9px 12px; border-radius: 9px;
    display: flex; gap: 8px; align-items: baseline;
    border: 1px solid;
  }
  .flag-danger { background: rgba(239,68,68,.08); color: #FCA5A5; border-color: rgba(239,68,68,.28); }
  .flag-warn   { background: rgba(245,158,11,.08); color: #FCD34D; border-color: rgba(245,158,11,.28); }
  .flag-ok     { background: rgba(16,185,129,.08); color: #6EE7B7; border-color: rgba(16,185,129,.28); }
  .gate { position: relative; border-radius: 12px; }
  .gate.locked { min-height: 110px; }
  .gate.locked > *:not(.lock-overlay) { filter: blur(5px); pointer-events: none; user-select: none; opacity: .50; }
  .lock-overlay {
    position: absolute; inset: -4px;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    background: rgba(10,14,20,.65);
    backdrop-filter: blur(4px);
    border-radius: 12px;
  }
  .paywall-note {
    display: block;
    margin-top: 6px;
    margin-bottom: 16px;
    line-height: 1.4;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: .01em;
    text-align: center;
    color: #94A3B8;
  }
  .pro-btn {
    padding: 10px 18px;
    border: 1px solid rgba(245,158,11,.45); border-radius: 10px;
    background: linear-gradient(180deg, rgba(245,158,11,.20), rgba(245,158,11,.10));
    color: #FCD34D;
    font-family: inherit;
    font-size: 12.5px; font-weight: 700; letter-spacing: -.01em; cursor: pointer;
    box-shadow: 0 0 24px rgba(245,158,11,.16);
    transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s ease, border-color 0.2s ease, background 0.2s ease;
  }
  .pro-btn:hover {
    background: linear-gradient(180deg, rgba(245,158,11,.28), rgba(245,158,11,.15));
    border-color: rgba(245,158,11,.7);
    transform: translateY(-1px) scale(1.02);
    box-shadow: 0 0 32px rgba(245,158,11,.28);
  }
  .pro-btn:active { transform: translateY(0) scale(.98); }
  .name-chip {
    display: inline-flex; align-items: center; gap: 8px;
    background: rgba(16,185,129,.09);
    border: 1px solid rgba(16,185,129,.35);
    color: #6EE7B7;
    font-size: 13px; font-weight: 800;
    padding: 8px 14px; border-radius: 999px;
  }
  .conf { font-size: 10.5px; font-weight: 700; opacity: .75; }
  .hint { font-size: 12.5px; color: #9CA3AF; line-height: 1.55; margin: 0; }
  .name-row { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
  .mini-copy {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 7px 13px; border-radius: 999px;
    border: 1px solid rgba(16,185,129,.4);
    background: rgba(16,185,129,.08);
    color: #6EE7B7;
    font-family: inherit; font-size: 11px; font-weight: 800;
    cursor: pointer;
    transition: all .15s ease;
  }
  .mini-copy:hover { background: rgba(16,185,129,.16); transform: translateY(-1px); }
  .mini-copy.copied,
  .act.copied {
    background: rgba(16,185,129,.18) !important;
    border-color: rgba(16,185,129,.45) !important;
    color: #6EE7B7 !important;
  }
  .ho-toolbar { justify-content: space-between; }
  .hook-opt {
    margin-top: 8px;
    padding: 11px 13px;
    border: 1px solid #1E2530;
    background: #0E1218;
    border-radius: 10px;
  }
  .ho-head {
    display: flex; align-items: center; gap: 7px;
    font-size: 10px; letter-spacing: .06em; text-transform: uppercase;
  }
  .ho-head b { color: #34D399; font-size: 10.5px; }
  .ho-head span { color: #64748B; font-weight: 600; }
  .ho-text { margin: 8px 0 0; font-size: 12.5px; line-height: 1.55; color: #E2E8F0; white-space: pre-wrap; }
  .ho-foot { display: flex; gap: 8px; margin-top: 9px; }
  textarea.hook {
    width: 100%; min-height: 96px;
    resize: vertical;
    border: 1px solid #1E2530; border-radius: 10px;
    background: #080A0E;
    padding: 11px 13px;
    font-family: inherit; font-size: 13px; line-height: 1.55;
    color: #F3F4F6;
    transition: border-color .15s ease;
  }
  textarea.hook::placeholder { color: #4B5563; }
  textarea.hook:focus { outline: none; border-color: rgba(16,185,129,.55); box-shadow: 0 0 0 3px rgba(16,185,129,.12); }
  .row { display: flex; gap: 8px; margin-top: 9px; flex-wrap: wrap; }
  .act {
    padding: 8px 14px; border-radius: 9px;
    border: 1px solid #1E2530; background: #121620;
    font-family: inherit;
    font-size: 12.5px; font-weight: 700; color: #E5E7EB; cursor: pointer;
    transition: all 0.18s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .act:hover { background: #1A202C; border-color: #2E3846; }
  .act:active { transform: scale(.97); }
  .act.primary {
    background: linear-gradient(180deg, #34D399, #059669);
    border-color: transparent; color: #07090C;
    box-shadow: 0 4px 16px rgba(16,185,129,.28), inset 0 1px 0 rgba(255,255,255,.2);
    transition: transform 0.18s cubic-bezier(0.16, 1, 0.3, 1), filter 0.15s ease, box-shadow 0.18s ease;
  }
  .act.primary:hover { filter: brightness(1.08); transform: translateY(-1px); box-shadow: 0 6px 20px rgba(16,185,129,.38); }
  .act.primary:active { transform: translateY(0) scale(.97); }
  .act[disabled] { opacity: .45; cursor: not-allowed; transform: none !important; }
  .err { margin-top: 8px; font-size: 12px; color: #F87171; }
  .scan-note {
    display: flex; align-items: center; gap: 8px;
    margin: 0 0 12px;
    padding: 9px 12px;
    border-radius: 10px;
    background: rgba(245,158,11,.07);
    border: 1px solid rgba(245,158,11,.25);
    color: #FCD34D;
    font-size: 12px; line-height: 1.45;
  }
  .scan-note i {
    width: 7px; height: 7px; border-radius: 999px; flex: none;
    background: #F59E0B;
    animation: grScanPulse 1.1s ease-in-out infinite;
  }
  @keyframes grScanPulse {
    0%, 100% { opacity: 1; box-shadow: 0 0 0 0 rgba(245,158,11,.5); }
    50% { opacity: .5; box-shadow: 0 0 0 4px rgba(245,158,11,0); }
  }
  .guest-note {
    display: flex; align-items: center; gap: 10px;
    margin: 14px 0 2px;
    padding: 11px 12px;
    border-radius: 10px;
    background: rgba(59,130,246,.09);
    border: 1px solid rgba(59,130,246,.30);
    color: #93C5FD;
    font-size: 12px; line-height: 1.5;
  }
  .guest-note b { color: #BFDBFE; }
  .guest-link {
    margin-left: auto; flex: none;
    padding: 6px 12px; border-radius: 8px;
    background: #2563EB; border: none; cursor: pointer;
    color: #fff; font-family: inherit;
    font-size: 11.5px; font-weight: 700;
    transition: filter .15s ease, transform .12s ease;
  }
  .guest-link:hover { filter: brightness(1.12); }
  .guest-link:active { transform: scale(.97); }
  .decision {
    margin: 0 0 14px;
    padding: 11px 12px;
    border: 1px solid;
    border-radius: 10px;
  }
  .decision-bid { background: rgba(16,185,129,.08); border-color: rgba(16,185,129,.35); }
  .decision-consider { background: rgba(245,158,11,.08); border-color: rgba(245,158,11,.30); }
  .decision-skip { background: rgba(239,68,68,.08); border-color: rgba(239,68,68,.30); }
  .decision-top { display: flex; align-items: baseline; gap: 8px; }
  .decision-top strong { font-size: 12px; letter-spacing: .08em; color: #F3F4F6; }
  .decision-top span { color: #CBD5E1; font-size: 11.5px; line-height: 1.35; }
  .decision-reasons { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 7px; }
  .decision-reasons span { padding: 3px 7px; border-radius: 999px; background: rgba(255,255,255,.06); color: #9CA3AF; font-size: 10px; }
  .decision p { margin: 8px 0 0; color: #E5E7EB; font-size: 11.5px; line-height: 1.4; }
  .roi-card {
    margin: 0 0 14px;
    padding: 10px 12px;
    border-radius: 10px;
    background: linear-gradient(135deg, rgba(16,185,129,.08), rgba(15,23,42,.45));
    border: 1px solid rgba(16,185,129,.25);
    display: flex; flex-direction: column; gap: 4px;
  }
  .roi-header {
    display: flex; align-items: center; justify-content: space-between;
  }
  .roi-title {
    font-size: 11px; font-weight: 800; letter-spacing: .06em;
    text-transform: uppercase; color: #34D399;
  }
  .roi-badge {
    font-size: 10px; font-weight: 800;
    padding: 2px 7px; border-radius: 999px;
    background: rgba(16,185,129,.15);
    border: 1px solid rgba(16,185,129,.35);
    color: #6EE7B7;
  }
  .roi-stat {
    margin: 0; font-size: 12px; line-height: 1.4; color: #CBD5E1;
  }
  .roi-stat b { color: #F3F4F6; font-weight: 700; }
  .roi-stat .roi-highlight { color: #34D399; font-weight: 700; }
  .pro-hook-header {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 6px; font-size: 10.5px; font-weight: 700; color: #FCD34D;
    letter-spacing: .04em; text-transform: uppercase;
  }
  .pro-hook-tag {
    font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px;
    background: rgba(245,158,11,.15); border: 1px solid rgba(245,158,11,.3);
    color: #FCD34D;
  }
  .autopilot-card {
    margin: 14px 0 10px;
    padding: 12px 14px;
    border-radius: 12px;
    background: linear-gradient(135deg, rgba(99,102,241,.09), rgba(15,23,42,.65));
    border: 1px solid rgba(99,102,241,.32);
    display: flex; flex-direction: column; gap: 10px;
  }
  .ap-header {
    display: flex; align-items: center; justify-content: space-between;
  }
  .ap-title {
    font-size: 11px; font-weight: 800; letter-spacing: .06em;
    text-transform: uppercase; color: #A5B4FC; display: flex; align-items: center; gap: 6px;
  }
  .ap-badge {
    font-size: 9px; font-weight: 800; padding: 2px 7px; border-radius: 999px;
    background: rgba(99,102,241,.2); border: 1px solid rgba(99,102,241,.45); color: #C7D2FE;
  }
  .ap-case-chip {
    padding: 8px 10px; border-radius: 8px; font-size: 11.5px;
    background: #0D1117; border: 1px solid #1E2530; color: #E2E8F0;
    line-height: 1.4;
  }
  .ap-case-chip small { color: #94A3B8; font-size: 10.5px; display: block; margin-bottom: 2px; }
  .ap-case-chip b { color: #A5B4FC; font-weight: 700; display: block; margin-bottom: 2px; }
  .ap-case-chip span { color: #CBD5E1; font-size: 11px; }
  .ap-tone-bar {
    display: flex; align-items: center; justify-content: space-between; gap: 8px;
  }
  .ap-tone-select {
    flex: 1; background: #0E1218; border: 1px solid #1E2530; border-radius: 8px;
    padding: 6px 8px; color: #F3F4F6; font-size: 11.5px; outline: none; cursor: pointer;
  }
  .ap-proposal-preview {
    font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    font-size: 11.5px; line-height: 1.5; color: #CBD5E1; background: #070A0F;
    border: 1px solid #1E2530; border-radius: 8px; padding: 10px;
    max-height: 150px; overflow-y: auto; white-space: pre-wrap; word-break: break-word;
    margin: 0;
  }
  .ap-proposal-preview::-webkit-scrollbar { width: 5px; }
  .ap-proposal-preview::-webkit-scrollbar-thumb { background: #1E2530; border-radius: 4px; }
  .ap-actions {
    display: flex; gap: 8px; align-items: center;
  }
  .ap-btn-copy {
    flex: 1; padding: 7px 12px; border-radius: 8px; font-weight: 700; font-size: 11.5px;
    background: #4F46E5; border: 1px solid #6366F1; color: #fff; cursor: pointer;
    transition: all 0.16s ease; display: flex; align-items: center; justify-content: center; gap: 6px;
  }
  .ap-btn-copy:hover { background: #4338CA; border-color: #818CF8; }
  .ap-btn-polish {
    padding: 7px 12px; border-radius: 8px; font-weight: 700; font-size: 11.5px;
    background: #121620; border: 1px solid #2E3846; color: #C7D2FE; cursor: pointer;
    transition: all 0.16s ease; display: flex; align-items: center; gap: 5px;
  }
  .ap-btn-polish:hover { background: #1A202C; border-color: #6366F1; color: #fff; }
  .panel.docked {
    top: var(--gr-top-offset, 64px);
    bottom: auto;
    max-height: calc(100vh - var(--gr-top-offset, 64px) - 20px);
    width: min(400px, 92vw);
    border-radius: 14px 0 0 14px;
    border: 1px solid #1E2530;
    border-right: none;
    box-shadow: -18px 12px 48px rgba(0, 0, 0, .65), inset 0 1px 0 rgba(255,255,255,.05);
    transform: translateX(104%);
    transition: transform 0.32s cubic-bezier(0.16, 1, 0.3, 1);
    will-change: transform;
  }
  .wrap.docked.open .panel { transform: translateX(0); }
  .wrap.docked.open .panel.docked.collapsed {
    transform: translateX(calc(100% + 20px));
    pointer-events: none;
  }
  @media (max-width: 1440px) {
    .panel,
    .panel.docked {
      width: min(380px, 42vw);
      max-height: calc(100vh - var(--gr-top-offset, 60px) - 16px);
      top: var(--gr-top-offset, 60px);
    }
  }
  @media (max-width: 1024px) {
    .panel,
    .panel.docked {
      width: min(360px, 92vw);
    }
  }
  .activity-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 7px; }
  .act-cell {
    background: #10141B;
    border: 1px solid #171C25;
    border-radius: 10px;
    padding: 9px 6px;
    text-align: center;
  }
  .act-cell span {
    display: block;
    font-size: 16px; font-weight: 800;
    font-variant-numeric: tabular-nums;
    color: #F3F4F6; line-height: 1.1;
  }
  .act-cell small {
    display: block;
    margin-top: 3px;
    font-size: 8px; font-weight: 700;
    letter-spacing: .08em; text-transform: uppercase;
    color: #6B7280;
  }
  .tr-block {
    border: 1px solid rgba(16,185,129,.25);
    background: linear-gradient(180deg, rgba(16,185,129,.05), rgba(16,185,129,.01)), #10141B;
    border-radius: 12px;
    padding: 12px 13px;
    display: grid; gap: 9px;
  }
  .tr-row { display: flex; align-items: baseline; justify-content: space-between; gap: 10px; font-size: 12.5px; }
  .tr-row b { color: #CBD5E1; font-weight: 600; }
  .tr-row em { font-style: normal; font-weight: 800; color: #34D399; font-variant-numeric: tabular-nums; white-space: nowrap; }
  .tr-chips { display: flex; flex-wrap: wrap; gap: 6px; }
  .chip {
    padding: 3.5px 9px; border-radius: 999px;
    font-size: 10px; font-weight: 700; border: 1px solid;
    max-width: 100%;
  }
  .chip.c-danger { background: rgba(239,68,68,.08); color: #FCA5A5; border-color: rgba(239,68,68,.30); }
  .chip.c-warn   { background: rgba(245,158,11,.08); color: #FCD34D; border-color: rgba(245,158,11,.30); }
  .chip.c-ok     { background: rgba(16,185,129,.08); color: #6EE7B7; border-color: rgba(16,185,129,.30); }
  .company-pill-row {
    display: flex; flex-wrap: wrap; gap: 6px; margin-top: 6px;
  }
  .company-tag {
    display: inline-flex; align-items: center; gap: 4px;
    padding: 2.5px 8px; border-radius: 6px;
    background: rgba(52,211,153,.12); border: 1px solid rgba(52,211,153,.35);
    color: #34D399; font-size: 11px; font-weight: 700;
  }
  .domain-tag {
    display: inline-flex; align-items: center; gap: 4px;
    padding: 2.5px 8px; border-radius: 6px;
    background: rgba(56,189,248,.12); border: 1px solid rgba(56,189,248,.35);
    color: #38BDF8; font-size: 11px; font-weight: 700;
    text-decoration: none; transition: all 0.15s ease;
  }
  .domain-tag:hover {
    border-color: #38BDF8; background: rgba(56,189,248,.2); text-decoration: none;
  }
  .watchout-box {
    margin: 14px 0; padding: 12px 14px; border-radius: 12px;
    background: linear-gradient(180deg, rgba(239,68,68,.10) 0%, rgba(10,14,20,.65) 100%);
    border: 1px solid rgba(239,68,68,.35);
    box-shadow: 0 4px 18px rgba(239,68,68,.08);
  }
  .watchout-box.clean {
    background: rgba(16,185,129,.06);
    border-color: rgba(52,211,153,.25);
    box-shadow: none;
  }
  .watchout-header {
    display: flex; flex-direction: column; gap: 2px; margin-bottom: 10px;
  }
  .watchout-badge {
    font-size: 11px; font-weight: 800; color: #F87171; letter-spacing: .05em; text-transform: uppercase;
  }
  .watchout-sub {
    font-size: 11px; color: #94A3B8;
  }
  .watchout-list {
    display: flex; flex-direction: column; gap: 8px;
  }
  .watchout-card {
    background: #0E131C; border: 1px solid #1E2530; border-radius: 8px;
    padding: 9px 12px; border-left: 3px solid #EF4444;
  }
  .watchout-card-top {
    display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;
  }
  .watchout-cat {
    font-size: 10px; font-weight: 800; text-transform: uppercase; letter-spacing: .04em; color: #F87171;
  }
  .watchout-star {
    font-size: 11px; font-weight: 700; color: #F59E0B;
  }
  .watchout-quote {
    margin: 0; font-size: 12px; line-height: 1.45; color: #E2E8F0; font-style: italic;
  }
  .watchout-clean-text {
    display: flex; align-items: center; gap: 8px; font-size: 12px; color: #34D399;
  }
  .clean-icon { font-weight: 900; font-size: 14px; }
  .tech-stack-row, .praise-row {
    display: flex; flex-wrap: wrap; gap: 6px; margin: 4px 0 14px;
  }
  .tech-chip {
    padding: 3.5px 9px; border-radius: 8px; font-size: 11px; font-weight: 600;
    background: #111622; border: 1px solid #1E2530; color: #E2E8F0;
  }
  .praise-chip {
    padding: 3.5px 9px; border-radius: 8px; font-size: 11px; font-weight: 600;
    background: rgba(16,185,129,.08); border: 1px solid rgba(16,185,129,.25); color: #6EE7B7;
  }
  .dossier-card {
    margin: 6px 0 16px; padding: 13px 14px; border-radius: 12px;
    background: #0E131C; border: 1px solid #1E2530;
  }
  .dossier-intro {
    display: flex; align-items: center; justify-content: space-between; gap: 10px; font-size: 12px; color: #94A3B8;
  }
  .dossier-btn {
    flex: none; padding: 6px 12px; border-radius: 8px;
    background: linear-gradient(180deg, #38BDF8, #0284C7);
    border: none; cursor: pointer; color: #07090C;
    font-size: 11.5px; font-weight: 800; font-family: inherit;
    transition: all 0.18s cubic-bezier(0.16, 1, 0.3, 1);
  }
  .dossier-btn:hover { filter: brightness(1.1); transform: translateY(-1px); }
  .dossier-btn:active { transform: translateY(0) scale(.97); }
  .dossier-btn[disabled] { opacity: .5; cursor: not-allowed; transform: none !important; }
  .dossier-content {
    margin-top: 10px; padding-top: 10px; border-top: 1px solid #1E2530;
    font-size: 12px; line-height: 1.6; color: #E2E8F0; white-space: pre-wrap;
  }
  .dossier-gate-box {
    margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: rgba(56,189,248,.06); border: 1px solid rgba(56,189,248,.2);
    font-size: 11.5px; color: #94A3B8; line-height: 1.45;
  }
  .dossier-gate-box b { color: #38BDF8; }
  .dossier-settings-btn {
    display: inline-block; margin-top: 7px; padding: 4px 10px; border-radius: 6px;
    background: #1E2530; border: 1px solid #2E3846; color: #F3F4F6;
    font-size: 11px; font-weight: 700; cursor: pointer;
  }
  .dossier-settings-btn:hover { background: #2A3444; }
  .team-banner {
    margin-bottom: 14px;
    padding: 12px 14px;
    border-radius: 12px;
    background: rgba(139, 92, 246, 0.12);
    border: 1px solid rgba(139, 92, 246, 0.45);
    box-shadow: 0 4px 18px rgba(0, 0, 0, 0.35), 0 0 14px rgba(139, 92, 246, 0.15);
  }
  .team-banner.collision {
    background: rgba(225, 29, 72, 0.14);
    border-color: rgba(244, 63, 94, 0.55);
    box-shadow: 0 4px 18px rgba(0, 0, 0, 0.35), 0 0 16px rgba(244, 63, 94, 0.25);
  }
  .team-banner-head {
    display: flex; align-items: center; justify-content: space-between;
    font-size: 11.5px; font-weight: 800; letter-spacing: -0.01em;
    color: #DDD6FE; margin-bottom: 5px;
  }
  .team-banner.collision .team-banner-head { color: #FECDD3; }
  .team-banner-desc {
    font-size: 11px; line-height: 1.45; color: #94A3B8; margin-bottom: 10px;
  }
  .team-banner-desc b { color: #F3F4F6; }
  .team-actions-row {
    display: flex; gap: 6px; flex-wrap: wrap; align-items: center;
  }
  .team-btn {
    padding: 5px 10px;
    border-radius: 7px;
    font-size: 11px; font-weight: 700;
    cursor: pointer; border: 1px solid transparent;
    transition: all 0.15s ease;
    font-family: inherit; line-height: 1.2;
  }
  .team-btn-claim {
    background: linear-gradient(180deg, #8B5CF6, #7C3AED);
    color: #FFFFFF;
    box-shadow: 0 2px 8px rgba(139, 92, 246, 0.3);
  }
  .team-btn-claim:hover { filter: brightness(1.1); transform: translateY(-1px); }
  .team-btn-applied {
    background: #10B981; color: #0A0E14; font-weight: 800;
  }
  .team-btn-applied:hover { filter: brightness(1.1); transform: translateY(-1px); }
  .team-btn-pass {
    background: #1E2530; color: #94A3B8; border-color: #2E3846;
  }
  .team-btn-pass:hover { background: #2A3444; color: #F3F4F6; }
  .team-status-chip {
    display: inline-flex; align-items: center; gap: 5px;
    padding: 3px 8px; border-radius: 6px;
    font-size: 10.5px; font-weight: 700;
    background: rgba(139, 92, 246, 0.2); border: 1px solid rgba(139, 92, 246, 0.4);
    color: #C4B5FD;
  }
  .bid-intel-card {
    border-radius: 12px;
    background: #0E1218;
    border: 1px solid #1E2530;
    padding: 12px 14px;
    margin-top: 6px;
  }
  .bi-head {
    display: flex; align-items: center; justify-content: space-between;
    margin-bottom: 10px;
  }
  .bi-title {
    font-size: 12px; font-weight: 800; color: #F3F4F6;
  }
  .bi-badge {
    font-size: 10px; font-weight: 800; padding: 2px 7px; border-radius: 6px;
    border: 1px solid;
  }
  .bi-badge.c-brand { background: rgba(99,102,241,.15); color: #A5B4FC; border-color: rgba(99,102,241,.4); }
  .bi-badge.c-warn { background: rgba(245,158,11,.15); color: #FCD34D; border-color: rgba(245,158,11,.4); }
  .bi-badge.c-ok { background: rgba(16,185,129,.15); color: #6EE7B7; border-color: rgba(16,185,129,.4); }
  .bi-badge.c-danger { background: rgba(239,68,68,.15); color: #FCA5A5; border-color: rgba(239,68,68,.4); }
  .bi-stats-grid {
    display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px;
    margin-bottom: 8px;
  }
  .bi-stat {
    background: #131720; border: 1px solid #1C2330; border-radius: 8px;
    padding: 6px 8px; text-align: center;
  }
  .bi-stat small {
    display: block; font-size: 9px; font-weight: 700; color: #64748B; text-transform: uppercase;
  }
  .bi-stat b {
    font-size: 13px; font-weight: 900; color: #F1F5F9; font-family: ui-monospace, monospace;
  }
  .bi-desc {
    font-size: 11.5px; line-height: 1.4; color: #94A3B8; margin: 0;
  }
`,$n=`
  :host { all: initial; display: block; width: 100%; }
  * { box-sizing: border-box; font-family: Inter, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
  .card {
    margin: 10px 0;
    padding: 14px;
    background: #0D0F12;
    color: #F3F4F6;
    border: 1px solid rgba(16,185,129,.30);
    border-radius: 14px;
    box-shadow: 0 6px 24px rgba(0,0,0,.35);
    font-size: 12px; line-height: 1.45;
  }
  .top { display: flex; align-items: center; gap: 10px; }
  .tile {
    flex: none; width: 46px; height: 46px; border-radius: 12px;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    font-weight: 800; font-size: 17px; line-height: 1; font-variant-numeric: tabular-nums;
    border: 1px solid;
  }
  .tile small { font-size: 7px; font-weight: 700; letter-spacing: .1em; margin-top: 2px; opacity: .65; }
  .t-high   { background: rgba(16,185,129,.10); border-color: rgba(16,185,129,.45); box-shadow: 0 0 16px rgba(16,185,129,.20); }
  .t-medium { background: rgba(245,158,11,.10); border-color: rgba(245,158,11,.45); box-shadow: 0 0 16px rgba(245,158,11,.15); }
  .t-low    { background: rgba(239,68,68,.10); border-color: rgba(239,68,68,.45); box-shadow: 0 0 16px rgba(239,68,68,.15); }
  .t-nodata {
    background: #12151C;
    border-color: #262C37;
    color: #9CA3AF;
    box-shadow: none;
  }
  .brandline { min-width: 0; }
  .brandline b {
    display: block; font-size: 11px; letter-spacing: -.01em;
    background: linear-gradient(90deg, #34D399, #10B981);
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .brandline span { font-size: 10px; color: #9CA3AF; }
  .expand {
    margin-left: auto; flex: none;
    padding: 7px 12px; border-radius: 8px;
    background: linear-gradient(180deg, #34D399, #059669);
    border: none; cursor: pointer;
    color: #0D0F12; font-family: inherit;
    font-size: 11px; font-weight: 800;
    transition: all .15s ease;
    box-shadow: 0 3px 12px rgba(16,185,129,.28), inset 0 1px 0 rgba(255,255,255,.2);
  }
  .expand:hover { filter: brightness(1.08); transform: translateY(-1px); }
  .flags { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 11px; }
  .chip {
    padding: 3.5px 9px; border-radius: 999px;
    font-size: 10px; font-weight: 700; border: 1px solid;
    max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .c-danger { background: rgba(239,68,68,.08); color: #FCA5A5; border-color: rgba(239,68,68,.30); }
  .c-warn   { background: rgba(245,158,11,.08); color: #FCD34D; border-color: rgba(245,158,11,.30); }
  .c-ok     { background: rgba(16,185,129,.08); color: #6EE7B7; border-color: rgba(16,185,129,.30); }
  .rows { margin-top: 10px; border-top: 1px solid #171C25; }
  .r { display: flex; align-items: center; gap: 8px; padding: 6px 2px; border-bottom: 1px solid #171C25; }
  .r:last-child { border-bottom: none; }
  .r b:first-child { color: #CBD5E1; font-weight: 600; }
  .r .bar { height: 4px; border-radius: 999px; background: #1F242D; overflow: hidden; flex: 1; }
  .r .bar > i { display: block; height: 100%; background: linear-gradient(90deg, #059669, #34D399); }
  .r em { font-style: normal; font-weight: 700; font-variant-numeric: tabular-nums; color: #E5E7EB; }
  .r .na { color: #4B5563; font-size: 10.5px; }
  .name { margin-top: 10px; }
  .name span {
    display: inline-flex; align-items: center; gap: 7px;
    padding: 6px 12px; border-radius: 999px;
    background: rgba(16,185,129,.09); border: 1px solid rgba(16,185,129,.35);
    color: #6EE7B7; font-size: 12px; font-weight: 800;
  }
  .name small { font-weight: 700; opacity: .75; font-size: 10px; }
  .note {
    margin-top: 10px; padding-top: 9px;
    border-top: 1px solid #171C25;
    color: #93C5FD; font-size: 10.5px; line-height: 1.5;
  }
  .decision {
    margin-top: 11px; padding: 8px 10px; border: 1px solid; border-radius: 9px;
    display: flex; align-items: baseline; gap: 7px; flex-wrap: wrap;
    font-size: 10.5px; line-height: 1.35;
  }
  .decision-bid { background: rgba(16,185,129,.08); border-color: rgba(16,185,129,.35); color: #6EE7B7; }
  .decision-consider { background: rgba(245,158,11,.08); border-color: rgba(245,158,11,.30); color: #FCD34D; }
  .decision-skip { background: rgba(239,68,68,.08); border-color: rgba(239,68,68,.30); color: #FCA5A5; }
  .decision strong { letter-spacing: .08em; color: #F3F4F6; }
  .decision span { color: #CBD5E1; }
`;function w(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}let L=null,T=null,A=null,$=null,G=null,V=null,U=null;function N(){var t;if(!L||!A)return;(t=A.parentElement)==null||t.classList.remove("open");const e=L;if(window.setTimeout(()=>e.remove(),260),G&&(window.removeEventListener("keydown",G),G=null),V&&(document.removeEventListener("pointerdown",V,!0),V=null),U&&typeof U.focus=="function")try{U.focus()}catch{}U=null,L=null,T=null,A=null,$=null}function An(){return L!=null&&document.body.contains(L)}function Fn(){N()}function In(){try{const e=document.querySelector("header")??document.querySelector('[data-qa="nav-bar"]')??document.querySelector(".nav-container")??document.querySelector("nav");if(e){const t=e.getBoundingClientRect();if(t.bottom>30&&t.bottom<160)return Math.round(t.bottom)}}catch{}return 64}function _n(e,t){if(L&&T&&document.body.contains(L)){A==null||A.classList.toggle("collapsed",t);return}L&&L.remove(),U=document.activeElement??null;const n=In(),o=document.createElement("div");o.dataset.gigradarModal="",o.style.cssText=`position:fixed;inset:0;z-index:99999;pointer-events:none;--gr-top-offset:${n}px;`,T=o.attachShadow({mode:"closed"});const r=document.createElement("style");r.textContent=En;const a=document.createElement("div");if(a.className="wrap"+(e?" docked":"")+(t?" collapsed":""),!e){const s=document.createElement("div");s.className="backdrop",s.addEventListener("click",()=>N()),a.appendChild(s)}A=document.createElement("aside"),A.className="panel"+(e?" docked":"")+(t?" collapsed":""),A.setAttribute("role","dialog"),A.setAttribute("aria-modal","true"),A.setAttribute("aria-label","GigRadar Client Intel"),$=document.createElement("div"),$.className="body",A.appendChild($),a.appendChild(A),T.append(r,a),document.body.appendChild(o),L=o,requestAnimationFrame(()=>a.classList.add("open")),G=s=>{if(s.key==="Escape"){const i=T==null?void 0:T.activeElement;if(i&&(i.tagName==="INPUT"||i.tagName==="TEXTAREA")){i.blur();return}N();return}if(s.key==="Tab"&&T&&A){const i=Array.from(T.querySelectorAll('button:not([disabled]), [tabindex="0"]:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled])')).filter(b=>b.offsetParent!==null);if(i.length===0)return;const c=i[0],u=i[i.length-1];s.shiftKey&&T.activeElement===c?(s.preventDefault(),u.focus()):!s.shiftKey&&T.activeElement===u&&(s.preventDefault(),c.focus())}},window.addEventListener("keydown",G),V=s=>{e||L&&!s.composedPath().includes(L)&&N()},document.addEventListener("pointerdown",V,!0)}function Tn(e){return e.score.components.map(t=>{const n=t.value==null?null:`${Math.round(t.value*100)}%`;return`
        <tr>
          <td>${t.label}</td>
          <td>
            ${n?`<div class="bar"><i style="width:${n}"></i></div>`:'<span class="na">no data on page</span>'}
          </td>
          <td class="val ${t.display==null?"na":""}">
            ${t.display??"—"}
          </td>
        </tr>`}).join("")}function Ln(e){return e.flags.length===0?'<li class="flag-ok">✓ No red flags detected on this page.</li>':e.flags.map(t=>`<li class="flag-${t.level==="danger"?"danger":"warn"}">${t.level==="danger"?"🚨 ":"⚠️ "}${w(t.text)}</li>`).join("")}function Rn(e){const t=e.activity;if(!t)return"";const n=(o,r)=>`
    <div class="act-cell"><span>${r??"—"}</span><small>${o}</small></div>`;return`
    <h3 class="sec">Activity radar</h3>
    <div class="activity-grid">
      ${n("Proposals",t.proposalsCount)}
      ${n("Interviewing",t.interviewingCount)}
      ${n("Invites sent",t.invitesSentCount)}
      ${n("Unanswered",t.unansweredInvitesCount)}
    </div>`}function Dn(e){const t=e.trueRate,n=e.budget;if(!t||t.medianHourlyUsd==null&&t.avgFixedUsd==null)return"";const o=[],r=[];t.medianHourlyUsd!=null&&(o.push(`<div class="tr-row"><b>True Median Rate</b><em>$${t.medianHourlyUsd.toFixed(2)}/hr</em></div>`),(n==null?void 0:n.type)==="hourly"&&n.maxUsd!=null&&n.maxUsd>0&&r.push(n.maxUsd>=t.medianHourlyUsd*1.5?`<span class="chip c-danger">⚠ Listed $${n.maxUsd%1===0?n.maxUsd.toFixed(0):n.maxUsd.toFixed(2)}/hr is inflated vs what they actually pay</span>`:'<span class="chip c-ok">Listed rate in line with payout history</span>')),t.avgFixedUsd!=null&&o.push(`<div class="tr-row"><b>Avg Fixed Payout</b><em>$${Math.round(t.avgFixedUsd).toLocaleString("en-US")}</em></div>`);const a=t.sampleCount>0?`<div class="tr-chips"><span class="chip c-ok">${t.sampleCount} past contract${t.sampleCount===1?"":"s"} analyzed</span>${r.join("")}</div>`:r.length>0?`<div class="tr-chips">${r.join("")}</div>`:"";return`
    <h3 class="sec">True Rate benchmark</h3>
    <div class="tr-block">${o.join("")}${a}</div>`}function jn(e){var n;const t=(n=e.dossier)==null?void 0:n.company;return!t||!t.name&&!t.domain?"":`
    <div class="company-pill-row">
      ${t.name?`<span class="company-tag" title="Identified Organization">🏢 ${w(t.name)}</span>`:""}
      ${t.domain?`<a href="https://${w(t.domain)}" target="_blank" rel="noopener noreferrer" class="domain-tag" title="Visit Website">🌐 ${w(t.domain)} ↗</a>`:""}
    </div>`}function zn(e){const t=e.dossier;if(!t)return"";const n=t.reviewRedFlags;return n.length>0?`
      <div class="watchout-box">
        <div class="watchout-header">
          <span class="watchout-badge">⚠ WATCH OUT (${n.length} Review Red Flag${n.length===1?"":"s"})</span>
          <span class="watchout-sub">Direct quotes from past freelancer feedback</span>
        </div>
        <div class="watchout-list">
          ${n.map(o=>`
            <div class="watchout-card">
              <div class="watchout-card-top">
                <span class="watchout-cat">${w(o.label)}</span>
                ${o.rating!=null?`<span class="watchout-star">★ ${o.rating.toFixed(1)}</span>`:""}
              </div>
              <p class="watchout-quote">"${w(o.snippet)}"</p>
            </div>`).join("")}
        </div>
      </div>`:e.meta.feedbacks.length>0?`
      <div class="watchout-box clean">
        <div class="watchout-clean-text">
          <span class="clean-icon">✓</span>
          <span><b>Clean Review Record:</b> 0 disputes or red flags across ${e.meta.feedbacks.length} client feedback entries.</span>
        </div>
      </div>`:""}function Pn(e){const t=e.dossier;if(!t)return"";const n=t.techStack.length>0?`
        <h3 class="sec">Tech Stack & Tools</h3>
        <div class="tech-stack-row">
          ${t.techStack.map(r=>`<span class="tech-chip">⚙ ${w(r)}</span>`).join("")}
        </div>`:"",o=t.praiseHighlights.length>0?`
        <h3 class="sec">Client Strengths & Praise</h3>
        <div class="praise-row">
          ${t.praiseHighlights.map(r=>`<span class="praise-chip">${w(r)}</span>`).join("")}
        </div>`:"";return`${n}${o}`}function Mn(){return`
    <h3 class="sec">✨ AI Client Dossier</h3>
    <div id="gr-dossier-card" class="dossier-card">
      <div class="dossier-intro">
        <span>Instant tactical briefing synthesized directly via your BYOK key.</span>
        <button id="gr-dossier-btn" class="dossier-btn" type="button">✨ Synthesize Dossier</button>
      </div>
      <div id="gr-dossier-content" class="dossier-content" style="display: none;"></div>
      <div id="gr-dossier-gate" style="display: none;"></div>
      <div id="gr-dossier-err" class="err"></div>
    </div>`}function Bn(e,t){const n=e.querySelector("#gr-dossier-btn"),o=e.querySelector("#gr-dossier-content"),r=e.querySelector("#gr-dossier-gate"),a=e.querySelector("#gr-dossier-err");if(!n||!o||!r||!a)return;const s=async()=>{var c,u,b,d,m,g,p;n.disabled=!0;const i=n.textContent;n.textContent="Synthesizing…";try{const l=await Lt({title:t.meta.title,description:t.meta.descriptionSnippet,hireRatePct:t.signals.hireRatePct,totalSpendUsd:t.signals.totalSpendUsd,ratingAvg:((c=t.rating)==null?void 0:c.avg)??null,ratingCount:((u=t.rating)==null?void 0:u.count)??null,companyName:((d=(b=t.dossier)==null?void 0:b.company)==null?void 0:d.name)??null,companyDomain:((g=(m=t.dossier)==null?void 0:m.company)==null?void 0:g.domain)??null,techStack:((p=t.dossier)==null?void 0:p.techStack)??[],feedbacks:t.meta.feedbacks});l.ok?(o.style.display="block",o.innerHTML=w(l.text).replace(/\n/g,"<br>")):a.textContent=l.text}catch(l){a.textContent=String(l instanceof Error?l.message:l)}finally{n.disabled=!1,n.textContent=i}};n.addEventListener("click",async()=>{var c,u;a.textContent="",r.style.display="none";const i=await Ye();if(!i.enabled||!i.apiKey){r.style.display="block",n.style.display="none",r.innerHTML=`
        <div class="dossier-gate-box">
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;">
            <b style="color:#38BDF8;font-size:11.5px;">⚡ Quick AI Key Setup</b>
            <div style="display:flex;align-items:center;gap:6px;">
              <button type="button" class="dossier-settings-btn" style="margin:0;padding:2px 7px;font-size:10px;">Full Settings ↗</button>
              <button type="button" id="gr-inline-cancel" title="Cancel" style="background:transparent;border:none;color:#64748B;cursor:pointer;font-size:12px;padding:0 3px;line-height:1;">✕</button>
            </div>
          </div>
          <div style="color:#94A3B8;font-size:10.5px;line-height:1.4;margin-bottom:8px;">
            Paste your OpenAI or Anthropic API key to synthesize instant client briefings with zero credit fees.
          </div>
          <div style="display:flex;gap:5px;align-items:center;">
            <select id="gr-inline-provider" style="background:#090C10;border:1px solid #232D3F;color:#E2E8F0;border-radius:6px;padding:5px 6px;font-size:11px;font-family:inherit;">
              <option value="openai">OpenAI</option>
              <option value="anthropic">Anthropic</option>
            </select>
            <input id="gr-inline-key" type="password" placeholder="Paste sk-..." autocomplete="off" spellcheck="false" style="flex:1;min-width:0;background:#090C10;border:1px solid #232D3F;color:#E2E8F0;border-radius:6px;padding:5px 8px;font-size:11px;font-family:monospace;" />
            <button id="gr-inline-save" type="button" style="background:linear-gradient(180deg,#34D399,#059669);border:none;border-radius:6px;padding:5px 11px;font-size:11px;font-weight:800;color:#07090C;cursor:pointer;white-space:nowrap;">
              Save & Run
            </button>
          </div>
          <div id="gr-inline-err" style="color:#F87171;font-size:10px;margin-top:4px;display:none;"></div>
        </div>`,(c=r.querySelector("#gr-inline-cancel"))==null||c.addEventListener("click",()=>{r.style.display="none",n.style.display="inline-flex"}),(u=r.querySelector(".dossier-settings-btn"))==null||u.addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_OPTIONS"})});const b=r.querySelector("#gr-inline-save"),d=r.querySelector("#gr-inline-key"),m=r.querySelector("#gr-inline-provider"),g=r.querySelector("#gr-inline-err");window.setTimeout(()=>d==null?void 0:d.focus(),50),d==null||d.addEventListener("keydown",p=>{p.key==="Enter"&&(p.preventDefault(),b==null||b.click())}),b==null||b.addEventListener("click",async()=>{const p=(d==null?void 0:d.value.trim())??"",l=(m==null?void 0:m.value)??"openai";if(p.length<10){g&&(g.style.display="block",g.textContent="Please paste a valid API key (e.g. sk-...)");return}await At({enabled:!0,provider:l,apiKey:p}),r.style.display="none",n.style.display="inline-flex",await s()});return}await s()})}function Hn(e){if(e.meta.feedbacks.length===0)return`<p class="hint">Open the full job post to scan past client feedback for the client's first name.</p>`;if(!e.nameGuess)return`<p class="hint">Feedback scanned (${e.meta.feedbacks.length} entries) — no confident name match found. Better skip the personalization than guess wrong.</p>`;const t=Math.round(e.nameGuess.confidence*100),n=e.nameGuess.alternates.length>0?`<small>Also mentioned: ${w(e.nameGuess.alternates.join(", "))}</small>`:"";return`
    <div class="name-row">
      <span class="name-chip">👤 ${w(e.nameGuess.name)}
        <span class="conf">${t}% confidence · ${e.nameGuess.votes} mention${e.nameGuess.votes===1?"":"s"}</span>
      </span>
      <button id="gr-name-copy" class="mini-copy" type="button">📋 Copy</button>
    </div>${n}`}async function Nn(e){try{const t=await Ye();e.hidden=!(t.enabled&&t.apiKey)}catch{e.hidden=!0}}function qn(e,t){const n=e.querySelector("#gr-hooks-free"),o=e.querySelector("#gr-hooks-pro-list"),r=e.querySelector("#gr-ai-polish"),a=e.querySelector("#gr-hooks-err");if(!n||!o||!r||!a)return;let s=[],i=0;function c(d){return d===0?n.querySelector(".ho-text"):o.querySelector(`.hook-opt:nth-of-type(${d}) .ho-text`)}function u(){var m,g;if(s=Ft({jobId:t.meta.jobId,title:t.meta.title,description:t.meta.descriptionSnippet,clientName:((m=t.nameGuess)==null?void 0:m.name)??null,techStack:((g=t.dossier)==null?void 0:g.techStack)??[]}),s.length>0){const p=s[0];n.innerHTML=`
        <div class="hook-opt">
          <div class="ho-head"><b>Option ${w(p.label)}</b><span>${w(p.style)} · Free</span></div>
          <p class="ho-text"></p>
          <div class="ho-foot">
            <button class="act primary ho-copy" data-i="0" type="button">📋 Copy Hook</button>
          </div>
        </div>`;const l=n.querySelector(".ho-text");l&&(l.textContent=p.text)}else n.innerHTML="";const d=s.slice(1);d.length>0?(o.innerHTML=d.map((p,l)=>`
          <div class="hook-opt">
            <div class="ho-head"><b>Option ${w(p.label)}</b><span>${w(p.style)}</span></div>
            <p class="ho-text"></p>
            <div class="ho-foot">
              <button class="act primary ho-copy" data-i="${l+1}" type="button">📋 Copy Hook</button>
            </div>
          </div>`).join(""),d.forEach((p,l)=>{const y=o.querySelector(`.hook-opt:nth-of-type(${l+1}) .ho-text`);y&&(y.textContent=p.text)})):o.innerHTML="",b()}function b(){e.querySelectorAll(".ho-copy").forEach(d=>{d.addEventListener("click",async()=>{const m=Number(d.dataset.i),g=s[m];if(g){i=m;try{await navigator.clipboard.writeText(g.text),d.textContent="✓ Copied!",d.classList.add("copied"),window.setTimeout(()=>{d.textContent="📋 Copy Hook",d.classList.remove("copied")},1400)}catch{a.textContent="Clipboard blocked by browser permissions."}}})})}r.addEventListener("click",async()=>{var p,l,y;const d=Math.max(i,0),m=s[d];if(!m)return;a.textContent="",r.disabled=!0;const g=r.textContent;r.textContent="Polishing…";try{const h=await $t(m.text,{title:t.meta.title,description:t.meta.descriptionSnippet,clientName:((p=t.nameGuess)==null?void 0:p.name)??null,techStack:((l=t.dossier)==null?void 0:l.techStack)??[],budget:t.budget?t.budget.type==="hourly"?`$${t.budget.minUsd}-$${t.budget.maxUsd}/hr`:`$${t.budget.maxUsd} fixed`:null,trueRate:((y=t.trueRate)==null?void 0:y.medianHourlyUsd)??null});if(h.ok){m.text=h.text;const S=c(d);S&&(S.textContent=h.text)}else a.textContent=h.text}catch(h){a.textContent=String(h instanceof Error?h.message:h)}finally{r.disabled=!1,r.textContent=g}}),Nn(r),u()}const Un="https://www.upwork.com/ab/account/security/login";function rt(){const e=['a[href*="/account/security/login"]','a[href*="/account/login"]','a[href*="/users/login"]','a[href*="/users/signup"]','a[data-qa="nav-login"]','[data-qa*="login" i]','[data-qa*="sign-up" i]','[data-qa*="signup" i]','[data-test*="login" i]'].join(", ");try{if(document.querySelector(e)!=null)return!0;const t=document.querySelectorAll('header a, header button, nav a, nav button, [role="banner"] a, [role="banner"] button');for(const n of Array.from(t)){const o=(n.textContent??"").trim().toLowerCase();if(o==="log in"||o==="sign in"||o==="sign up")return!0}}catch{return!1}return!1}function On(e,t,n){const o=e.querySelector("#gr-team-collision-container");if(!o||!t.meta.jobId)return;const r=async()=>{var i,c,u,b;const a=await Rt(),s=await Dt(t.meta.jobId);if(a!=="agency"&&!s.isClaimed){o.innerHTML="",o.style.display="none";return}if(o.style.display="block",s.isClaimed&&!s.isCurrentMember){const d=s.activity,m=ge(d.updatedAt),g=d.status==="applied"?"team_member_applied":d.status==="drafting"?"team_member_drafting":"team_member_viewing",p=f(g,n);o.innerHTML=`
        <div class="team-banner collision">
          <div class="team-banner-head">
            <span>🚨 ${f("team_collision_warning",n)}</span>
            <span class="team-status-chip">${d.status.toUpperCase()}</span>
          </div>
          <div class="team-banner-desc">
            Teammate <b>${w(d.memberName)}</b> ${w(p)} (${w(m)}).
            Submitting another proposal will double-spend Connects.
          </div>
          <div class="team-actions-row">
            <button type="button" id="gr-team-claim-btn" class="team-btn team-btn-claim">
              ${f("claim_job_btn",n)}
            </button>
            <button type="button" id="gr-team-applied-btn" class="team-btn team-btn-applied">
              ${f("mark_applied_btn",n)}
            </button>
            <button type="button" id="gr-team-pass-btn" class="team-btn team-btn-pass">
              ${f("pass_job_btn",n)}
            </button>
          </div>
        </div>`}else if(s.isClaimed&&s.isCurrentMember){const d=s.activity,m=ge(d.updatedAt);o.innerHTML=`
        <div class="team-banner">
          <div class="team-banner-head">
            <span>👥 Team Lead Tracker: Claimed by You</span>
            <span class="team-status-chip">${d.status.toUpperCase()}</span>
          </div>
          <div class="team-banner-desc">
            You marked this job as <b>${w(d.status)}</b> (${w(m)}). Other team members see you are active.
          </div>
          <div class="team-actions-row">
            ${d.status!=="applied"?`<button type="button" id="gr-team-applied-btn" class="team-btn team-btn-applied">
                    ${f("mark_applied_btn",n)}
                  </button>`:""}
            <button type="button" id="gr-team-pass-btn" class="team-btn team-btn-pass">
              ${f("pass_job_btn",n)}
            </button>
          </div>
        </div>`}else o.innerHTML=`
        <div class="team-banner">
          <div class="team-banner-head">
            <span>👥 Agency Team Pipeline</span>
            <span style="font-size:10px;color:#94A3B8;font-weight:600;">UNASSIGNED</span>
          </div>
          <div class="team-banner-desc">
            Claim this job to notify teammates and prevent duplicate proposals.
          </div>
          <div class="team-actions-row">
            <button type="button" id="gr-team-claim-btn" class="team-btn team-btn-claim">
              ${f("claim_job_btn",n)}
            </button>
            <button type="button" id="gr-team-applied-btn" class="team-btn team-btn-applied">
              ${f("mark_applied_btn",n)}
            </button>
            <button type="button" id="gr-team-webhook-btn" class="team-btn" style="background:#4F46E5;color:#FFFFFF;">
              📡 ${f("sync_webhook_btn",n)}
            </button>
          </div>
        </div>`;(i=o.querySelector("#gr-team-claim-btn"))==null||i.addEventListener("click",async d=>{var m;d.stopPropagation(),await Re({jobId:t.meta.jobId,jobTitle:t.meta.title,status:"drafting",jobUrl:t.meta.url,clientName:((m=t.nameGuess)==null?void 0:m.name)??void 0,dealValueUsd:Q(t.budget),budget:t.budget,hireRatePct:t.signals.hireRatePct,totalSpendUsd:t.signals.totalSpendUsd,paymentVerified:t.signals.paymentVerified}),await r()}),(c=o.querySelector("#gr-team-applied-btn"))==null||c.addEventListener("click",async d=>{var m;d.stopPropagation(),await Re({jobId:t.meta.jobId,jobTitle:t.meta.title,status:"applied",jobUrl:t.meta.url,clientName:((m=t.nameGuess)==null?void 0:m.name)??void 0,dealValueUsd:Q(t.budget),budget:t.budget,hireRatePct:t.signals.hireRatePct,totalSpendUsd:t.signals.totalSpendUsd,paymentVerified:t.signals.paymentVerified}),await r()}),(u=o.querySelector("#gr-team-webhook-btn"))==null||u.addEventListener("click",async d=>{var p,l;d.stopPropagation();const m=d.currentTarget;m.disabled=!0;const g=m.textContent;m.textContent="⏳ Syncing...",await jt({eventType:Q(t.budget)>=1e3?"high_value_lead":"job_claimed",jobId:t.meta.jobId,jobTitle:t.meta.title,jobUrl:t.meta.url,clientName:((p=t.nameGuess)==null?void 0:p.name)??void 0,dealValueUsd:Q(t.budget),budget:t.budget,hireRatePct:t.signals.hireRatePct,totalSpendUsd:t.signals.totalSpendUsd,paymentVerified:!!t.signals.paymentVerified,memberName:"You (Agency BD)",status:((l=s.activity)==null?void 0:l.status)||"drafting",timestamp:Date.now()}),m.textContent="✅ Synced!",setTimeout(()=>{m.textContent=g,m.disabled=!1},1800)}),(b=o.querySelector("#gr-team-pass-btn"))==null||b.addEventListener("click",async d=>{d.stopPropagation(),await zt(t.meta.jobId),await r()})};r()}function Gn(e,t){const n=Et({budget:e.budget,clientHireRatePct:e.signals.hireRatePct,clientPaymentVerified:e.signals.paymentVerified,clientTotalSpendUsd:e.signals.totalSpendUsd,proposalCount:e.meta.proposalCount}),o=n.strategy==="AGGRESSIVE_TOP_SLOT"?"c-warn":n.strategy==="TACTICAL_BOOST"?"c-brand":n.strategy==="ORGANIC_SWEET_SPOT"?"c-ok":"c-danger",r=n.strategy==="AGGRESSIVE_TOP_SLOT"?"bid_strategy_aggressive":n.strategy==="TACTICAL_BOOST"?"bid_strategy_tactical":n.strategy==="ORGANIC_SWEET_SPOT"?"bid_strategy_organic":"bid_strategy_skip";return`
    <h3 class="sec">📈 ${f("bid_intel_title",t)}</h3>
    <div class="bid-intel-card">
      <div class="bi-head">
        <span class="bi-title">🎯 ${f(r,t)}</span>
        <span class="bi-badge ${o}">${n.roiRatio}x ROI</span>
      </div>
      <div class="bi-stats-grid">
        <div class="bi-stat">
          <small>${f("win_probability_label",t)}</small>
          <b>${n.winProbabilityPct}%</b>
        </div>
        <div class="bi-stat">
          <small>${f("expected_value_label",t)}</small>
          <b style="color:#60A5FA;">+${n.expectedValueUsd>0?"$":""}${n.expectedValueUsd.toFixed(0)}</b>
        </div>
        <div class="bi-stat">
          <small>${f("optimal_bid_label",t)}</small>
          <b style="color:#A5B4FC;">${n.recommendedBid}c</b>
        </div>
      </div>
      <p class="bi-desc">${w(n.verdictSummary)}</p>
    </div>`}function Vn(e){return`
    <div id="gr-autopilot-card" class="autopilot-card">
      <div class="ap-header">
        <span class="ap-title">🚀 ${f("autopilot_title",e)}</span>
        <span class="ap-badge">AUTOPILOT</span>
      </div>
      <div id="gr-ap-case-chip" class="ap-case-chip">
        <small>${f("matched_case_study_label",e)}:</small>
        <b id="gr-ap-study-title">Searching portfolio…</b>
        <span id="gr-ap-study-metrics"></span>
      </div>
      <div class="ap-tone-bar">
        <select id="gr-ap-tone-select" class="ap-tone-select">
          <option value="direct_engineer">${f("tone_direct",e)}</option>
          <option value="consultative_partner">${f("tone_consultative",e)}</option>
          <option value="velocity_exec">${f("tone_velocity",e)}</option>
          <option value="custom">${f("tone_custom",e)}</option>
        </select>
      </div>
      <pre id="gr-ap-preview" class="ap-proposal-preview">Generating 4-part proposal…</pre>
      <div class="ap-actions">
        <button id="gr-ap-copy-btn" class="ap-btn-copy" type="button">📋 ${f("copy_full_proposal_btn",e)}</button>
        <button id="gr-ap-polish-btn" class="ap-btn-polish" type="button" title="${f("ai_polish_proposal_btn",e)}">${f("ai_polish_proposal_btn",e)}</button>
      </div>
    </div>`}function Kn(e,t,n){const o=e.querySelector("#gr-autopilot-card"),r=e.querySelector("#gr-ap-study-title"),a=e.querySelector("#gr-ap-study-metrics"),s=e.querySelector("#gr-ap-tone-select"),i=e.querySelector("#gr-ap-preview"),c=e.querySelector("#gr-ap-copy-btn"),u=e.querySelector("#gr-ap-polish-btn");if(!o||!r||!a||!s||!i||!c||!u)return;let b=null,d={...It};const m=async g=>{var p,l,y;try{d=await _t(),g&&(d.tone=g),s.value=d.tone;const h=await Tt({title:t.meta.title,description:t.meta.descriptionSnippet,techStack:((p=t.dossier)==null?void 0:p.techStack)??[]});h.matched?(r.textContent=`💼 ${h.matched.title}`,a.textContent=h.matched.metricsOutcome):(r.textContent=`⚡ ${f("no_case_study_matched",n)}`,a.textContent="Injecting proven enterprise delivery benchmarks."),b=await Zt({jobMeta:{jobId:t.meta.jobId,title:t.meta.title,descriptionSnippet:t.meta.descriptionSnippet},clientName:((l=t.nameGuess)==null?void 0:l.name)??null,techStack:((y=t.dossier)==null?void 0:y.techStack)??[],voiceProfile:d,caseStudy:h.matched}),i.textContent=b.fullText}catch{i.textContent="Ready to generate full proposal."}};s.addEventListener("change",()=>{m(s.value)}),c.addEventListener("click",async()=>{if(b)try{await navigator.clipboard.writeText(b.fullText),c.textContent=`✓ ${f("proposal_copied",n)}`,c.classList.add("copied"),setTimeout(()=>{c.textContent=`📋 ${f("copy_full_proposal_btn",n)}`,c.classList.remove("copied")},1500)}catch{}}),u.addEventListener("click",async()=>{var g,p;if(b){u.disabled=!0,u.textContent="Polishing…";try{const l=await Jt({jobMeta:{jobId:t.meta.jobId,title:t.meta.title,descriptionSnippet:t.meta.descriptionSnippet},clientName:((g=t.nameGuess)==null?void 0:g.name)??null,techStack:((p=t.dossier)==null?void 0:p.techStack)??[],voiceProfile:d,caseStudy:b.matchedCaseStudyId?{id:b.matchedCaseStudyId,title:b.matchedCaseStudyTitle??"",tags:[],problemSolved:"",metricsOutcome:b.caseStudyInjection,updatedAt:0}:null});l.ok&&l.proposal?(b=l.proposal,i.textContent=l.proposal.fullText,u.textContent="✓ Polished"):u.textContent="AI Key Needed"}catch{u.textContent="AI Key Needed"}finally{setTimeout(()=>{u.disabled=!1,u.textContent="✨ Polish"},1800)}}}),m()}function R(e,t={}){var C,k;const n=t.locale||Se;e.meta.feedbacks.length>0&&!e.nameGuess&&(e.nameGuess=de(e.meta.feedbacks)),e.dossier||(e.dossier=X({feedbacks:e.meta.feedbacks,description:`${e.meta.title}
${e.meta.descriptionSnippet}`,contractTitles:[e.meta.title]}));const o=t.docked===!0,r=o&&(t.collapsed===!0||window.innerWidth<1024&&t.expanded!==!0);if(_n(o,r),!$||!A||!T)return;const a=$.scrollTop;(C=A.querySelector(".gr-head"))==null||C.remove(),$.innerHTML="";const s=e.score.scored,i=t.scanning===!0,c=ot({signals:e.signals,score:e.score,flags:e.flags,proposalCount:e.meta.proposalCount}),u=!s&&!t.settled,b=!i&&s?`tier-${e.score.tier.toLowerCase()}`:"tier-nodata",d=!i&&s?`${e.score.score}`:"--",m=i?"SCANNING":s?"SCORE":u?"SCANNING":"NO DATA",g=document.createElement("div");g.className="gr-head head",g.innerHTML=`
    <div class="score-ring ${b}">
      ${d}<small>${m}</small>
    </div>
    <div style="min-width:0;flex:1;">
      <p class="job-title"></p>
      <p class="job-sub">${w(Wn(e))}</p>
      ${jn(e)}
    </div>
    <div class="head-actions">
      <button class="settings-btn" title="Open Extension Settings" aria-label="Open Extension Settings">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/>
          <circle cx="12" cy="12" r="3"/>
        </svg>
      </button>
      <button class="close-btn" title="Close" aria-label="Close">✕</button>
    </div>`,g.querySelector(".job-title").textContent=e.meta.title,g.querySelector(".close-btn").addEventListener("click",()=>N()),g.querySelector(".settings-btn").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"OPEN_OPTIONS"})}),A.insertBefore(g,$);const p=!e.score.scored&&rt()?'<div class="guest-note"><span><b>Guest mode detected</b> — log in to Upwork so client history becomes visible.</span><button id="gr-guest-login" class="guest-link" type="button">Log in</button></div>':"",l=u?'<div class="scan-note"><i></i>Reading the client sidebar — live numbers land here in a moment…</div>':"";$.innerHTML=`
    ${p}
    ${l}
    <div id="gr-team-collision-container"></div>
    ${i?"":`<div class="decision decision-${c.action.toLowerCase()}" aria-live="polite">
      <div class="decision-top"><strong>${c.action}</strong><span>${w(c.summary)}</span></div>
      <div class="decision-reasons">${c.reasons.map(E=>`<span>${w(E)}</span>`).join("")}</div>
      <p>${w(c.recommendation)}</p>
    </div>`}

    <div id="gr-roi-card" class="roi-card">
      <div class="roi-header">
        <span class="roi-title">🛡️ ${f("connects_saved_roi_title",n)}</span>
        <span id="gr-roi-badge" class="roi-badge"></span>
      </div>
      <p id="gr-roi-stat" class="roi-stat"></p>
    </div>

    ${zn(e)}

    <h3 class="sec">${f("drawer_signals",n)}</h3>
    <table class="signals"><tbody>${Tn(e)}</tbody></table>

    ${Rn(e)}
    ${Dn(e)}

    <h3 class="sec">${f("red_flags_title",n)}</h3>
    <ul class="flags">${Ln(e)}</ul>

    <h3 class="sec">${f("drawer_client_name",n)}</h3>
    <div id="gr-name" class="gate">${Hn(e)}</div>

    ${Pn(e)}

    <h3 class="sec">⚡ ${f("drawer_proposal_hooks",n)}</h3>
    <div class="row ho-toolbar">
      <span class="hint">${f("hooks_subtitle",n)}</span>
      <button id="gr-ai" class="act" hidden>✨ AI Polish</button>
    </div>
    <div id="gr-hooks-free"></div>
    <div id="gr-hooks-pro" class="gate" style="margin-top: 10px;">
      <div class="pro-hook-header">
        <span>${f("pro_variants_title",n)}</span>
        <span class="pro-hook-tag">PRO</span>
      </div>
      <div id="gr-hooks-pro-list"></div>
    </div>
    <div id="gr-hook-err" class="err"></div>

    ${Vn(n)}

    ${Gn(e,n)}

    ${Mn()}`;const y=$;Vt().then(E=>{if(!y)return;const F=y.querySelector("#gr-roi-badge"),v=y.querySelector("#gr-roi-stat");if(!F||!v)return;const I=E*Kt,B=c.action==="SKIP";if(E>0)if(I>=9.99){const P=(I/9.99).toFixed(1);F.textContent=`⚡ ${P}x ROI`,v.innerHTML=`Protected <b>${E} Connects</b> (<span class="roi-highlight">~$${I.toFixed(2)}</span> saved). Paid for Pro <b>${P}x over</b>.`}else{const P=Math.round(I/9.99*100);F.textContent=`⚡ ${P}% of Pro`,v.innerHTML=`Protected <b>${E} Connects</b> (<span class="roi-highlight">~$${I.toFixed(2)}</span> saved) — <b>${P}%</b> of the $9.99 Pro license recovered.`}else F.textContent=B?"+$1.20 Value":"$0.15/Connect",B?v.innerHTML='Skipping this low-intent job protects <b>~8 Connects</b> (<span class="roi-highlight">~$1.20</span>) from being wasted.':v.innerHTML="Skipping flagged ghost jobs protects <b>~8 Connects ($1.20)</b> each. ROI updates as you browse."}),(k=$.querySelector("#gr-guest-login"))==null||k.addEventListener("click",()=>{window.location.href=Un});const h=$.querySelector("#gr-name-copy");if(h&&e.nameGuess){const E=e.nameGuess.name;h.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(E),h.textContent="✓ Copied!",h.classList.add("copied"),window.setTimeout(()=>{h.textContent="📋 Copy",h.classList.remove("copied")},1200)}catch{window.setTimeout(()=>{h.textContent="📋 Copy"},600)}})}qn($,e),Kn($,e,n),Bn($,e),On($,e,n),$.scrollTop=a;const S=[$.querySelector("#gr-name"),$.querySelector("#gr-hooks-pro")];Ot().then(E=>{for(const F of S){if(!F||E)continue;F.classList.add("locked");const v=document.createElement("div");v.className="lock-overlay";const I=document.createElement("button");I.className="pro-btn",I.textContent=`${f("drawer_pro_required",n)} — ${Gt} ${f("early_bird",n)}`,I.addEventListener("click",P=>{P.stopPropagation(),M()&&chrome.runtime.sendMessage({type:"OPEN_OPTIONS"}).catch(()=>{}),N()});const B=document.createElement("span");B.className="paywall-note",B.textContent=f("pro_price_note",n),v.appendChild(I),v.appendChild(B),F.appendChild(v)}}).catch(()=>{})}function Yn(e){return e?e.replace(/\s*[-–—]?\s*proposals?:?.*$/i,"").replace(/\s*[-–—]\s*$/,"").trim():""}function Wn(e){const t=[];e.rating&&t.push(`★ ${e.rating.avg.toFixed(2)} (${e.rating.count} reviews)`);const n=Yn(e.meta.postedText);n&&t.push(n);const o=/[^\n]*\bproposals?:?\s*([0-9]+(?:\s*(?:to|-|–)\s*[0-9]+|\+)?)/i.exec(e.meta.postedText??"");return o!=null&&o[1]?t.push(`Proposals: ${o[1].trim()}`):e.meta.proposalCount!=null&&t.push(`${e.meta.proposalCount}+ proposals`),t.join(" · ")}function Ee(e,t,n){var S,C,k,E,F;t.meta.feedbacks.length>0&&!t.nameGuess&&(t.nameGuess=de(t.meta.feedbacks)),t.dossier||(t.dossier=X({feedbacks:t.meta.feedbacks,description:`${t.meta.title}
${t.meta.descriptionSnippet}`,contractTitles:[t.meta.title]}));const o=e.querySelector("[data-gigradar-inline]"),r=document.createElement("div");r.dataset.gigradarInline="",r.dataset.gigradarJobId=t.meta.jobId,r.style.cssText="display:block;width:100%";const a=r.attachShadow({mode:"closed"}),s=document.createElement("style");s.textContent=$n;const i=document.createElement("div");i.className="card";const c=(S=t.dossier)!=null&&S.reviewRedFlags&&t.dossier.reviewRedFlags.length>0?`<span class="chip c-danger" title="Disputes or issues flagged in reviews">⚠ ${t.dossier.reviewRedFlags.length} Review Flag${t.dossier.reviewRedFlags.length===1?"":"s"}</span>`:"",u=t.flags.length>0||c?`<div class="flags">${c}${t.flags.slice(0,3).map(v=>`<span class="chip c-${v.level}" title="${w(v.text)}">${v.level==="danger"?"⚠":"•"} ${w(v.text)}</span>`).join("")}</div>`:'<div class="flags"><span class="chip c-ok">No red flags detected</span></div>',b=t.score.components.map(v=>{const I=v.value==null?null:`${Math.round(v.value*100)}%`;return`
        <div class="r">
          <b>${v.label}</b>
          ${I?`<span class="bar"><i style="width:${I}"></i></span><em>${v.display??""}</em>`:'<span class="na">no data on page</span><em>—</em>'}
        </div>`}).join(""),d=t.nameGuess!=null?`<div class="name"><span>${w(t.nameGuess.name)}<small>${Math.round(t.nameGuess.confidence*100)}% · ${t.nameGuess.votes}×</small></span></div>`:"",m=!t.score.scored&&rt()?'<div class="note">Guest mode — log in to Upwork for client intel</div>':"",g=t.score.scored,p=ot({signals:t.signals,score:t.score,flags:t.flags,proposalCount:t.meta.proposalCount}),l=g?`t-${t.score.tier.toLowerCase()}`:"t-nodata",y=g?`${t.score.score}`:"--",h=g?"SCORE":"NO DATA";return i.innerHTML=`
    <div class="top">
      <div class="tile ${l}">
        ${y}<small>${h}</small>
      </div>
      <div class="brandline">
        <b>GigRadar Client Intel</b>
        <span>${w(t.score.tier)} intent${t.rating?` · ★ ${t.rating.avg.toFixed(2)} (${t.rating.count})`:""}${t.meta.proposalCount!=null?` · ${t.meta.proposalCount}+ proposals`:""}</span>
        ${(k=(C=t.dossier)==null?void 0:C.company)!=null&&k.name||(F=(E=t.dossier)==null?void 0:E.company)!=null&&F.domain?`
          <div style="font-size:10px;font-weight:700;color:#34D399;margin-top:2px;">
            🏢 ${w(t.dossier.company.name||t.dossier.company.domain)}
          </div>`:""}
      </div>
      <button class="expand" type="button">Full Intel ▸</button>
    </div>
    <div class="decision decision-${p.action.toLowerCase()}">
      <strong>${p.action}</strong><span>${w(p.summary)}</span>
    </div>
    ${u}
    <div class="rows">${b}</div>
    ${d}
    ${m}`,i.querySelector(".expand").addEventListener("click",v=>{v.preventDefault(),v.stopPropagation(),n()}),a.append(s,i),o?o.replaceWith(r):e.appendChild(r),r}const fe="gigradar-detail-trigger",Zn=1e3,K="gigradar:skipped_jobs",at=24*60*60*1e3,te=new WeakMap,he=new Set;let J=null;async function Jn(e){if(he.has(e))return!0;if(!M())return!1;try{const n=(await chrome.storage.local.get(K))[K]||{},o=Date.now();if(n[e]&&o-n[e]<at)return he.add(e),!0}catch{return!1}return!1}async function Xn(e){if(he.add(e),!!M())try{const n=(await chrome.storage.local.get(K))[K]||{},o=Date.now();n[e]=o;for(const[r,a]of Object.entries(n))o-a>at&&delete n[r];await chrome.storage.local.set({[K]:n})}catch{}}function Qn(){J||(J=new IntersectionObserver(e=>{for(const t of e){const n=t.target,o=Date.now();if(t.isIntersecting){te.has(n)||te.set(n,o);continue}const r=te.get(n);if(r!==void 0){te.delete(n);const a=o-r,s=n.dataset.gigradarJobId;a>=Zn&&s&&(async()=>await Jn(s)||(await Xn(s),await Yt(Wt)))()}}},{threshold:.6}))}const it=['[data-qa="client-company-profile"]',".client-biography",'[data-test="client-info"]','[class*="client-info"]','[class*="client-bio"]','[class*="job-details"] aside section','aside section[class*="client"]'];let x=null,qe=null,ue=null;const eo=48,z=new Map,D=new Map;let j="en";Xe().then(e=>{j=e});Qe(e=>{j=e;for(const[,t]of D.entries())t.card.isConnected&&t.host.remove();D.clear(),re()});let $e=[],Ae="local_anonymous";Pt().then(e=>{Ae=e.userId||"local_anonymous"});Mt().then(e=>{$e=e});var Ke;typeof chrome<"u"&&((Ke=chrome.storage)!=null&&Ke.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{if(t!=="local")return;let n=!1;if(e[De]&&($e=e[De].newValue||[],n=!0),e[je]){const o=e[je].newValue;o&&(Ae=o.userId||"local_anonymous"),n=!0}if(n){for(const[,o]of D.entries())o.card.isConnected&&o.host.remove();D.clear(),re()}});function st(e){if(e.meta.jobId)for(z.has(e.meta.jobId)&&z.delete(e.meta.jobId),z.set(e.meta.jobId,e);z.size>eo;){const t=z.keys().next().value;if(t===void 0)break;z.delete(t)}}function Fe(){return/\/jobs\//.test(window.location.pathname)}function lt(e){const t=e.getBoundingClientRect();return t.width>0&&t.height>0&&window.getComputedStyle(e).visibility!=="hidden"}function ct(e){return new Promise(t=>{window.setTimeout(t,e)})}function to(e,t){let n;return()=>{window.clearTimeout(n),n=window.setTimeout(e,t)}}function no(e,t=26){const n=e.trim().replace(/\s+/g," ");return n.length>t?`${n.slice(0,t-1)}…`:n}function dt(e){for(const t of We(document.body,e))if(lt(t))return t;return null}function Ie(e,t){return e?t&&t.sampleCount>=e.sampleCount?t:e:t??null}const pt="gigradar:intel:";let Ue=0;async function oo(){if(M())try{const e=await chrome.storage.local.get(null),t=Date.now()-7*864e5,n=Object.entries(e).filter(([o,r])=>{if(!o.startsWith(pt))return!1;const a=r==null?void 0:r.savedAt;return typeof a!="number"||a<t});n.length>0&&await chrome.storage.local.remove(n.map(([o])=>o))}catch{return}}async function ro(e){if(!M())return;const t=e.meta.jobId;if(t)try{const n=`${pt}${t}`,r=(await chrome.storage.local.get(n))[n],a=mn(r,e,Date.now());await chrome.storage.local.set({[n]:a}),Ue+=1,Ue%25===0&&await oo()}catch{return}}function _e(e){const t={...e.signals};let n=e.activity,o=e.budget,r=e.trueRate,a=e.rating,s=e.meta.feedbacks,i=`${e.meta.title}
${e.meta.descriptionSnippet}`;if(Fe()){const g=ve(),p=g?Ze(g):null;p&&(Object.assign(t,p.signalsPatch),p.feedbacks.length>0&&(s=p.feedbacks),n=p.activity??n,o=p.budget??o,r=Ie(r,p.trueRate),a=p.rating??a,i=`${(g==null?void 0:g.innerText)??""}
${i}`)}const c=se(i),u=Ce(s),b=le(t),d=ce({signals:t,proposalCount:e.meta.proposalCount,activity:n,budget:o,trueRate:r,sentiment:u,scamMatched:c.matched}),m=X({feedbacks:s,description:`${e.meta.title}
${e.meta.descriptionSnippet}`,contractTitles:[e.meta.title]});return{meta:{...e.meta,feedbacks:s},signals:t,score:b,flags:d,nameGuess:de(s),activity:n,budget:o,trueRate:r,sentiment:u,rating:a,dossier:m}}function pe(e){var o;x=e,ye();const t=D.get(e.meta.jobId);if(t!=null&&t.card.isConnected){t.host.remove();const r=nt(t.card,{score:e.score.scored?e.score.score:null,tier:e.score.scored?e.score.tier:null,flagCount:e.flags.length,provisional:Object.values(e.signals).some(a=>a==null),alert:tt(e.signals,e.meta.proposalCount,!1,j),locale:j},()=>{const a=Z(x,e.meta.jobId,e);R({...a},{locale:j})});D.set(e.meta.jobId,{card:t.card,host:r})}else t&&D.delete(e.meta.jobId);const n=document.querySelector("[data-gigradar-inline]");(n==null?void 0:n.dataset.gigradarJobId)===e.meta.jobId&&((o=n.parentElement)!=null&&o.isConnected)&&Ee(n.parentElement,{...e},()=>{const r=Z(x,e.meta.jobId,e);R({...r},{locale:j})}),ro(e)}function ao(){for(const[e,t]of D.entries())if(!t.card.isConnected||!t.host.isConnected){if(J&&t.host)try{J.unobserve(t.host)}catch{}D.delete(e)}}function Te(e){const t=e.querySelectorAll('a[href*="/jobs/"]'),n=new Set;for(const o of Array.from(t)){const r=ie(o.href);r&&n.add(r)}return n}const Oe=["article.job-tile-responsive","article.job-tile",'[data-test="job-tile"]','[data-test="JobTile"]','[data-qa="job-tile"]',"section.job-tile-responsive",'[data-ev-label="search_result_item"]',"article",".air3-card"].join(", ");function ut(e){var n;const t=e.closest(Oe);if(t&&t!==document.body&&t.tagName!=="MAIN"){const o=(n=t.parentElement)==null?void 0:n.closest(Oe);return o&&o!==document.body&&o.tagName!=="MAIN"&&Te(o).size===1?o:t}return null}function re(){ao();const e=We(document.body,we.jobCard),t=[],n=document.querySelectorAll('h2 a[href*="/jobs/"], h3 a[href*="/jobs/"], [data-test*="title"] a[href*="/jobs/"], a[data-test="job-tile-title-link"], .job-tile-title a');for(const i of Array.from(n)){const c=i.closest('[data-gigradar-card="true"]');if(c&&c.querySelector("[data-gigradar-badge]"))continue;const u=ut(i);u&&t.push(u)}const r=Array.from(new Set([...e,...t])).filter(i=>!(!i.isConnected||i.dataset.gigradarCard==="true"&&i.querySelector("[data-gigradar-badge]")));if(r.length===0)return;const a=r.filter(i=>i.isConnected&&Te(i).size===1),s=a.filter(i=>!a.some(c=>c!==i&&c.contains(i)));for(const i of s){if(!i.isConnected||i.querySelector("[data-gigradar-badge]"))continue;const c=be(i);if(!c||!c.meta.jobId)continue;const u=D.get(c.meta.jobId);if(u!=null&&u.host.isConnected&&u.card.isConnected)continue;i.dataset.gigradarCard="true",i.dataset.gigradarJobId=c.meta.jobId,st(c);const b=c.signals,d=b.hireRatePct!=null||b.totalSpendUsd!=null||b.paymentVerified!=null,m=se(`${c.meta.title}
${c.meta.descriptionSnippet}`),g=d?le(b):null,p=ce({signals:b,proposalCount:c.meta.proposalCount,scamMatched:m.matched}),l=tt(b,c.meta.proposalCount,m.matched,j),y=ze(c.meta.jobId).toLowerCase(),h=$e.find(k=>ze(k.jobId).toLowerCase()===y&&k.expiresAt>Date.now()&&k.status!=="passed");let S=null;h&&h.memberId!==Ae&&(S={memberName:h.memberName,status:h.status,timeAgo:ge(h.updatedAt)});const C=nt(i,{score:(g==null?void 0:g.score)??null,tier:(g==null?void 0:g.tier)??null,flagCount:p.length,provisional:Object.values(b).some(k=>k==null),alert:l,teamAlert:S,locale:j},()=>{const k=be(i)??c;R(_e(k),{locale:j})});D.set(c.meta.jobId,{card:i,host:C}),p.length>0&&(Qn(),C.dataset.gigradarJobId=c.meta.jobId,J.observe(C))}}function io(e){var o,r;const t=e.querySelector('a[href*="/jobs/"]')??null;return t?ie(t.href):(((o=e.querySelector("h1"))==null?void 0:o.textContent)??((r=e.querySelector("h2"))==null?void 0:r.textContent)??"").trim().slice(0,64)}async function so(e=8){for(let t=0;t<e;t++){const n=dt(it);if(n)return n;await ct(300)}return null}const gt=["hireRatePct","totalSpendUsd","paymentVerified","daysSinceLastHire"];let Y,H=null,xe=0,O=null;function bt(e){return gt.map(t=>String(e[t]??"·")).join("|")}const mt=["proposalsCount","interviewingCount","invitesSentCount","unansweredInvitesCount"];function ft(e){return e?mt.map(t=>String(e[t]??"·")).join("|"):"∅"}function lo(e){var t;return[bt(e.signals),e.meta.feedbacks.length,ft(e.activity),((t=e.trueRate)==null?void 0:t.sampleCount)??-1,e.flags.map(n=>n.text).join("§"),e.rating?`★${e.rating.avg}`:"-"].join("#")}function ne(){xe+=1,Y!==void 0&&(window.clearTimeout(Y),Y=void 0),O==null||O.cancel(),O=null,H=null}function co(e){const t=Ut(e),n=Je(t);if(n&&x&&n.meta.jobId===x.meta.jobId){const o={...x.signals},r=n.signals,a=o;for(const C of gt){const k=r[C];k!=null&&(a[C]=k)}const s={...x.activity??{proposalsCount:null,interviewingCount:null,invitesSentCount:null,unansweredInvitesCount:null}},i=n.activity??x.activity;if(i){const C=s;for(const k of mt){const E=i[k];E!=null&&(C[k]=E)}}const c=Object.values(s).some(C=>C!=null),u=Array.from(new Set([...x.meta.feedbacks,...n.meta.feedbacks])),b=n.meta.proposalCount??x.meta.proposalCount,d=n.budget??x.budget??null,m=Ie(x.trueRate,n.trueRate),g=se(t.innerText??""),p=Ce(u),l=n.rating??x.rating??null,y=lo(x),h=ce({signals:o,proposalCount:b,activity:c?s:null,budget:d,trueRate:m,sentiment:p,scamMatched:g.matched});if([bt(o),u.length,ft(c?s:null),(m==null?void 0:m.sampleCount)??-1,h.map(C=>C.text).join("§"),l?`★${l.avg}`:"-"].join("#")!==y){const C=X({feedbacks:u,description:`${x.meta.title}
${x.meta.descriptionSnippet}`,contractTitles:[x.meta.title]}),k={meta:{...x.meta,proposalCount:b,feedbacks:u},signals:o,score:le(o),flags:h,nameGuess:de(u),activity:c?s:null,budget:d,trueRate:m,sentiment:p,rating:l,dossier:C};pe(k),document.querySelector("[data-gigradar-modal]")!=null&&R({...k},{docked:!0,settled:!0})}}}function po(){x&&document.querySelector("[data-gigradar-modal]")!=null&&R({...x},{docked:!0,settled:!0})}function ht(e){ne();const t=xe;H=e;let n=0;const o=()=>t===xe&&!!H&&H.isConnected&&document.body.contains(H),r=()=>{if(Y=void 0,!o()){ne();return}co(H),n+=1,n<12?Y=window.setTimeout(r,900):(ne(),po())};O=Nt(e,()=>{o()&&r()},()=>{o()&&r()},5,300)}function uo(e){const t=x&&x.meta.jobId===e.meta.jobId?x:z.get(e.meta.jobId)??xt();if(!t)return e;const n=e.signals,o=t.signals;return{...e,signals:{hireRatePct:n.hireRatePct??o.hireRatePct,totalSpendUsd:n.totalSpendUsd??o.totalSpendUsd,paymentVerified:n.paymentVerified??o.paymentVerified,daysSinceLastHire:n.daysSinceLastHire??o.daysSinceLastHire},budget:e.budget??t.budget??null,trueRate:e.trueRate??t.trueRate??null,rating:e.rating??t.rating??null,meta:{...e.meta,title:e.meta.title&&e.meta.title!=="Upwork job"?e.meta.title:t.meta.title||e.meta.title,proposalCount:e.meta.proposalCount??t.meta.proposalCount}}}function Le(e,t=!1){const n=Je(e);let o=null;n?o=_e(uo(n)):x&&(o=x),o&&(pe(o),R({...o},{docked:!0,scanning:!0,expanded:t}),(async()=>{const r=await so()??Bt(e);if(!(!e.isConnected||!document.body.contains(e))&&r){const a=Z(x,o.meta.jobId,o);Ee(r,a,()=>{const s=Z(x,o.meta.jobId,o);R({...s},{})})}})(),ht(e))}function Ge(){const e=ke();if(!e||!go(e)){ue=null,ne();return}const t=io(e);if(t!==ue){ue=t,Le(e);return}const n=!document.querySelector("[data-gigradar-inline]"),o=document.querySelector("[data-gigradar-modal]")==null;if(n&&o&&x){const r=dt(it);r&&Ee(r,x,()=>{const a=Z(x,x.meta.jobId,x);R({...a},{})})}}function go(e){return e.isConnected&&lt(e)}function ae(){var k,E,F,v;const e=ve();if(!e){x&&R({...x},{docked:!0});return}const t=Ze(e)??{signalsPatch:{},feedbacks:[]},n=ie(window.location.href),o=(x==null?void 0:x.meta.jobId)===n?x:z.get(n)??xt(),r=e.innerText??"",a=(k=/[^\n]*\bproposals?\b[^\n]*/i.exec(r))==null?void 0:k[0],s=(E=/^[^\n]*posted[^\n]*$/im.exec(r))==null?void 0:E[0],i=e.querySelector('[data-test="job-description"]')??e.querySelector(".job-description"),c={hireRatePct:null,totalSpendUsd:null,paymentVerified:null,daysSinceLastHire:null,...(o==null?void 0:o.signals)??{},...t.signalsPatch},u=t.feedbacks.length>0?t.feedbacks:(o==null?void 0:o.meta.feedbacks)??[],b=se(`${r}
${((i==null?void 0:i.textContent)??"").slice(0,2e3)}`),d=Ce(u),m=(v=(F=e.querySelector("h1"))==null?void 0:F.textContent)==null?void 0:v.trim(),g=(W(m)?null:m)||(o==null?void 0:o.meta.title)||document.title||"Upwork job",p=W(g)?"Upwork job":g,l={jobId:n,title:p,url:window.location.href,proposalCount:Ht(a??null)??(o==null?void 0:o.meta.proposalCount)??null,postedText:s?s.trim().slice(0,60):null,descriptionSnippet:((i==null?void 0:i.textContent)??"").trim().slice(0,400)||(o==null?void 0:o.meta.descriptionSnippet)||"",feedbacks:u},y=le(c),h=ce({signals:c,proposalCount:l.proposalCount,activity:t.activity,budget:t.budget,trueRate:t.trueRate,sentiment:d,scamMatched:b.matched}),S=X({feedbacks:u,description:`${l.title}
${l.descriptionSnippet}`,contractTitles:[l.title]}),C={meta:l,signals:c,score:y,flags:h,nameGuess:null,activity:t.activity??(o==null?void 0:o.activity)??null,budget:t.budget??(o==null?void 0:o.budget)??null,trueRate:Ie(o==null?void 0:o.trueRate,t.trueRate),sentiment:d,rating:t.rating??(o==null?void 0:o.rating)??null,dossier:S};pe(C),R(C,{docked:!0,scanning:!0}),ht(e)}async function bo(){for(let t=0;t<6&&!document.querySelector("h1");t++)await ct(400);const e=ie(window.location.href);if(qe===e){ae();return}qe=e,ae()}function mo(){let e=document.getElementById(fe);return e||(e=document.createElement("div"),e.id=fe,e.style.cssText=["position:fixed","right:18px","bottom:18px","z-index:99998","display:none","align-items:center","gap:8px","max-width:min(340px,60vw)","padding:10px 16px","border-radius:12px","background:rgba(13,15,18,.96)","border:1px solid rgba(16,185,129,.35)","color:#F3F4F6",'font-family:Inter,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',"font-size:12.5px","cursor:pointer","box-shadow:0 6px 22px rgba(0,0,0,.45), 0 0 18px rgba(16,185,129,.15), inset 0 1px 0 rgba(255,255,255,.06)","transition:transform .12s ease, box-shadow .16s ease"].join(";"),e.innerHTML=`
      <span style="background:linear-gradient(90deg,#34D399,#10B981);-webkit-background-clip:text;background-clip:text;color:transparent;font-weight:800;flex:none">GigRadar Intel</span>
      <span data-gr-title style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#9CA3AF;font-weight:600"></span>`,e.addEventListener("mouseenter",()=>{e.style.transform="translateY(-1px)",e.style.boxShadow="0 10px 30px rgba(0,0,0,.55), 0 0 26px rgba(16,185,129,.28)"}),e.addEventListener("mouseleave",()=>{e.style.transform="translateY(0)",e.style.boxShadow="0 6px 22px rgba(0,0,0,.45), 0 0 18px rgba(16,185,129,.15)"}),e.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation();const n=ke();if(n){Le(n,!0);return}x?R({...x},{docked:!0,expanded:!0}):ae()}),document.body.appendChild(e)),e}function ye(){var o,r,a,s;if(!(!!x||Fe()||qt())){(o=document.getElementById(fe))==null||o.remove();return}const t=mo();t.style.display="flex";const n=t.querySelector("[data-gr-title]");if(n){let i=x==null?void 0:x.meta.title;if(W(i)){const c=(s=(a=(r=ve())==null?void 0:r.querySelector("h1"))==null?void 0:a.textContent)==null?void 0:s.trim();i=W(c)?"":c}n.textContent=i?no(i):""}}const fo=3e3;let oe=null;function xt(){return!oe||Date.now()-oe.at>fo?null:oe.parsed}function ho(){document.addEventListener("click",e=>{const t=e.target;if(!t||typeof t.closest!="function"||!M())return;const n=t.closest(we.jobCard.join(", "))??ut(t);if(!n||Te(n).size!==1)return;const o=be(n);!o||W(o.meta.title)||(st(o),oe={parsed:o,at:Date.now()},pe(_e(o)))},!0)}function xo(){document.addEventListener("keydown",e=>{const t=e.key.toLowerCase();if(!(/mac/i.test(navigator.platform)?e.metaKey&&e.shiftKey&&t==="g"&&!e.altKey:e.altKey&&t==="g"&&!e.ctrlKey&&!e.metaKey))return;if(e.preventDefault(),e.stopPropagation(),An()){Fn();return}if(x){R({...x},{docked:!0,expanded:!0});return}const r=ke();r?Le(r,!0):Fe()&&ae()},!0)}function yo(){const e=()=>{window.setTimeout(yt,0)};for(const t of["pushState","replaceState"]){const n=history[t];Object.defineProperty(history,t,{value:function(o,r,a){n.call(this,o,r,a),e()},configurable:!0,writable:!0})}window.addEventListener("popstate",e)}function yt(){vt(),/\/jobs\/~/.test(window.location.pathname)&&bo(),et()&&me()}function wt(){if(!M()){kt.disconnect();return}if(et()){try{me()}catch{window.setTimeout(me,1e3)}return}try{re()}catch{window.setTimeout(re,1500)}try{Ge()}catch{window.setTimeout(Ge,1500)}try{ye()}catch{window.setTimeout(ye,1500)}}const vt=to(wt,250),kt=new MutationObserver(vt);function Ve(){yo(),ho(),xo(),kt.observe(document.body,{childList:!0,subtree:!0}),wt(),yt()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Ve,{once:!0}):Ve();
