import{l as M,m as q,d as K,c as X,a as $,b as Z,p as tt,q as et,g as R,e as ot,f as nt,h as A,i as F,j as at,k as it,n as rt,S as U,o as O,r as st,s as lt}from"./bid-intelligence-C4nmXGvU.js";import{e as P}from"./extpay-core-6aOhiK5e.js";import{g as ct,t as f}from"./metrics-CxlbnKT_.js";async function H(e){var h;const t=e.voiceProfile??await M(),n=(h=e.clientName)!=null&&h.trim()?e.clientName.trim():"there";let o=e.caseStudy;o===void 0&&(o=(await q({title:e.jobMeta.title,description:e.jobMeta.descriptionSnippet,techStack:e.techStack})).matched);const r=K(e.jobMeta.title,e.jobMeta.descriptionSnippet,e.techStack),s=X(e.jobMeta.title),i=s?` for your ${s}`:"";let l="";switch(t.tone){case"consultative_partner":l=`Hi ${n}, the biggest challenge with ${r.subject} projects like this is usually ${r.challenge}. Here is how we tackle this cleanly without technical debt or unexpected scope creep.`;break;case"velocity_exec":l=`Hi ${n}, saw your requirements${i}. I specialize in ${r.subject} and can jump in immediately with fast turnaround and daily production updates.`;break;case"custom":t.customInstructions?l=`Hi ${n}, reviewing your requirements${i} — ${t.customInstructions.slice(0,140)}`:l=`Hi ${n}, saw your posting${i}. I specialize in ${r.subject} and have delivered comparable implementations.`;break;case"direct_engineer":default:l=`Hi ${n}, saw you need help with ${r.subject}${i}. Having delivered similar ${r.solutionType} recently, I can take ownership of this build from day one.`;break}let d="";o?d=`Relevant implementation: I previously delivered "${o.title}" (${o.problemSolved}). Outcome: ${o.metricsOutcome}`+(o.proofLink?` [${o.proofLink}]`:"")+".":d=`I've engineered comparable ${r.solutionType} with strict attention to performance, automated testing, and reliable architecture.`;const a="Audit existing requirements, technical dependencies, and edge cases.",u=`Implement ${r.subject} architecture with milestone demos and automated verification.`,p="Production deployment, documentation, and zero-downtime handoff.",b=[a,u,p],c="What does your target milestone timeline look like? If you'd like, I can walk you through the technical approach or jump on a brief 10-minute scope alignment call tomorrow.",m=[l,d,`Proposed roadmap:
1. ${a}
2. ${u}
3. ${p}`,c].join(`

`),w=$(m,t.bannedPhrases);return{hook:$(l,t.bannedPhrases),caseStudyInjection:$(d,t.bannedPhrases),executionPlan:b,closingCta:$(c,t.bannedPhrases),fullText:w,matchedCaseStudyId:o==null?void 0:o.id,matchedCaseStudyTitle:o==null?void 0:o.title}}async function Ft(e){const t=await H(e),n=await Z();if(!n.enabled||!n.apiKey)return{ok:!0,proposal:t,polishedByAi:!1};try{const o=e.voiceProfile??await M(),r=[e.jobMeta.descriptionSnippet.slice(0,600),o.customInstructions?`Voice Guidelines: ${o.customInstructions}`:"",`Voice Tone: ${o.tone}`].filter(Boolean).join(`
`),s=await tt(t.hook,{title:e.jobMeta.title,description:r,clientName:e.clientName,techStack:e.techStack});if(s.ok&&s.text)return{ok:!0,proposal:{...t,hook:s.text,fullText:`${s.text}

${t.caseStudyInjection}

Proposed roadmap:
1. ${t.executionPlan[0]}
2. ${t.executionPlan[1]}
3. ${t.executionPlan[2]}

${t.closingCta}`},polishedByAi:!0}}catch{}return{ok:!0,proposal:t,polishedByAi:!1}}const dt="gigradar:intel:",pt=7*864e5,T="gigradar-autofill-toolbar";function k(){try{const e=/~([0-9a-z]{8,})/i.exec(window.location.pathname);return e?O(e[1]):O(window.location.pathname.split("/").filter(Boolean).pop()??"")}catch{return""}}async function _(e){if(!e||!P())return null;try{const t=`${dt}${e}`,o=(await chrome.storage.local.get(t))[t];return!o||typeof o.title!="string"||o.title.length===0||Date.now()-(o.savedAt??0)>pt?null:o}catch{return null}}function v(){var n;const e=document.querySelector("h1")??document.querySelector('[data-test="job-title"]')??document.querySelector("h2"),t=document.querySelector('[data-test="job-description"]')??document.querySelector('[class*="job-description"]');return{title:((n=e==null?void 0:e.textContent)==null?void 0:n.trim().slice(0,200))||"Upwork job",description:((t==null?void 0:t.textContent)??"").trim().slice(0,1200)}}function L(e,t){var o;const n=(o=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value"))==null?void 0:o.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}function ut(e,t,n){const o=e.trim().replace(/\s+/g," "),r=o.length>90?`${o.slice(0,89)}…`:o,s=st(t,`${t} ${n} ${o}`),i=lt[s[0]??"web"];return`Regarding "${r}" — I've worked extensively on ${i}, and this maps directly to how I would approach your project. I can walk you through relevant specifics on a quick call, start immediately, and keep you updated daily.`}const bt=`
  :host { all: initial; }
  * { box-sizing: border-box; }
  .bar {
    display: flex; align-items: center; gap: 7px; flex-wrap: wrap;
    margin: 8px 0;
    padding: 9px 12px;
    border-radius: 12px;
    background: #0D0F12;
    border: 1px solid rgba(16,185,129,.35);
    box-shadow: 0 4px 18px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.05);
    font-family: Inter, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    width: max-content; max-width: 100%;
  }
  .brand {
    font-weight: 800; font-size: 10.5px; letter-spacing: .04em;
    background: linear-gradient(90deg, #34D399, #10B981);
    -webkit-background-clip: text; background-clip: text; color: transparent;
    margin-right: 2px;
  }
  button {
    font-family: inherit;
    border-radius: 9px; cursor: pointer;
    transition: all .14s ease;
  }
  .autopilot {
    padding: 8px 15px;
    border: 1px solid rgba(129,140,248,.5);
    background: linear-gradient(180deg, #6366F1, #4338CA);
    color: #FFFFFF;
    font-size: 12px; font-weight: 800;
    box-shadow: 0 3px 12px rgba(99,102,241,.32), inset 0 1px 0 rgba(255,255,255,.2);
  }
  .autopilot:hover { filter: brightness(1.1); transform: translateY(-1px); }
  .autopilot:active { transform: scale(.97); }
  .fill {
    padding: 8px 15px;
    border: none;
    background: linear-gradient(180deg, #34D399, #059669);
    color: #0D0F12;
    font-size: 12px; font-weight: 800;
    box-shadow: 0 3px 12px rgba(16,185,129,.28), inset 0 1px 0 rgba(255,255,255,.2);
  }
  .fill:hover { filter: brightness(1.08); transform: translateY(-1px); }
  .fill:active { transform: scale(.97); }
  .variant {
    padding: 6px 11px;
    border: 1px solid #262C37;
    background: #161A22;
    color: #E5E7EB;
    font-size: 11px; font-weight: 700;
  }
  .variant:hover { background: #1D222C; border-color: #3A4250; }
  .status { font-size: 11px; font-weight: 700; color: #6EE7B7; }
`,gt=["display:inline-flex;align-items:center;gap:5px","margin:4px 0 6px;padding:5px 11px","border-radius:999px;border:1px solid rgba(16,185,129,.45)","background:rgba(16,185,129,.09);color:#34D399",'font-family:Inter,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',"font-size:11px;font-weight:800;cursor:pointer","transition:all .14s ease"].join(";");let E=[];async function mt(){const e=k(),t=await _(e),n=v(),o=t?{title:t.title,description:t.description||n.description}:n,r=(t==null?void 0:t.clientName)??null;return{hooks:R({jobId:e||o.title,title:o.title,description:o.description,clientName:r}),context:o}}function V(){const e=et(document.body,U.coverLetter);return e instanceof HTMLTextAreaElement?e:document.querySelector('form textarea:not([id*="question" i])')}function N(e,t){const n=V();if(!n){t&&(t.textContent="Cover letter field not found");return}L(n,e.text),n.focus(),t&&(t.textContent=`Option ${e.label} filled ✓`,window.setTimeout(()=>{t.textContent=""},2200))}function S(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const j="gigradar-team-collision-banner";async function ft(e){var r,s;const t=k();if(!t||!P())return;const n=await ot(),o=await nt(t);if(n==="agency"&&!o.isClaimed){const i=v(),l=I(),d=A(l);await F({jobId:t,jobTitle:i.title,status:"drafting",jobUrl:window.location.href,budget:l,dealValueUsd:d})}if(o.isClaimed&&!o.isCurrentMember){if(document.getElementById(j))return;const i=document.createElement("div");i.id=j;const l=i.attachShadow({mode:"closed"}),d=document.createElement("style");d.textContent=`
      :host { all: initial; display: block; width: 100%; margin: 12px 0 16px; }
      * { box-sizing: border-box; font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
      .box {
        padding: 14px 18px;
        border-radius: 12px;
        background: rgba(225, 29, 72, 0.12);
        border: 1px solid rgba(244, 63, 94, 0.6);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4), 0 0 18px rgba(244, 63, 94, 0.2);
        color: #F3F4F6;
      }
      .head {
        display: flex; align-items: center; justify-content: space-between;
        font-size: 13px; font-weight: 800; color: #FECDD3; margin-bottom: 6px;
      }
      .desc {
        font-size: 12px; line-height: 1.5; color: #E2E8F0; margin-bottom: 12px;
      }
      .desc b { color: #FFFFFF; font-weight: 700; }
      .btns { display: flex; gap: 8px; flex-wrap: wrap; }
      .btn {
        padding: 7px 14px; border-radius: 8px; font-size: 11.5px; font-weight: 700;
        cursor: pointer; border: none; transition: all 0.15s ease;
      }
      .btn-takeover {
        background: #8B5CF6; color: #FFFFFF;
      }
      .btn-takeover:hover { background: #7C3AED; }
      .btn-applied {
        background: #10B981; color: #07090C; font-weight: 800;
      }
      .btn-applied:hover { background: #059669; color: #FFFFFF; }
    `;const a=o.activity,u=at(a.updatedAt),p=document.createElement("div");p.className="box",p.innerHTML=`
      <div class="head">
        <span>🛑 TEAM COLLISION WARNING</span>
        <span style="font-size:10px;padding:3px 8px;border-radius:6px;background:rgba(244,63,94,0.25);border:1px solid rgba(244,63,94,0.5);">${a.status.toUpperCase()}</span>
      </div>
      <div class="desc">
        Teammate <b>${S(a.memberName)}</b> is already <b>${S(a.status)}</b> on this job (${S(u)}).
        Submitting this proposal will burn 12–16 Connects ($1.80–$2.40) and send duplicate agency proposals.
      </div>
      <div class="btns">
        <button type="button" id="gr-takeover-btn" class="btn btn-takeover">⚡ Take Over (Claim Drafting)</button>
        <button type="button" id="gr-mark-applied-btn" class="btn btn-applied">✅ Mark as Applied</button>
      </div>
    `,(r=p.querySelector("#gr-takeover-btn"))==null||r.addEventListener("click",async()=>{const b=v(),c=I(),m=A(c);await F({jobId:t,jobTitle:b.title,status:"drafting",jobUrl:window.location.href,budget:c,dealValueUsd:m}),i.remove()}),(s=p.querySelector("#gr-mark-applied-btn"))==null||s.addEventListener("click",async()=>{const b=v(),c=I(),m=A(c);await F({jobId:t,jobTitle:b.title,status:"applied",jobUrl:window.location.href,budget:c,dealValueUsd:m}),i.remove()}),l.append(d,p),e.insertAdjacentElement("beforebegin",i)}}const B="gigradar-bid-intelligence-card";function I(){try{const e=document.body.innerText,t=/\$([0-9.]+)\s*-\s*\$([0-9.]+)\s*\/hr/i.exec(e)||/\$([0-9.]+)\s*\/hr/i.exec(e);if(t){const o=parseFloat(t[1]),r=t[2]?parseFloat(t[2]):o;return{type:"hourly",minUsd:o,maxUsd:r}}const n=/(?:budget|fixed[- ]price)[:\s]*\$([0-9,]+)/i.exec(e)||/\$([0-9,]+)\s*(?:fixed[- ]price|budget)/i.exec(e);if(n){const o=parseFloat(n[1].replace(/,/g,""));return{type:"fixed",minUsd:o,maxUsd:o}}}catch{}return null}function xt(){try{const e=document.body.innerText,t=/proposals:\s*([0-9]+)\s*to\s*([0-9]+)/i.exec(e)||/([0-9]+)\+?\s*proposals/i.exec(e);if(t)return parseInt(t[2]||t[1],10)}catch{}return null}function ht(){const e=Array.from(document.querySelectorAll('input[type="number"], input[type="text"], input'));for(const t of e){const n=(t.getAttribute("name")??"").toLowerCase(),o=(t.getAttribute("aria-label")??"").toLowerCase(),r=(t.getAttribute("data-test")??"").toLowerCase(),s=(t.getAttribute("data-qa")??"").toLowerCase(),i=(t.getAttribute("placeholder")??"").toLowerCase();if(n.includes("boost")||n.includes("bid")||o.includes("boost")||o.includes("bid")||r.includes("boost")||r.includes("bid")||s.includes("boost")||s.includes("bid")||i.includes("bid"))return t}return null}function yt(e){var o;const t=ht();if(!t)return!1;const n=(o=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:o.set;return n?n.call(t,String(e)):t.value=String(e),t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.focus(),!0}async function vt(e){var C;if(document.getElementById(B))return;const t=k(),n=await _(t),o=await ct(),r=(n==null?void 0:n.budget)||I(),s=(n==null?void 0:n.proposalCount)||xt(),i=(n==null?void 0:n.hireRatePct)??null,l=(n==null?void 0:n.paymentVerified)??null,d=(n==null?void 0:n.totalSpendUsd)??null,a=it({budget:r,clientHireRatePct:i,clientPaymentVerified:l,clientTotalSpendUsd:d,proposalCount:s}),u=document.createElement("div");u.id=B;const p=u.attachShadow({mode:"closed"}),b=document.createElement("style");b.textContent=`
    :host { all: initial; display: block; width: 100%; margin: 10px 0 16px; }
    * { box-sizing: border-box; font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    .card {
      border-radius: 14px;
      background: #0B0E14;
      border: 1px solid rgba(99, 102, 241, 0.35);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.06);
      padding: 14px 16px;
      color: #E2E8F0;
    }
    .top-bar {
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
      margin-bottom: 12px;
    }
    .brand-title {
      font-size: 11px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase;
      color: #818CF8; display: flex; align-items: center; gap: 6px;
    }
    .badge {
      font-size: 9.5px; font-weight: 800; padding: 3px 8px; border-radius: 6px;
      text-transform: uppercase; letter-spacing: .04em; border: 1px solid;
    }
    .badge-tactical { background: rgba(99, 102, 241, 0.2); color: #A5B4FC; border-color: rgba(99, 102, 241, 0.4); }
    .badge-aggressive { background: rgba(245, 158, 11, 0.2); color: #FCD34D; border-color: rgba(245, 158, 11, 0.4); }
    .badge-organic { background: rgba(16, 185, 129, 0.2); color: #6EE7B7; border-color: rgba(16, 185, 129, 0.4); }
    .badge-skip { background: rgba(239, 68, 68, 0.2); color: #FCA5A5; border-color: rgba(239, 68, 68, 0.4); }

    .stats-grid {
      display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 8px;
      margin-bottom: 12px;
    }
    .tile {
      background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.06);
      border-radius: 10px; padding: 8px 10px;
    }
    .tile-lbl { font-size: 9.5px; font-weight: 700; color: #94A3B8; text-transform: uppercase; }
    .tile-val { font-size: 15px; font-weight: 900; margin-top: 2px; font-family: ui-monospace, monospace; }
    .tile-val small { font-size: 10px; font-weight: 600; color: #94A3B8; }

    .text-emerald { color: #34D399; }
    .text-brand { color: #60A5FA; }
    .text-indigo { color: #A5B4FC; }
    .text-amber { color: #FBBF24; }

    .verdict {
      font-size: 11.5px; line-height: 1.45; color: #CBD5E1;
      background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 8px; padding: 8px 12px; margin-bottom: 12px;
    }

    .curve-row {
      display: flex; gap: 4px; align-items: flex-end; height: 48px; margin-bottom: 12px;
      padding: 0 4px; border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    .bar-col {
      flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end;
      height: 100%; position: relative; cursor: pointer;
    }
    .bar-col:hover .bar-fill { filter: brightness(1.25); }
    .bar-fill {
      width: 100%; border-radius: 3px 3px 0 0; background: #374151;
      transition: height 0.2s ease, background-color 0.2s ease;
    }
    .bar-fill.active { background: #6366F1; box-shadow: 0 0 8px rgba(99, 102, 241, 0.6); }
    .bar-fill.organic { background: #10B981; }
    .bar-lbl { font-size: 8px; color: #64748B; margin-top: 3px; font-family: ui-monospace, monospace; }

    .actions-bar {
      display: flex; align-items: center; justify-content: space-between; gap: 10px;
    }
    .apply-btn {
      padding: 8px 16px; border-radius: 9px; font-size: 12px; font-weight: 800; cursor: pointer;
      border: 1px solid rgba(129, 140, 248, 0.6);
      background: linear-gradient(180deg, #6366F1, #4338CA);
      color: #FFFFFF; box-shadow: 0 3px 12px rgba(99, 102, 241, 0.35);
      transition: all 0.14s ease;
    }
    .apply-btn:hover { filter: brightness(1.1); transform: translateY(-1px); }
    .apply-btn:active { transform: scale(0.97); }
    .organic-badge {
      font-size: 11.5px; font-weight: 700; color: #34D399;
      display: flex; align-items: center; gap: 5px;
    }
    .status-msg { font-size: 11px; font-weight: 700; color: #34D399; }
  `;const c=a.strategy==="AGGRESSIVE_TOP_SLOT"?"badge-aggressive":a.strategy==="TACTICAL_BOOST"?"badge-tactical":a.strategy==="ORGANIC_SWEET_SPOT"?"badge-organic":"badge-skip",m=a.strategy==="AGGRESSIVE_TOP_SLOT"?"bid_strategy_aggressive":a.strategy==="TACTICAL_BOOST"?"bid_strategy_tactical":a.strategy==="ORGANIC_SWEET_SPOT"?"bid_strategy_organic":"bid_strategy_skip",w=Math.max(...a.curve.map(g=>g.winProbabilityPct),1),h=a.curve.map(g=>{const y=Math.max(8,Math.round(g.winProbabilityPct/w*100)),Q=g.bidConnects===a.recommendedBid,Y=g.bidConnects===0,J=Q?"active":Y?"organic":"";return`
        <div class="bar-col" title="${g.bidConnects} Connects: ${g.winProbabilityPct}% win, +$${g.expectedValueUsd} EV">
          <div class="bar-fill ${J}" style="height:${y}%"></div>
          <span class="bar-lbl">${g.bidConnects}c</span>
        </div>`}).join(""),x=document.createElement("div");x.className="card",x.innerHTML=`
    <div class="top-bar">
      <div class="brand-title">
        <span>⚡ ${f("bid_intel_title",o)}</span>
      </div>
      <span class="badge ${c}">${f(m,o)}</span>
    </div>

    <div class="stats-grid">
      <div class="tile">
        <div class="tile-lbl">${f("win_probability_label",o)}</div>
        <div class="tile-val text-emerald">${a.winProbabilityPct}% <small>(${a.organicWinProbabilityPct}% org)</small></div>
      </div>
      <div class="tile">
        <div class="tile-lbl">${f("expected_value_label",o)}</div>
        <div class="tile-val text-brand">+${a.expectedValueUsd>0?"$":""}${a.expectedValueUsd.toFixed(0)}</div>
      </div>
      <div class="tile">
        <div class="tile-lbl">${f("optimal_bid_label",o)}</div>
        <div class="tile-val text-indigo">${a.recommendedBid}c <small>($${a.connectsCostUsd.toFixed(2)})</small></div>
      </div>
      <div class="tile">
        <div class="tile-lbl">${f("expected_roi_label",o)}</div>
        <div class="tile-val text-amber">${a.roiRatio}x <small>(BE ${a.breakEvenWinRatePct}%)</small></div>
      </div>
    </div>

    <div class="verdict">${S(a.verdictSummary)}</div>

    <div class="curve-row">
      ${h}
    </div>

    <div class="actions-bar">
      ${a.recommendedBid>0?`<button type="button" id="gr-apply-bid-btn" class="apply-btn">
              ${f("apply_optimal_bid_btn",o)} (${a.recommendedBid} Connects)
             </button>`:`<div class="organic-badge">
              🛡️ ${f("bid_strategy_organic",o)}: 0 Connects
             </div>`}
      <span id="gr-bid-status" class="status-msg"></span>
    </div>
  `,(C=x.querySelector("#gr-apply-bid-btn"))==null||C.addEventListener("click",()=>{const g=yt(a.recommendedBid),y=x.querySelector("#gr-bid-status");y&&(y.textContent=g?f("optimal_bid_applied",o):"Could not find Upwork bid field",setTimeout(()=>{y.textContent=""},2500))}),p.append(b,x),e.insertAdjacentElement("beforebegin",u)}function wt(e){if(document.getElementById(T))return;const t=document.createElement("div");t.id=T;const n=t.attachShadow({mode:"closed"}),o=document.createElement("style");o.textContent=bt;const r=document.createElement("div");r.className="bar";const s=document.createElement("span");s.className="brand",s.textContent="GigRadar";const i=document.createElement("button");i.type="button",i.className="autopilot",i.textContent="🚀 Auto-Fill Full Proposal";const l=document.createElement("button");l.type="button",l.className="fill",l.textContent="⚡ Quick Hook";const d=document.createElement("span");d.className="status",r.append(s,i,l),i.addEventListener("click",async u=>{u.preventDefault(),u.stopPropagation(),i.disabled=!0;const p=i.textContent;i.textContent="Generating…",d.textContent="Matching case studies…";try{const b=k(),c=await _(b),m=v(),w=(c==null?void 0:c.title)||m.title,h=(c==null?void 0:c.description)||m.description,x=(c==null?void 0:c.clientName)??null,C=await q({title:w,description:h}),g=await H({jobMeta:{jobId:b||"upwork-job",title:w,descriptionSnippet:h},clientName:x,caseStudy:C.matched});L(e,g.fullText),e.focus();const y=g.matchedCaseStudyTitle?` [Study: ${g.matchedCaseStudyTitle.slice(0,30)}…]`:"";d.textContent=`✓ Full Proposal Injected!${y}`,window.setTimeout(()=>{d.textContent=""},4e3)}catch{d.textContent="Generation failed"}finally{i.disabled=!1,i.textContent=p}}),l.addEventListener("click",u=>{if(u.preventDefault(),u.stopPropagation(),E.length===0){const p=v();E=R({jobId:k()||p.title,title:p.title,description:p.description,clientName:null})}N(E[0],d)}),(async()=>{const{hooks:u}=await mt();E=u;for(const p of u){const b=document.createElement("button");b.type="button",b.className="variant",b.textContent=`${p.label}`,b.title=`${p.style} — ${p.text.slice(0,80)}…`,b.addEventListener("click",c=>{c.preventDefault(),c.stopPropagation(),N(p,d)}),r.appendChild(b)}})(),r.appendChild(d),n.append(o,r);const a=e.closest('[data-test="cover-letter-section"]')??e.closest("form")??e.parentElement;a==null||a.insertAdjacentElement("beforebegin",t)}function kt(){var o,r;const e=rt(document.body,U.screeningQuestion),{title:t,description:n}=v();for(const s of e){if(s.querySelector("[data-gigradar-answer-btn]"))continue;const i=s.querySelector("textarea");if(!i)continue;const l=s.querySelector('label, h3, h4, [data-test="question-label"]')??s.firstElementChild,d=((o=l==null?void 0:l.textContent)==null?void 0:o.trim())||((r=s.textContent)==null?void 0:r.trim().slice(0,160))||"this question",a=document.createElement("button");a.type="button",a.dataset.gigradarAnswerBtn="",a.setAttribute("style",gt),a.textContent="✨ Auto-Draft Answer",a.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation(),L(i,ut(d,t,n)),a.textContent="✓ Drafted",window.setTimeout(()=>{a.textContent="✨ Auto-Draft Answer"},1800)}),l&&l.parentElement===s?l.insertAdjacentElement("afterend",a):i.insertAdjacentElement("beforebegin",a)}}function Ct(){return/\/(nx|ab)\/proposals\/job\//.test(window.location.pathname)}function Tt(){D()}function D(){if(!P()){W.disconnect();return}if(!Ct())return;const e=V();if(e&&$t(e)){wt(e);const t=e.closest('[data-test="cover-letter-section"]')??e.closest("form")??e.parentElement;t&&(ft(t),vt(t))}kt()}function $t(e){const t=e.getBoundingClientRect();return t.width>0&&t.height>0}function Et(e,t){let n;return()=>{window.clearTimeout(n),n=window.setTimeout(e,t)}}const G=Et(D,400),W=new MutationObserver(G);function z(){W.observe(document.body,{childList:!0,subtree:!0}),D();let e=window.location.href;window.setInterval(()=>{var t,n,o;window.location.href!==e&&(e=window.location.href,(t=document.getElementById(T))==null||t.remove(),(n=document.getElementById(j))==null||n.remove(),(o=document.getElementById(B))==null||o.remove(),G())},800)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",z,{once:!0}):z();export{Ft as a,H as g,Ct as i,Tt as s};
