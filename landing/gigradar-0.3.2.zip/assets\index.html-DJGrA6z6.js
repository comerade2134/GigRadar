import{S as We,g as bt,a as xt,s as He,o as mt}from"./share-modal-DFpAcbF4.js";import{t as st,u as gt,v as Ke,w as Fe,x as ft,b as Ge,y as vt,z as yt,A as ht,B as wt,C as _t,l as ke,D as ze,E as kt,F as $t,e as St,G as Ye,H as ee,j as Je,I as Xe,J as Et,K as Ct,L as Lt,M as Qe,N as It,k as At,O as te,i as Tt,P as Bt}from"./bid-intelligence-C4nmXGvU.js";import{a as jt,l as Pt,D as Nt}from"./feed-scanner-B53pnkH_.js";import{a as nt,g as Ut,t,s as Mt,D as Rt}from"./metrics-CxlbnKT_.js";import{e as se,P as Ot,g as Ze}from"./extpay-core-6aOhiK5e.js";import"./extpay-vendor-CwkHEbPA.js";const $e="gigradar:team_intel",Se="gigradar:sync_state",Ee={lastSyncedAt:null,syncStatus:"offline"};async function qt(){if(!se())return{...Ee};try{const b=(await chrome.storage.local.get(Se))[Se];if(b&&typeof b.syncStatus=="string")return b}catch{}return{...Ee}}async function pe(e){se()&&await chrome.storage.local.set({[Se]:e})}async function Ce(){if(!se())return[];try{const b=(await chrome.storage.local.get($e))[$e];if(Array.isArray(b))return b}catch{}return[]}async function et(e){if(!se())return;const b=await Ce();if(b.some(c=>c.clientKey===e.clientKey))return;const R=[{...e,flaggedAt:Date.now()},...b.slice(0,99)];await chrome.storage.local.set({[$e]:R})}async function tt(){if(!se())return{...Ee};const e=await st();if(e.tier==="free"){const b={lastSyncedAt:null,syncStatus:"offline"};return await pe(b),b}await pe({lastSyncedAt:e.syncedAt??null,syncStatus:"syncing"});try{await nt(),e.syncedAt=Date.now(),await gt(e),e.tier==="agency"&&(await Ce()).length===0&&(await et({clientKey:"org_acme_ghost",clientName:"Acme Digital Labs",flaggedBy:"Sarah (Lead BD)",reason:"Never hires after sending tests (0/14 hires on $50k listed)"}),await et({clientKey:"org_crypto_scam",clientName:"Web3 Global Ventures",flaggedBy:"Alex (Agency Dev)",reason:"Attempts off-platform Telegram interview redirection"}));const b={lastSyncedAt:e.syncedAt,syncStatus:"synced"};return await pe(b),b}catch(b){const $={lastSyncedAt:e.syncedAt??null,syncStatus:"error",errorMessage:b instanceof Error?b.message:"Cloud synchronization failed"};return await pe($),$}}function _(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const y=document.querySelector("#app");async function at(){var Me,Re,Oe,qe,De,Ve;if(!y)return;const e=await Ut();y.innerHTML=`
    <header class="mb-8 flex animate-fade-up items-center gap-3.5">
      <div class="relative flex h-12 w-12 items-center justify-center rounded-2xl border border-brand-500/35 bg-gradient-to-b from-brand-500/20 to-brand-500/5 shadow-[0_0_20px_rgba(16,185,129,0.25)]">
        <svg viewBox="0 0 24 24" fill="none" class="h-7 w-7" aria-hidden="true">
          <rect x="1.25" y="1.25" width="21.5" height="21.5" rx="6.5" fill="url(#gr-logo-g)" stroke="#10B981" stroke-opacity=".35"/>
          <path d="M13.4 4.8 7.2 12.9h3.6l-1.1 6.3 6.9-8.7h-3.9l.7-5.7z" fill="#0D0F12"/>
          <defs>
            <linearGradient id="gr-logo-g" x1="2" y1="2" x2="22" y2="22">
              <stop stop-color="#34D399"/><stop offset="1" stop-color="#059669"/>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div>
        <div class="flex items-center gap-2">
          <h1 class="text-xl font-black tracking-tight text-white">${t("settings_title",e)}</h1>
          <span class="rounded-md border border-white/10 bg-white/5 px-2 py-0.5 font-mono text-[10px] text-slate-400">
            v${chrome.runtime.getManifest().version}
          </span>
        </div>
        <p class="text-xs text-mute">${t("settings_sub",e)}</p>
      </div>
    </header>

    <!-- Language Selector Section -->
    <section class="mb-6 space-y-4 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("language_section_title",e)}</h2>
          <p class="mt-0.5 text-xs text-mute">${t("language_section_desc",e)}</p>
        </div>
        <span id="lang-save-status" class="text-xs font-bold text-brand-400"></span>
      </div>

      <!-- Visual Interactive Language Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
        ${We.map(s=>`
          <button type="button" data-option-lang="${s.code}"
            class="group relative flex flex-col justify-between rounded-xl border p-3 text-left transition-all duration-150 active:scale-95 ${s.code===e?"border-brand-500 bg-brand-500/15 shadow-[0_0_18px_rgba(16,185,129,0.22)]":"border-edge bg-obsidian/70 hover:border-brand-500/40 hover:bg-raised"}">
            <div class="flex items-center justify-between">
              ${bt(s.code)}
              ${s.code===e?`<span class="inline-flex items-center gap-1 rounded-full bg-brand-500/20 px-2 py-0.5 text-[9.5px] font-black text-brand-300 border border-brand-500/40 shadow-[0_0_8px_rgba(16,185,129,0.3)]">
                      <svg viewBox="0 0 16 16" fill="none" class="h-2.5 w-2.5"><path d="M3.5 8.5L6.5 11.5L12.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> ${t("connects_saved_active",e)}
                    </span>`:`<span class="rounded-md border border-white/5 bg-white/5 px-1.5 py-0.5 font-mono text-[9.5px] font-extrabold text-slate-400 group-hover:text-slate-200 transition-colors">${s.code.toUpperCase()}</span>`}
            </div>
            <div class="mt-3 min-w-0">
              <div class="text-xs font-bold text-white truncate group-hover:text-brand-300 transition-colors">${s.nativeName}</div>
              <div class="text-[10px] text-slate-400 truncate mt-0.5">${s.sublabel}</div>
            </div>
          </button>
        `).join("")}
      </div>

      <!-- Hidden select for compatibility -->
      <select id="setting-language" class="hidden">
        ${We.map(s=>`
          <option value="${s.code}" ${s.code===e?"selected":""}>
            ${s.name}
          </option>
        `).join("")}
      </select>
    </section>

    <!-- License Section -->
    <section class="mb-6 space-y-4 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("license",e)}</h2>
        <span class="text-[10px] font-mono text-slate-400">ExtensionPay</span>
      </div>

      <div class="flex items-start gap-3 rounded-xl border border-white/5 bg-obsidian/40 p-3.5">
        <div class="flex h-8 w-8 flex-none items-center justify-center rounded-lg border border-brand-500/30 bg-brand-500/15 text-brand-400">
          <svg viewBox="0 0 16 16" fill="currentColor" class="h-4 w-4">
            <path d="M8 1a7 7 0 100 14A7 7 0 008 1zm-.8 4h1.6v4H7.2V5zm.8 7a1 1 0 110-2 1 1 0 010 2z"/>
          </svg>
        </div>
        <p id="license-status" class="text-sm leading-relaxed text-slate-300 pt-0.5">${t("license_status_checking",e)}</p>
      </div>

      <div class="flex flex-wrap gap-2.5 pt-1">
        <button id="buy"
          class="group relative overflow-hidden rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-5 py-2.5 text-sm font-black text-slate-950 shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all duration-150 hover:brightness-105 active:scale-[.98]">
          <span class="absolute inset-x-0 top-0 h-px bg-white/60"></span>
          ${t("get_pro",e)} — ${Ot} early bird
        </button>
        <button id="recheck"
          class="rounded-xl border border-edge bg-raised px-4 py-2.5 text-sm font-semibold text-mute transition-colors duration-150 hover:border-brand-500/40 hover:text-white active:scale-[.99]">
          ${t("recheck_license",e)}
        </button>
      </div>
    </section>

    <!-- Account & Cloud Sync Section -->
    <section class="mb-6 space-y-4 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("account_section_title",e)}</h2>
          <p class="mt-0.5 text-xs text-mute">${t("account_section_desc",e)}</p>
        </div>
        <span id="account-tier-badge" class="inline-flex items-center gap-1.5 rounded-full border border-slate-700 bg-slate-800/80 px-2.5 py-1 text-xs font-bold text-slate-400">
          <span class="h-1.5 w-1.5 rounded-full bg-brand-400"></span>
          <span id="account-tier-label">${t("tier_free",e)}</span>
        </span>
      </div>

      <div class="rounded-xl border border-white/5 bg-obsidian/40 p-4 space-y-3">
        <div class="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div class="flex items-center gap-2">
            <span class="text-mute font-medium">Status:</span>
            <span id="cloud-sync-status" class="font-bold text-slate-400 flex items-center gap-1.5">
              <span class="h-2 w-2 rounded-full bg-slate-500"></span>
              ${t("sync_status_offline",e)}
            </span>
          </div>
          <div id="account-user-email" class="text-slate-400 font-mono text-[11px]">
            local_anonymous
          </div>
        </div>

        <div id="team-info-box" class="hidden rounded-lg border border-brand-500/20 bg-brand-500/5 p-3 text-xs">
          <div class="flex items-center justify-between text-brand-300 font-bold mb-1">
            <span id="team-name-label">Agency Workspace</span>
            <span id="team-seats-badge" class="rounded bg-brand-500/20 px-2 py-0.5 text-[10px] font-mono">1 / 10 seats</span>
          </div>
          <div class="text-[11px] text-slate-400 flex items-center justify-between">
            <span>${t("team_intel_shared",e)}:</span>
            <span id="team-intel-count" class="font-mono font-bold text-white">0</span>
          </div>
        </div>
      </div>

      <div class="grid gap-3 sm:grid-cols-2">
        <input id="account-token-input" type="text" placeholder="Enter license or agency team token…" autocomplete="off" spellcheck="false"
          class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 text-xs text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20" />
        <div class="flex items-center gap-2">
          <button id="account-connect-btn" type="button"
            class="rounded-xl border border-edge bg-raised px-4 py-2.5 text-xs font-semibold text-white transition-colors duration-150 hover:border-brand-500/40 hover:bg-raised/80 active:scale-[.99]">
            Connect
          </button>
          <button id="account-sync-btn" type="button"
            class="flex-1 rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-4 py-2.5 text-xs font-black text-slate-950 shadow-[0_0_16px_rgba(16,185,129,0.2)] transition-all duration-150 hover:scale-[1.01] active:scale-[.98]">
            ${t("sync_now_btn",e)}
          </button>
          <button id="account-disconnect-btn" type="button" class="hidden rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-2.5 text-xs font-semibold text-red-400 transition-colors duration-150 hover:bg-red-500/20 active:scale-[.99]">
            Disconnect
          </button>
        </div>
      </div>
      <span id="account-status-msg" class="text-xs font-bold text-brand-400"></span>

      <!-- Module A: Live Team Proposal Pipeline & Collision Ledger -->
      <div id="team-pipeline-section" class="mt-4 pt-4 border-t border-white/5 space-y-3">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <div class="flex items-center gap-2">
            <span class="flex h-2 w-2 rounded-full bg-purple-400 shadow-[0_0_8px_rgba(168,85,247,0.6)]"></span>
            <h3 class="text-xs font-black uppercase tracking-wider text-purple-300">
              ${t("active_team_pipeline",e)}
            </h3>
          </div>
          <div class="flex items-center gap-2">
            <button id="simulate-team-activity-btn" type="button"
              class="rounded-lg border border-purple-500/30 bg-purple-500/10 px-2.5 py-1 text-[11px] font-bold text-purple-300 hover:bg-purple-500/20 hover:border-purple-500/50 transition-colors">
              ${t("simulate_team_activity_btn",e)}
            </button>
            <button id="clear-team-pipeline-btn" type="button"
              class="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] font-semibold text-slate-400 hover:text-white transition-colors">
              ${t("clear_team_pipeline_btn",e)}
            </button>
          </div>
        </div>

        <!-- Metrics Row -->
        <div class="grid grid-cols-3 gap-2.5">
          <div class="rounded-xl border border-white/5 bg-obsidian/60 p-3">
            <div class="text-[10px] uppercase font-bold text-mute tracking-wider">${t("collisions_prevented_label",e)}</div>
            <div id="metric-collisions-prevented" class="text-lg font-black text-white font-mono mt-0.5">0</div>
          </div>
          <div class="rounded-xl border border-white/5 bg-obsidian/60 p-3">
            <div class="text-[10px] uppercase font-bold text-mute tracking-wider">${t("connects_saved_label",e)}</div>
            <div id="metric-connects-saved" class="text-lg font-black text-emerald-400 font-mono mt-0.5">0</div>
          </div>
          <div class="rounded-xl border border-white/5 bg-obsidian/60 p-3">
            <div class="text-[10px] uppercase font-bold text-mute tracking-wider">${t("capital_protected_label",e)}</div>
            <div id="metric-dollars-saved" class="text-lg font-black text-brand-300 font-mono mt-0.5">$0.00</div>
          </div>
        </div>
        <div class="mt-2.5">
          <button id="options-share-savings-btn" type="button" class="w-full flex items-center justify-center gap-2 rounded-xl border border-brand-400/40 bg-brand-500/10 hover:bg-brand-500/20 py-2 px-3 text-xs font-bold text-brand-300 shadow-sm transition-all active:scale-[0.99]">
            <svg viewBox="0 0 16 16" fill="currentColor" class="h-3.5 w-3.5 flex-none"><path d="M13.5 1a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 2.5a2.5 2.5 0 0 1 2.5-2.5 2.5 2.5 0 0 1 2.5 2.5c0 1.25-.92 2.3-2.12 2.47l-5.6 2.8a2.5 2.5 0 0 1 0 .46l5.6 2.8c1.2-.17 2.12.88 2.12 2.47a2.5 2.5 0 1 1-5 0c0-.16.02-.31.05-.46l-5.6-2.8A2.5 2.5 0 1 1 5.5 8c0 .16-.02.31-.05.46l5.6 2.8A2.5 2.5 0 0 1 11 13.5"/></svg>
            <span>${t("share_savings_btn",e)} — LinkedIn / X Badge</span>
          </button>
        </div>

        <!-- Active Team Proposals List -->
        <div id="team-pipeline-list" class="space-y-2">
          <!-- Dynamically populated -->
        </div>
      </div>
    </section>

    <!-- Proposal Autopilot & Custom Voice Profile Studio (Module B) -->
    <section class="mb-6 space-y-5 rounded-2xl border border-indigo-500/30 bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-indigo-400">
              🚀 ${t("voice_profile_title",e)}
            </h2>
            <span class="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[9px] font-extrabold text-indigo-300 border border-indigo-500/30">
              PRO FREELANCER
            </span>
          </div>
          <p class="mt-0.5 text-xs text-mute">${t("voice_profile_desc",e)}</p>
        </div>
        <span id="voice-save-status" class="text-xs font-bold text-indigo-400"></span>
      </div>

      <!-- Tone Selector & Custom Instructions -->
      <div class="grid gap-4 sm:grid-cols-2">
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("default_voice_tone_label",e)}</span>
          <div class="relative">
            <select id="voice-tone-select"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-indigo-500/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
              <option value="direct_engineer">${t("tone_direct",e)}</option>
              <option value="consultative_partner">${t("tone_consultative",e)}</option>
              <option value="velocity_exec">${t("tone_velocity",e)}</option>
              <option value="custom">${t("tone_custom",e)}</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>

        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("custom_tone_instructions",e)}</span>
          <input id="voice-custom-instructions" type="text"
            placeholder="${t("custom_tone_placeholder",e)}"
            class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 text-sm text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-indigo-500/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
        </label>
      </div>

      <!-- Interactive Tone Analyzer -->
      <div class="rounded-xl border border-white/5 bg-obsidian/70 p-4 space-y-3">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-slate-300">${t("auto_tone_analyzer_title",e)}</span>
          <span id="tone-analysis-badge" class="text-[10px] font-bold text-slate-400">${t("tone_calibration_hint",e)}</span>
        </div>
        <textarea id="tone-sample-input" rows="3"
          placeholder="${t("paste_sample_proposal_placeholder",e)}"
          class="w-full rounded-xl border border-edge bg-obsidian/90 px-3.5 py-2.5 text-xs text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-indigo-500/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"></textarea>
        <div class="flex items-center justify-between">
          <button id="tone-analyze-btn" type="button"
            class="rounded-xl border border-indigo-500/40 bg-indigo-500/15 px-4 py-1.5 text-xs font-bold text-indigo-300 transition-all duration-150 hover:bg-indigo-500/25 active:scale-95">
            ${t("analyze_tone_btn",e)}
          </button>
          <div id="tone-traits-display" class="text-xs text-slate-300 font-mono hidden"></div>
        </div>
      </div>

      <!-- Portfolio Case Studies Manager -->
      <div class="space-y-3 pt-2">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-xs font-bold text-slate-200">💼 ${t("case_studies_title",e)}</h3>
            <p class="text-[11px] text-mute">${t("case_studies_sub",e)}</p>
          </div>
          <button id="seed-case-studies-btn" type="button"
            class="rounded-lg border border-edge bg-raised px-3 py-1 text-xs font-semibold text-slate-300 hover:border-brand-500/40 hover:text-white transition-all">
            ${t("seed_case_studies_btn",e)}
          </button>
        </div>

        <!-- Add Case Study Form -->
        <div class="rounded-xl border border-white/5 bg-obsidian/50 p-3.5 space-y-2.5">
          <div class="grid gap-2.5 sm:grid-cols-2">
            <input id="cs-title-input" type="text" placeholder="${t("case_study_title_label",e)}"
              class="rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
            <input id="cs-tags-input" type="text" placeholder="${t("case_study_tags_label",e)}"
              class="rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
          </div>
          <div class="grid gap-2.5 sm:grid-cols-2">
            <input id="cs-problem-input" type="text" placeholder="${t("case_study_problem_label",e)}"
              class="rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
            <input id="cs-metrics-input" type="text" placeholder="${t("case_study_metrics_label",e)}"
              class="rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
          </div>
          <div class="flex items-center gap-2">
            <input id="cs-link-input" type="url" placeholder="${t("case_study_link_label",e)}"
              class="flex-1 rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
            <button id="add-case-study-btn" type="button"
              class="rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-indigo-500 active:scale-95 transition-all">
              ${t("add_case_study_btn",e)}
            </button>
          </div>
        </div>

        <!-- Case Studies List -->
        <div id="case-studies-list" class="space-y-2">
          <!-- Dynamically populated -->
        </div>
      </div>
    </section>

    <!-- Predictive Bid Intelligence & Connects ROI Simulator (Module C) -->
    <section class="mb-6 space-y-5 rounded-2xl border border-sky-500/30 bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-sky-400">
              📈 ${t("bid_simulator_title",e)}
            </h2>
            <span class="rounded bg-sky-500/20 px-1.5 py-0.5 text-[9px] font-extrabold text-sky-300 border border-sky-500/30">
              ${t("bid_intel_badge",e)}
            </span>
          </div>
          <p class="mt-0.5 text-xs text-mute">${t("bid_simulator_desc",e)}</p>
        </div>
      </div>

      <!-- Controls Grid -->
      <div class="grid gap-4 sm:grid-cols-3">
        <label class="block space-y-1.5">
          <div class="flex justify-between text-xs">
            <span class="font-semibold text-slate-300">${t("contract_value_label",e)}</span>
            <span id="sim-budget-val" class="font-mono font-bold text-sky-400">$1,500</span>
          </div>
          <input id="sim-budget-slider" type="range" min="100" max="10000" step="100" value="1500"
            class="w-full accent-sky-500 cursor-pointer" />
        </label>

        <label class="block space-y-1.5">
          <div class="flex justify-between text-xs">
            <span class="font-semibold text-slate-300">${t("client_hire_rate_label",e)}</span>
            <span id="sim-hirerate-val" class="font-mono font-bold text-emerald-400">65%</span>
          </div>
          <input id="sim-hirerate-slider" type="range" min="0" max="100" step="5" value="65"
            class="w-full accent-emerald-500 cursor-pointer" />
        </label>

        <label class="block space-y-1.5">
          <div class="flex justify-between text-xs">
            <span class="font-semibold text-slate-300">${t("competition_label",e)}</span>
            <span id="sim-proposals-val" class="font-mono font-bold text-indigo-400">18 proposals</span>
          </div>
          <input id="sim-proposals-slider" type="range" min="1" max="60" step="1" value="18"
            class="w-full accent-indigo-500 cursor-pointer" />
        </label>
      </div>

      <!-- Output Simulation Dashboard -->
      <div class="rounded-xl border border-white/5 bg-obsidian/70 p-4 space-y-3.5">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span id="sim-strategy-badge" class="rounded px-2 py-0.5 text-[10px] font-black uppercase font-mono border"></span>
            <span id="sim-recommended-bid" class="text-xs font-bold text-white"></span>
          </div>
          <span id="sim-roi-ratio" class="text-xs font-mono font-extrabold text-amber-400"></span>
        </div>

        <div class="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <div class="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
            <div class="text-[9.5px] font-bold text-mute uppercase tracking-wider">${t("win_probability_label",e)}</div>
            <div id="sim-win-prob" class="text-base font-black text-emerald-400 font-mono mt-0.5">0%</div>
          </div>
          <div class="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
            <div class="text-[9.5px] font-bold text-mute uppercase tracking-wider">${t("organic_win_label",e)}</div>
            <div id="sim-org-prob" class="text-base font-black text-slate-300 font-mono mt-0.5">0%</div>
          </div>
          <div class="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
            <div class="text-[9.5px] font-bold text-mute uppercase tracking-wider">${t("expected_value_label",e)}</div>
            <div id="sim-expected-value" class="text-base font-black text-brand-300 font-mono mt-0.5">$0</div>
          </div>
          <div class="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
            <div class="text-[9.5px] font-bold text-mute uppercase tracking-wider">${t("break_even_win_label",e)}</div>
            <div id="sim-breakeven" class="text-base font-black text-slate-400 font-mono mt-0.5">0%</div>
          </div>
        </div>

        <p id="sim-verdict" class="text-xs text-slate-300 leading-relaxed bg-white/[0.02] border border-white/5 p-3 rounded-lg"></p>

        <!-- Dynamic Visual Curve -->
        <div class="space-y-1">
          <div class="text-[10px] uppercase font-bold text-mute tracking-wider">Win Probability & EV by Boost Bid</div>
          <div id="sim-curve-container" class="flex gap-1.5 items-end h-20 pt-2 border-b border-white/10 pb-1">
            <!-- Dynamically populated bars -->
          </div>
        </div>
      </div>
    </section>

    <!-- AI Proposal Polisher (BYOK) Section -->
    <section class="mb-6 space-y-5 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("ai_polish_title",e)}</h2>

      <label class="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-edge bg-raised/80 px-4 py-3 transition-colors duration-150 hover:border-brand-500/30">
        <span class="text-sm font-semibold text-white">
          ${t("enable_ai_polish",e)}
          <span class="mt-0.5 block text-xs font-normal text-mute">${t("ai_polish_note",e)}</span>
        </span>
        <input id="byok-enabled" type="checkbox" class="peer sr-only" />
        <span class="relative h-6 w-11 flex-none rounded-full bg-slate-700 transition-colors duration-200 after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow-md after:transition-transform after:duration-200 peer-checked:bg-brand-500 peer-checked:after:translate-x-5 peer-focus-visible:ring-2 peer-focus-visible:ring-brand-400"></span>
      </label>

      <p class="-mt-2 text-xs leading-relaxed text-mute">
        ${t("ai_polish_help",e)}
      </p>

      <div class="grid gap-4 sm:grid-cols-2">
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("provider",e)}</span>
          <div class="relative">
            <select id="provider"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
              <option value="openai">OpenAI</option>
              <option value="anthropic">Anthropic</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>

        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("api_key",e)}</span>
          <input id="api-key" type="password" placeholder="sk-…" autocomplete="off" spellcheck="false"
            class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 text-sm text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20" />
        </label>
      </div>

      <div class="flex flex-wrap items-center gap-3 pt-1">
        <button id="save"
          class="rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-5 py-2 text-sm font-black text-slate-950 shadow-[0_0_16px_rgba(16,185,129,0.25)] transition-all duration-150 hover:shadow-[0_0_24px_rgba(16,185,129,0.45)] hover:scale-[1.01] active:scale-[.98]">
          ${t("save",e)}
        </button>
        <button id="byok-test" type="button"
          class="rounded-xl border border-edge bg-raised px-4 py-2 text-sm font-semibold text-slate-200 transition-colors duration-150 hover:border-brand-500/40 hover:bg-raised/80 hover:text-white active:scale-[.99]">
          ${t("test_connection",e)}
        </button>
        <span id="save-status" class="text-xs font-bold text-brand-400"></span>
      </div>
    </section>

    <!-- Background RSS Scanner Section -->
    <section class="space-y-5 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("scanner_title",e)}</h2>

      <label class="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-edge bg-raised/80 px-4 py-3 transition-colors duration-150 hover:border-brand-500/30">
        <span class="text-sm font-semibold text-white">
          ${t("scanner_toggle",e)}
          <span class="mt-0.5 block text-xs font-normal text-mute">${t("scanner_note",e)}</span>
        </span>
        <input id="scanner-enabled" type="checkbox" class="peer sr-only" />
        <span class="relative h-6 w-11 flex-none rounded-full bg-slate-700 transition-colors duration-200 after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow-md after:transition-transform after:duration-200 peer-checked:bg-brand-500 peer-checked:after:translate-x-5 peer-focus-visible:ring-2 peer-focus-visible:ring-brand-400"></span>
      </label>

      <label class="block space-y-2">
        <span class="text-xs font-semibold text-mute">${t("scanner_rss_label",e)}</span>
        <input id="scanner-rss" type="url" placeholder="https://www.upwork.com/nx/search/jobs/rss?q=…" autocomplete="off" spellcheck="false"
          class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 text-sm text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20" />
        <span class="block text-xs leading-relaxed text-mute">${t("scanner_rss_help",e)}</span>
      </label>

      <div class="grid gap-4 sm:grid-cols-3">
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("check_every",e)}</span>
          <div class="relative">
            <select id="scanner-interval"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
              <option value="3">3 minutes</option>
              <option value="5">5 minutes</option>
              <option value="10">10 minutes</option>
              <option value="15">15 minutes</option>
              <option value="30">30 minutes</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("min_score",e)}</span>
          <div class="relative">
            <select id="scanner-min-score"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
              <option value="80">80 (strict)</option>
              <option value="70">70</option>
              <option value="60">60 (loose)</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("posted_within",e)}</span>
          <div class="relative">
            <select id="scanner-fresh"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
              <option value="5">5 minutes</option>
              <option value="10">10 minutes</option>
              <option value="30">30 minutes</option>
              <option value="60">1 hour</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>
      </div>

      <div class="flex flex-wrap items-center gap-3 pt-1">
        <button id="scanner-save"
          class="rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-5 py-2 text-sm font-black text-slate-950 shadow-[0_0_16px_rgba(16,185,129,0.25)] transition-all duration-150 hover:shadow-[0_0_24px_rgba(16,185,129,0.45)] hover:scale-[1.01] active:scale-[.98]">
          ${t("save",e)}
        </button>
        <button id="scanner-test"
          class="rounded-xl border border-edge bg-raised px-4 py-2 text-sm font-semibold text-slate-200 transition-colors duration-150 hover:border-brand-500/40 hover:bg-raised/80 hover:text-white active:scale-[.99]">
          ${t("run_test_scan",e)}
        </button>
        <span id="scanner-status" class="text-xs font-bold text-brand-400"></span>
      </div>
    </section>

    <!-- Agency Lead Inbox & Pipeline (Module D) -->
    <section class="space-y-5 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-edge/60 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("lead_inbox_title",e)}</h2>
            <span class="rounded bg-indigo-500/20 px-1.5 py-0.5 font-mono text-[9px] font-bold text-indigo-400 border border-indigo-500/30">AGENCY CRM</span>
          </div>
          <p class="mt-0.5 text-xs text-mute">${t("lead_inbox_desc",e)}</p>
        </div>
        <div class="flex items-center gap-2">
          <button id="export-csv-btn" class="rounded-xl border border-edge bg-raised px-3 py-1.5 text-xs font-bold text-slate-200 hover:border-brand-500/40 hover:text-white transition-all">
            ${t("export_csv_btn",e)}
          </button>
          <button id="export-json-btn" class="rounded-xl border border-edge bg-raised px-3 py-1.5 text-xs font-bold text-slate-200 hover:border-brand-500/40 hover:text-white transition-all">
            ${t("export_json_btn",e)}
          </button>
          <button id="refresh-pipeline-btn" class="rounded-xl border border-edge bg-raised px-3 py-1.5 text-xs font-bold text-slate-200 hover:border-brand-500/40 hover:text-white transition-all">
            ${t("refresh_leads_btn",e)}
          </button>
        </div>
      </div>

      <!-- Pipeline KPIs -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div class="rounded-xl border border-edge/80 bg-raised/50 p-3">
          <div class="text-[10px] font-bold uppercase text-slate-400">${t("active_claims_count",e)}</div>
          <div id="kpi-active-claims" class="text-lg font-black text-white mt-0.5">0</div>
        </div>
        <div class="rounded-xl border border-edge/80 bg-raised/50 p-3">
          <div class="text-[10px] font-bold uppercase text-slate-400">${t("pipeline_total_value",e)}</div>
          <div id="kpi-pipeline-value" class="text-lg font-black text-emerald-400 mt-0.5">$0</div>
        </div>
        <div class="rounded-xl border border-edge/80 bg-raised/50 p-3">
          <div class="text-[10px] font-bold uppercase text-slate-400">${t("connects_saved_label",e)}</div>
          <div id="kpi-connects-saved" class="text-lg font-black text-sky-400 mt-0.5">0</div>
        </div>
        <div class="rounded-xl border border-edge/80 bg-raised/50 p-3">
          <div class="text-[10px] font-bold uppercase text-slate-400">${t("capital_protected_label",e)}</div>
          <div id="kpi-dollars-saved" class="text-lg font-black text-brand-400 mt-0.5">$0</div>
        </div>
      </div>

      <!-- Filters & Search -->
      <div class="flex flex-wrap items-center gap-3">
        <input id="lead-search" type="text" placeholder="Search by title, client, or BD…" class="flex-1 min-w-[200px] rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-brand-500/60 focus:outline-none" />
        <select id="lead-status-filter" class="rounded-xl border border-edge bg-obsidian px-3 py-2 text-xs text-ink focus:border-brand-500/60 focus:outline-none">
          <option value="all">${t("filter_all_status",e)}</option>
          <option value="drafting">${t("status_drafting",e)}</option>
          <option value="applied">${t("status_applied",e)}</option>
          <option value="viewing">${t("status_viewing",e)}</option>
          <option value="passed">${t("status_passed",e)}</option>
        </select>
      </div>

      <!-- Leads List Container -->
      <div id="leads-container" class="space-y-3 max-h-[420px] overflow-y-auto pr-1"></div>
    </section>

    <!-- Real-time Webhooks & CRM Sync (Module D) -->
    <section class="space-y-5 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="border-b border-edge/60 pb-3">
        <div class="flex items-center gap-2">
          <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("webhook_settings_title",e)}</h2>
          <span class="rounded bg-sky-500/20 px-1.5 py-0.5 font-mono text-[9px] font-bold text-sky-400 border border-sky-500/30">SLACK / DISCORD / CRM</span>
        </div>
        <p class="mt-0.5 text-xs text-mute">${t("webhook_settings_desc",e)}</p>
      </div>

      <!-- Slack Endpoint -->
      <div class="space-y-2">
        <div class="flex items-center justify-between">
          <label for="slack-url" class="text-xs font-semibold text-mute">${t("slack_webhook_label",e)}</label>
          <button id="test-slack-btn" type="button" class="text-[11px] font-bold text-sky-400 hover:text-sky-300 transition-colors">
            ${t("test_webhook_btn",e)}
          </button>
        </div>
        <input id="slack-url" type="url" placeholder="https://hooks.slack.com/services/T.../B.../X..." autocomplete="off" spellcheck="false" class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-brand-500/60 focus:outline-none" />
      </div>

      <!-- Discord Endpoint -->
      <div class="space-y-2">
        <div class="flex items-center justify-between">
          <label for="discord-url" class="text-xs font-semibold text-mute">${t("discord_webhook_label",e)}</label>
          <button id="test-discord-btn" type="button" class="text-[11px] font-bold text-indigo-400 hover:text-indigo-300 transition-colors">
            ${t("test_webhook_btn",e)}
          </button>
        </div>
        <input id="discord-url" type="url" placeholder="https://discord.com/api/webhooks/123.../..." autocomplete="off" spellcheck="false" class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-brand-500/60 focus:outline-none" />
      </div>

      <!-- Custom Webhook Endpoint -->
      <div class="space-y-2">
        <div class="flex items-center justify-between">
          <label for="custom-url" class="text-xs font-semibold text-mute">${t("custom_webhook_label",e)}</label>
          <button id="test-custom-btn" type="button" class="text-[11px] font-bold text-teal-400 hover:text-teal-300 transition-colors">
            ${t("test_webhook_btn",e)}
          </button>
        </div>
        <input id="custom-url" type="url" placeholder="https://api.youragency.com/leads/webhook" autocomplete="off" spellcheck="false" class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-brand-500/60 focus:outline-none" />
      </div>

      <!-- Trigger Rules & Threshold -->
      <div class="grid sm:grid-cols-2 gap-3 pt-2">
        <label class="flex items-center gap-3 cursor-pointer rounded-xl border border-edge/80 bg-raised/40 p-3 hover:border-brand-500/30 transition-colors">
          <input id="notify-claim" type="checkbox" class="h-4 w-4 rounded border-edge text-brand-500 focus:ring-0 focus:outline-none" />
          <span class="text-xs text-slate-200">${t("notify_claim_label",e)}</span>
        </label>
        <label class="flex items-center gap-3 cursor-pointer rounded-xl border border-edge/80 bg-raised/40 p-3 hover:border-brand-500/30 transition-colors">
          <input id="notify-applied" type="checkbox" class="h-4 w-4 rounded border-edge text-brand-500 focus:ring-0 focus:outline-none" />
          <span class="text-xs text-slate-200">${t("notify_applied_label",e)}</span>
        </label>
        <label class="flex items-center gap-3 cursor-pointer rounded-xl border border-edge/80 bg-raised/40 p-3 hover:border-brand-500/30 transition-colors">
          <input id="notify-high-value" type="checkbox" class="h-4 w-4 rounded border-edge text-brand-500 focus:ring-0 focus:outline-none" />
          <span class="text-xs text-slate-200">${t("notify_high_value_label",e)}</span>
        </label>
        <label class="flex items-center gap-3 cursor-pointer rounded-xl border border-edge/80 bg-raised/40 p-3 hover:border-brand-500/30 transition-colors">
          <input id="notify-collision" type="checkbox" class="h-4 w-4 rounded border-edge text-brand-500 focus:ring-0 focus:outline-none" />
          <span class="text-xs text-slate-200">${t("notify_collision_label",e)}</span>
        </label>
      </div>

      <div class="flex items-center justify-between gap-4 pt-1">
        <label class="flex items-center gap-3">
          <span class="text-xs font-semibold text-mute">${t("high_value_threshold_label",e)}</span>
          <input id="high-value-threshold" type="number" min="100" step="100" value="1000" class="w-28 rounded-xl border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink font-mono" />
        </label>

        <div class="flex items-center gap-3">
          <button id="save-webhooks-btn" class="rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-4 py-2 text-xs font-black text-slate-950 shadow hover:shadow-lg transition-all">
            ${t("save",e)}
          </button>
          <span id="webhook-save-status" class="text-xs font-bold text-brand-400"></span>
        </div>
      </div>
    </section>
  `;const b=document.getElementById("lang-save-status");document.querySelectorAll("button[data-option-lang]").forEach(s=>{s.addEventListener("click",async()=>{const n=s.dataset.optionLang;n&&(await Mt(n),b&&(b.textContent=`${t("saved",n)} ✓`),at())})});const $=document.getElementById("license-status"),R=document.getElementById("buy"),c=document.getElementById("save-status"),W=document.getElementById("byok-enabled"),O=document.getElementById("provider"),N=document.getElementById("api-key");async function Le(){if($)try{const s=await He();R&&(R.hidden=s),$.textContent=s?t("license_status_pro",e):t("license_status_free",e)}catch{const s=await Ze();R&&(R.hidden=s),$.textContent=s?t("license_status_pro",e):t("license_status_unknown",e)}}(Me=document.getElementById("buy"))==null||Me.addEventListener("click",()=>{xt()||$&&($.textContent="Payment window unavailable — verify the ExtensionPay extension ID in src/monetization/extpay.ts.")}),(Re=document.getElementById("recheck"))==null||Re.addEventListener("click",()=>{He(!0).then(s=>{$&&($.textContent=s?t("license_status_pro",e):t("license_status_free",e))}).catch(()=>void Le())}),(Oe=document.getElementById("save"))==null||Oe.addEventListener("click",async()=>{if(!W||!O||!N||!c)return;const s=W.checked,n=N.value.trim();if(s&&!n){c.className="text-xs text-red-400",c.textContent="Add an API key or disable the toggle.";return}if(s&&!(await Ke()?!0:await Fe())){W.checked=!1,c.className="text-xs text-amber-300",c.textContent="Host permission denied — AI polish stays off.";return}await ft({enabled:s,provider:O.value,apiKey:n}),!n&&s===!1&&(N.value=""),c.className="text-xs font-bold text-brand-400",c.textContent="Saved ✓",window.setTimeout(()=>{c&&(c.textContent="")},1600)}),(qe=document.getElementById("byok-test"))==null||qe.addEventListener("click",async()=>{if(!c||!O||!N)return;if(!(await Ke()?!0:await Fe())){c.className="text-xs text-amber-300",c.textContent="Host permission denied — cannot test.";return}let r=N.value.trim();if(r||(r=(await Ge()).apiKey),!r){c.className="text-xs text-red-400",c.textContent="Enter an API key first.";return}c.className="text-xs text-mute",c.textContent="Testing connection…";try{const l=await chrome.runtime.sendMessage({type:"BYOK_POLISH",prompt:"Connection verification ping. Respond with: OK",provider:O.value,apiKey:r});if(!l)throw new Error("No response from background worker.");l.ok?(c.className="text-xs font-bold text-brand-400",c.textContent="Connection verified ✓",window.setTimeout(()=>{c&&c.textContent==="Connection verified ✓"&&(c.textContent="")},3200)):(c.className="text-xs text-red-400",c.textContent=`Test failed: ${l.text||"API rejected key"}`)}catch(l){c.className="text-xs text-red-400",c.textContent=`Error: ${l instanceof Error?l.message:String(l)}`}}),(async()=>{const s=await Ge();W&&(W.checked=s.enabled),O&&(O.value=s.provider),N&&s.apiKey&&(N.placeholder="•••• saved ••••")})();const H=document.getElementById("scanner-enabled"),K=document.getElementById("scanner-rss"),ne=document.getElementById("scanner-interval"),ae=document.getElementById("scanner-min-score"),oe=document.getElementById("scanner-fresh"),j=document.getElementById("scanner-status");function U(s,n){j&&(j.className=n?"text-xs text-red-400":"text-xs font-bold text-brand-400",j.textContent=s,window.setTimeout(()=>{j&&(j.textContent="")},3200))}(De=document.getElementById("scanner-save"))==null||De.addEventListener("click",async()=>{if(!H||!K||!ne||!ae||!oe)return;const s=H.checked,n=K.value.trim();if(s&&!n.startsWith("https://")){U("Paste a valid https RSS URL first.",!0);return}if(s&&!(await chrome.permissions.contains({origins:["https://www.upwork.com/*"]})?!0:await chrome.permissions.request({origins:["https://www.upwork.com/*"]}))){H.checked=!1,U("Upwork host permission denied — scanner stays off.",!0);return}await jt({enabled:s,rssUrl:n,intervalMin:parseInt(ne.value,10),minScore:parseInt(ae.value,10),freshMinutes:parseInt(oe.value,10)});try{await chrome.runtime.sendMessage({type:"SCANNER_SETTINGS_UPDATED"})}catch{return}U(s?"Scanner armed ✓":"Scanner off",!1)}),(Ve=document.getElementById("scanner-test"))==null||Ve.addEventListener("click",async()=>{if(j){j.className="text-xs text-mute",j.textContent="Scanning…";try{const s=await chrome.runtime.sendMessage({type:"SCANNER_SCAN_NOW"});if(!s)throw new Error("no response");s.error?U(`Scan failed: ${s.error}`,!0):s.fetched?U(`Feed OK — ${s.notified} new high-intent job${s.notified===1?"":"s"}`,!1):U("Scanner is disabled — save it enabled first.",!0)}catch{U("No response from background worker.",!0)}}}),(async()=>{const s=await Pt();H&&(H.checked=s.enabled),K&&(K.value=s.rssUrl),ne&&(ne.value=String(s.intervalMin)),ae&&(ae.value=String(s.minScore)),oe&&(oe.value=String(s.freshMinutes)),K&&!s.rssUrl&&Nt.rssUrl})(),Le();const re=document.getElementById("account-tier-label"),ie=document.getElementById("account-tier-badge"),T=document.getElementById("cloud-sync-status"),Ie=document.getElementById("account-user-email"),be=document.getElementById("team-info-box"),Ae=document.getElementById("team-name-label"),Te=document.getElementById("team-seats-badge"),Be=document.getElementById("team-intel-count"),F=document.getElementById("account-token-input"),xe=document.getElementById("account-connect-btn"),me=document.getElementById("account-sync-btn"),q=document.getElementById("account-disconnect-btn"),G=document.getElementById("account-status-msg"),je=document.getElementById("metric-collisions-prevented"),Pe=document.getElementById("metric-connects-saved"),Ne=document.getElementById("metric-dollars-saved"),de=document.getElementById("team-pipeline-list"),ge=document.getElementById("simulate-team-activity-btn"),fe=document.getElementById("clear-team-pipeline-btn");function C(s,n){G&&(G.className=n?"text-xs text-red-400":"text-xs font-bold text-brand-400",G.textContent=s,window.setTimeout(()=>{G&&(G.textContent="")},3200))}async function M(){const s=await st(),n=await St(),r=await qt(),l=await Ce(),f=await Ye(),x=await ee();if(re&&ie&&(n==="agency"?(re.textContent=t("tier_agency",e),ie.className="inline-flex items-center gap-1.5 rounded-full border border-purple-500/40 bg-purple-500/15 px-2.5 py-1 text-xs font-bold text-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.25)]"):n==="pro_freelancer"?(re.textContent=t("tier_pro",e),ie.className="inline-flex items-center gap-1.5 rounded-full border border-brand-500/40 bg-brand-500/15 px-2.5 py-1 text-xs font-bold text-brand-300 shadow-[0_0_12px_rgba(16,185,129,0.25)]"):(re.textContent=t("tier_free",e),ie.className="inline-flex items-center gap-1.5 rounded-full border border-slate-700 bg-slate-800/80 px-2.5 py-1 text-xs font-bold text-slate-400")),Ie&&(Ie.textContent=s.email||s.userId),T)if(r.syncStatus==="synced"){const i=r.lastSyncedAt?new Date(r.lastSyncedAt).toLocaleTimeString():"";T.className="font-bold text-brand-400 flex items-center gap-1.5",T.innerHTML=`<span class="h-2 w-2 rounded-full bg-brand-400 shadow-[0_0_6px_rgba(16,185,129,0.6)]"></span> ${t("sync_status_synced",e)} ${i?`(${i})`:""}`}else r.syncStatus==="syncing"?(T.className="font-bold text-amber-300 flex items-center gap-1.5",T.innerHTML='<span class="h-2 w-2 rounded-full bg-amber-400 animate-ping"></span> Syncing…'):r.syncStatus==="error"?(T.className="font-bold text-red-400 flex items-center gap-1.5",T.innerHTML=`<span class="h-2 w-2 rounded-full bg-red-400"></span> ${r.errorMessage||"Sync error"}`):(T.className="font-bold text-slate-400 flex items-center gap-1.5",T.innerHTML=`<span class="h-2 w-2 rounded-full bg-slate-500"></span> ${t("sync_status_offline",e)}`);be&&(n==="agency"?(be.classList.remove("hidden"),Ae&&(Ae.textContent=s.teamName||"Agency Workspace"),Te&&(Te.textContent=`${s.activeSeats??1} / ${s.seatLimit??10} seats`),Be&&(Be.textContent=`${l.length} flagged clients`)):be.classList.add("hidden")),je&&(je.textContent=String(f.collisionsPrevented)),Pe&&(Pe.textContent=String(f.connectsSaved)),Ne&&(Ne.textContent=`$${f.dollarsSaved.toFixed(2)}`);const u=document.getElementById("options-share-savings-btn");u&&!u.dataset.bound&&(u.dataset.bound="true",u.addEventListener("click",async()=>{const i=await nt(),m=i*Rt,g=await Ze()&&m>=9.99?(m/9.99).toFixed(1):void 0;mt({connectsSaved:i,dollarsSaved:m,proRoiMultiplier:g,locale:e},e)})),de&&(x.length===0?de.innerHTML=`
          <div class="rounded-xl border border-white/5 bg-obsidian/30 p-4 text-center text-xs text-mute">
            ${t("team_pipeline_empty",e)}
          </div>`:(de.innerHTML=x.map(i=>{const m=i.status==="applied"?"bg-emerald-500/20 text-emerald-300 border-emerald-500/30":i.status==="drafting"?"bg-purple-500/20 text-purple-300 border-purple-500/30":"bg-slate-500/20 text-slate-300 border-slate-500/30",h=Je(i.updatedAt);return`
              <div class="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-obsidian/50 p-3 hover:border-purple-500/30 transition-colors">
                <div class="min-w-0 flex-1">
                  <div class="flex items-center gap-2">
                    <span class="rounded px-1.5 py-0.5 text-[9.5px] font-black uppercase font-mono border ${m}">
                      ${i.status}
                    </span>
                    <span class="text-xs font-bold text-white truncate">${_(i.jobTitle)}</span>
                  </div>
                  <div class="text-[11px] text-mute flex items-center gap-2 mt-1">
                    <span>👤 <b class="text-slate-200">${_(i.memberName)}</b></span>
                    <span>•</span>
                    <span>${_(h)}</span>
                    ${i.clientName?`<span>•</span><span>🏢 ${_(i.clientName)}</span>`:""}
                  </div>
                </div>
                <button type="button" data-release-job="${_(i.jobId)}"
                  class="flex-none rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[10.5px] font-semibold text-slate-400 hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300 transition-colors">
                  ${t("clear_btn",e)}
                </button>
              </div>`}).join(""),de.querySelectorAll("[data-release-job]").forEach(i=>{i.addEventListener("click",async m=>{m.stopPropagation();const h=i.getAttribute("data-release-job");h&&(await Xe(h),await M())})}))),q&&(s.tier!=="free"||s.licenseToken?q.classList.remove("hidden"):q.classList.add("hidden"))}xe==null||xe.addEventListener("click",async()=>{const s=F==null?void 0:F.value.trim();if(!s){C("Enter a token first.",!0);return}const n=await vt(s);n.success?(F&&(F.value=""),C(`Connected as ${n.profile.tier==="agency"?"Agency Team":"Pro Freelancer"} ✓`,!1),await tt(),await M()):C(n.error||"Connection failed",!0)}),me==null||me.addEventListener("click",async()=>{C("Syncing cloud data…",!1);const s=await tt();s.syncStatus==="synced"?C("Cloud sync completed ✓",!1):s.syncStatus==="offline"?C("Offline mode (Upgrade to Pro/Agency for cloud sync)",!1):C(s.errorMessage||"Sync failed",!0),await M()}),q==null||q.addEventListener("click",async()=>{await yt(),C("Account disconnected",!1),await M()}),ge==null||ge.addEventListener("click",async()=>{await ht(),C("Simulated agency team activity seeded ✓",!1),await M()}),fe==null||fe.addEventListener("click",async()=>{await wt(),C("Team pipeline cleared",!1),await M()});const L=y.querySelector("#voice-tone-select"),P=y.querySelector("#voice-custom-instructions"),ve=y.querySelector("#voice-save-status"),ye=y.querySelector("#tone-sample-input"),I=y.querySelector("#tone-analyze-btn"),le=y.querySelector("#tone-analysis-badge"),D=y.querySelector("#tone-traits-display"),he=y.querySelector("#seed-case-studies-btn"),z=y.querySelector("#cs-title-input"),Y=y.querySelector("#cs-tags-input"),J=y.querySelector("#cs-problem-input"),X=y.querySelector("#cs-metrics-input"),Q=y.querySelector("#cs-link-input"),we=y.querySelector("#add-case-study-btn"),ce=y.querySelector("#case-studies-list");function V(s){ve&&(ve.textContent=s,window.setTimeout(()=>{ve.textContent=""},2500))}async function ot(){const s=await ke();L&&(L.value=s.tone),P&&(P.value=s.customInstructions||""),s.derivedTraits&&D&&(D.classList.remove("hidden"),D.textContent=`Pace: ${s.derivedTraits.sentenceLength} · Style: ${s.derivedTraits.formality} · Focus: ${s.derivedTraits.focusAngle}`)}async function Ue(){const s=await ke(),n=(L==null?void 0:L.value)||"direct_engineer",r=(P==null?void 0:P.value.trim())||void 0;await ze({...s,tone:n,customInstructions:r}),V(t("saved",e))}L==null||L.addEventListener("change",()=>{Ue()}),P==null||P.addEventListener("blur",()=>{Ue()}),I==null||I.addEventListener("click",async()=>{const s=ye==null?void 0:ye.value.trim();if(!s){le&&(le.textContent="Paste proposal text first.");return}I&&(I.disabled=!0,I.textContent=t("analyzing_tone",e));const n=_t(s);le&&(le.textContent=`Tone: ${n.derivedTone.toUpperCase()} · ${n.metricsFrequency.toUpperCase()} Proof`),D&&(D.classList.remove("hidden"),D.textContent=`Sentences: ${n.detectedSentences} (avg ${n.avgSentenceLength} wps) · Formality: ${n.formality} · Focus: ${n.focusAngle}`),L&&(L.value=n.derivedTone);const r=await ke();await ze({...r,tone:n.derivedTone,sampleText:s.slice(0,1e3),derivedTraits:n}),I&&(I.disabled=!1,I.textContent=`✓ ${t("tone_analyzed_success",e)}`,setTimeout(()=>{I.textContent=t("analyze_tone_btn",e)},2500)),V(t("tone_analyzed_success",e))});async function ue(){if(!ce)return;const s=await Et();if(s.length===0){ce.innerHTML=`
        <div class="rounded-xl border border-dashed border-edge p-6 text-center text-xs text-mute">
          ${t("case_studies_empty",e)}
        </div>`;return}ce.innerHTML=s.map(n=>{const l=(Array.isArray(n.tags)?n.tags:[]).map(f=>`<span class="rounded bg-white/5 border border-white/10 px-1.5 py-0.5 text-[10px] text-slate-300">${_(f)}</span>`).join("");return`
          <div class="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-obsidian/70 p-3 hover:border-indigo-500/40 transition-colors">
            <div class="space-y-1 min-w-0">
              <div class="flex items-center gap-2 flex-wrap">
                <span class="text-xs font-bold text-white">${_(n.title)}</span>
                ${l}
              </div>
              <p class="text-[11.5px] text-slate-300 leading-snug">
                <span class="text-mute font-semibold">${t("case_study_problem_prefix",e)}</span> ${_(n.problemSolved)}
              </p>
              <p class="text-[11.5px] text-emerald-300 font-medium leading-snug">
                <span class="text-mute font-semibold">${t("case_study_receipts_prefix",e)}</span> ${_(n.metricsOutcome)}
              </p>
              ${n.proofLink?`<a href="${_(n.proofLink)}" target="_blank" rel="noreferrer" class="text-[10.5px] text-indigo-400 hover:underline">${t("case_study_proof_link",e)}</a>`:""}
            </div>
            <button type="button" data-delete-cs="${_(n.id)}"
              class="flex-none rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] font-semibold text-slate-400 hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300 transition-colors"
              title="${t("clear_btn",e)}">
              🗑️
            </button>
          </div>`}).join(""),ce.querySelectorAll("[data-delete-cs]").forEach(n=>{n.addEventListener("click",async()=>{const r=n.getAttribute("data-delete-cs");r&&(await Ct(r),V(t("case_study_deleted",e)),await ue())})})}he==null||he.addEventListener("click",async()=>{await kt(),V(t("seed_case_studies_success",e)),await ue()}),we==null||we.addEventListener("click",async()=>{const s=z==null?void 0:z.value.trim(),n=J==null?void 0:J.value.trim(),r=X==null?void 0:X.value.trim(),l=(Y==null?void 0:Y.value.trim())||"",f=(Q==null?void 0:Q.value.trim())||void 0;if(!s||!n||!r){V("Title, Problem, and Metrics are required.");return}const x=l.split(/[,]+/).map(u=>u.trim()).filter(u=>u.length>0);await $t({title:s,tags:x.length>0?x:["General"],problemSolved:n,metricsOutcome:r,proofLink:f}),z&&(z.value=""),Y&&(Y.value=""),J&&(J.value=""),X&&(X.value=""),Q&&(Q.value=""),V(t("case_study_saved",e)),await ue()});function rt(){const s=document.querySelector("#sim-budget-slider"),n=document.querySelector("#sim-hirerate-slider"),r=document.querySelector("#sim-proposals-slider"),l=document.querySelector("#sim-budget-val"),f=document.querySelector("#sim-hirerate-val"),x=document.querySelector("#sim-proposals-val"),u=document.querySelector("#sim-strategy-badge"),i=document.querySelector("#sim-recommended-bid"),m=document.querySelector("#sim-roi-ratio"),h=document.querySelector("#sim-win-prob"),g=document.querySelector("#sim-org-prob"),A=document.querySelector("#sim-expected-value"),B=document.querySelector("#sim-breakeven"),v=document.querySelector("#sim-verdict"),k=document.querySelector("#sim-curve-container");if(!s||!n||!r)return;const p=()=>{const w=Number(s.value),a=Number(n.value),d=Number(r.value);l&&(l.textContent=`$${w.toLocaleString()}`),f&&(f.textContent=`${a}%`),x&&(x.textContent=`${d} proposals`);const o=At({budget:{type:"fixed",minUsd:w,maxUsd:w},clientHireRatePct:a,clientPaymentVerified:!0,clientTotalSpendUsd:w*3,proposalCount:d}),S=o.strategy==="AGGRESSIVE_TOP_SLOT"?"bid_strategy_aggressive":o.strategy==="TACTICAL_BOOST"?"bid_strategy_tactical":o.strategy==="ORGANIC_SWEET_SPOT"?"bid_strategy_organic":"bid_strategy_skip",Z=o.strategy==="AGGRESSIVE_TOP_SLOT"?"bg-amber-500/20 text-amber-300 border-amber-500/40":o.strategy==="TACTICAL_BOOST"?"bg-sky-500/20 text-sky-300 border-sky-500/40":o.strategy==="ORGANIC_SWEET_SPOT"?"bg-emerald-500/20 text-emerald-300 border-emerald-500/40":"bg-red-500/20 text-red-300 border-red-500/40";if(u&&(u.className=`rounded px-2 py-0.5 text-[10px] font-black uppercase font-mono border ${Z}`,u.textContent=t(S,e)),i&&(i.textContent=o.recommendedBid>0?`Recommended: ${o.recommendedBid} Connects ($${o.connectsCostUsd.toFixed(2)})`:"Recommended: 0 Connects (Organic)"),m&&(m.textContent=`${o.roiRatio}x Projected ROI`),h&&(h.textContent=`${o.winProbabilityPct}%`),g&&(g.textContent=`${o.organicWinProbabilityPct}%`),A&&(A.textContent=`+$${o.expectedValueUsd>0?o.expectedValueUsd.toFixed(0):"0"}`),B&&(B.textContent=`${o.breakEvenWinRatePct}%`),v&&(v.textContent=o.verdictSummary),k){const _e=Math.max(...o.curve.map(E=>E.winProbabilityPct),1);k.innerHTML=o.curve.map(E=>{const lt=Math.max(10,Math.round(E.winProbabilityPct/_e*100)),ct=E.bidConnects===o.recommendedBid,ut=E.bidConnects===0,pt=ct?"bg-sky-500 shadow-[0_0_10px_rgba(14,165,233,0.5)]":ut?"bg-emerald-500":"bg-slate-700";return`
              <div class="flex-1 flex flex-col items-center justify-end h-full group relative cursor-pointer"
                   title="${E.bidConnects} Connects: ${E.winProbabilityPct}% win, +$${E.expectedValueUsd} EV">
                <div class="w-full rounded-t transition-all duration-200 ${pt}" style="height:${lt}%"></div>
                <span class="text-[9px] font-mono text-slate-400 mt-1">${E.bidConnects}c</span>
              </div>`}).join("")}};s.addEventListener("input",p),n.addEventListener("input",p),r.addEventListener("input",p),p()}async function it(){const s=document.getElementById("leads-container"),n=document.getElementById("kpi-active-claims"),r=document.getElementById("kpi-pipeline-value"),l=document.getElementById("kpi-connects-saved"),f=document.getElementById("kpi-dollars-saved"),x=document.getElementById("lead-search"),u=document.getElementById("lead-status-filter"),i=document.getElementById("export-csv-btn"),m=document.getElementById("export-json-btn"),h=document.getElementById("refresh-pipeline-btn");if(!s)return;let g=await ee();const A=await Ye(),B=k=>{const p=k.filter(a=>a.status==="drafting"||a.status==="applied"),w=k.reduce((a,d)=>a+(d.dealValueUsd??500),0);n&&(n.textContent=String(p.length)),r&&(r.textContent=te(w)),l&&(l.textContent=String(A.connectsSaved)),f&&(f.textContent=te(A.dollarsSaved))},v=()=>{const k=(u==null?void 0:u.value)||"all",p=((x==null?void 0:x.value)||"").toLowerCase().trim(),w=g.filter(a=>{if(k!=="all"&&a.status!==k)return!1;if(p){const d=a.jobTitle.toLowerCase().includes(p),o=(a.clientName||"").toLowerCase().includes(p),S=a.memberName.toLowerCase().includes(p);if(!d&&!o&&!S)return!1}return!0});if(B(g),w.length===0){s.innerHTML=`
          <div class="rounded-xl border border-dashed border-edge/80 p-6 text-center text-xs text-mute">
            ${t("team_pipeline_empty",e)}
          </div>`;return}s.innerHTML=w.map(a=>{const d=a.status==="applied",o=a.status==="drafting",S=a.status==="viewing",Z=d?"bg-emerald-500/15 border-emerald-500/40 text-emerald-300":o?"bg-amber-500/15 border-amber-500/40 text-amber-300":S?"bg-sky-500/15 border-sky-500/40 text-sky-300":"bg-slate-700/40 border-slate-600 text-slate-400",_e=te(a.dealValueUsd??500),E=Je(a.updatedAt);return`
            <div class="rounded-xl border border-edge bg-raised/50 p-4 transition-all hover:border-brand-500/30">
              <div class="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div class="flex items-center gap-2">
                  <span class="rounded px-2 py-0.5 text-[10px] font-extrabold uppercase border ${Z}">
                    ${a.status}
                  </span>
                  <span class="text-xs font-bold text-emerald-400 font-mono">${_e}</span>
                </div>
                <div class="text-[11px] text-slate-400">
                  Claimed by <b class="text-slate-200">${_(a.memberName)}</b> (${E})
                </div>
              </div>

              <div class="text-sm font-bold text-white mb-1">
                ${a.jobUrl?`<a href="${a.jobUrl}" target="_blank" class="hover:text-brand-400 hover:underline transition-colors">${_(a.jobTitle)} ↗</a>`:_(a.jobTitle)}
              </div>

              <div class="text-xs text-mute flex flex-wrap items-center gap-3 mb-3">
                ${a.clientName?`<span>Client: <b class="text-slate-300">${_(a.clientName)}</b></span>`:""}
                ${a.hireRatePct!==void 0&&a.hireRatePct!==null?`<span>Hire Rate: <b class="text-slate-300">${a.hireRatePct}%</b></span>`:""}
                ${a.totalSpendUsd!==void 0&&a.totalSpendUsd!==null?`<span>Spend: <b class="text-slate-300">${te(a.totalSpendUsd)}</b></span>`:""}
              </div>

              <div class="flex flex-wrap items-center gap-2 pt-1 border-t border-edge/40">
                ${a.status!=="applied"?`<button type="button" data-act-applied="${a.jobId}" class="rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 text-[11px] font-bold transition-all">
                        ✓ ${t("status_applied",e)}
                      </button>`:""}
                <button type="button" data-act-release="${a.jobId}" class="rounded-lg border border-edge bg-raised hover:bg-rose-500/20 hover:border-rose-500/40 hover:text-rose-300 px-2.5 py-1 text-[11px] font-bold text-slate-300 transition-all">
                  ✕ ${t("status_passed",e)}
                </button>
                <button type="button" data-act-copy="${a.jobId}" class="rounded-lg border border-edge bg-raised hover:border-brand-500/40 px-2.5 py-1 text-[11px] font-bold text-slate-300 transition-all">
                  📋 Copy Lead
                </button>
              </div>
            </div>`}).join(""),s.querySelectorAll("button[data-act-applied]").forEach(a=>{a.addEventListener("click",async()=>{const d=a.dataset.actApplied;if(!d)return;const o=g.find(S=>S.jobId===d);o&&(await Tt({jobId:o.jobId,jobTitle:o.jobTitle,status:"applied",jobUrl:o.jobUrl,clientName:o.clientName,dealValueUsd:o.dealValueUsd,budget:o.budget,hireRatePct:o.hireRatePct,totalSpendUsd:o.totalSpendUsd,paymentVerified:o.paymentVerified}),g=await ee(),v())})}),s.querySelectorAll("button[data-act-release]").forEach(a=>{a.addEventListener("click",async()=>{const d=a.dataset.actRelease;d&&(await Xe(d),g=await ee(),v())})}),s.querySelectorAll("button[data-act-copy]").forEach(a=>{a.addEventListener("click",async()=>{const d=a.dataset.actCopy;if(!d)return;const o=g.find(Z=>Z.jobId===d);if(!o)return;const S=`Upwork Lead: ${o.jobTitle}
Value: ${te(o.dealValueUsd??500)}
Status: ${o.status}
Assigned: ${o.memberName}
URL: ${o.jobUrl||"N/A"}`;await navigator.clipboard.writeText(S),a.textContent="✓ Copied!",setTimeout(()=>{a.textContent="📋 Copy Lead"},1500)})})};x==null||x.addEventListener("input",v),u==null||u.addEventListener("change",v),h==null||h.addEventListener("click",async()=>{g=await ee(),v()}),i==null||i.addEventListener("click",()=>{if(g.length===0)return;const k=["Job ID","Job Title","Client Name","Deal Value USD","Status","Assigned BD","Member Email","Upwork URL","Updated At"],p=g.map(o=>[`"${o.jobId}"`,`"${(o.jobTitle||"").replace(/"/g,'""')}"`,`"${(o.clientName||"Anonymous").replace(/"/g,'""')}"`,o.dealValueUsd??500,`"${o.status}"`,`"${(o.memberName||"").replace(/"/g,'""')}"`,`"${o.memberEmail||""}"`,`"${o.jobUrl||""}"`,`"${new Date(o.updatedAt).toISOString()}"`]),w="data:text/csv;charset=utf-8,"+[k.join(","),...p.map(o=>o.join(","))].join(`
`),a=encodeURI(w),d=document.createElement("a");d.setAttribute("href",a),d.setAttribute("download",`gigradar-agency-leads-${new Date().toISOString().slice(0,10)}.csv`),document.body.appendChild(d),d.click(),d.remove()}),m==null||m.addEventListener("click",async()=>{g.length!==0&&(await navigator.clipboard.writeText(JSON.stringify(g,null,2)),m&&(m.textContent="✓ Copied JSON!",setTimeout(()=>{m.textContent=t("export_json_btn",e)},1800)))}),v()}async function dt(){const s=document.getElementById("slack-url"),n=document.getElementById("discord-url"),r=document.getElementById("custom-url"),l=document.getElementById("notify-claim"),f=document.getElementById("notify-applied"),x=document.getElementById("notify-high-value"),u=document.getElementById("notify-collision"),i=document.getElementById("high-value-threshold"),m=document.getElementById("save-webhooks-btn"),h=document.getElementById("webhook-save-status"),g=document.getElementById("test-slack-btn"),A=document.getElementById("test-discord-btn"),B=document.getElementById("test-custom-btn"),v=await Lt();s&&(s.value=v.slackWebhookUrl||""),n&&(n.value=v.discordWebhookUrl||""),r&&(r.value=v.customWebhookUrl||""),l&&(l.checked=v.notifyOnClaim),f&&(f.checked=v.notifyOnApplied),x&&(x.checked=v.notifyOnHighValue),u&&(u.checked=v.notifyOnCollision),i&&(i.value=String(v.highValueThresholdUsd||1e3)),m==null||m.addEventListener("click",async()=>{const p=(s==null?void 0:s.value.trim())||"",w=(n==null?void 0:n.value.trim())||"",a=(r==null?void 0:r.value.trim())||"";await Qe([p,w,a]);const d={slackWebhookUrl:p,discordWebhookUrl:w,customWebhookUrl:a,notifyOnClaim:(l==null?void 0:l.checked)??!0,notifyOnApplied:(f==null?void 0:f.checked)??!0,notifyOnHighValue:(x==null?void 0:x.checked)??!0,notifyOnCollision:(u==null?void 0:u.checked)??!0,highValueThresholdUsd:Number(i==null?void 0:i.value)||1e3};await It(d),h&&(h.textContent=t("webhook_saved",e),setTimeout(()=>{h.textContent=""},2200))});const k=async(p,w,a)=>{if(!p||!a)return;const d=a.value.trim();if(!d){alert("Please enter a webhook URL first");return}await Qe([d]);const o=p.textContent;p.textContent="⏳ Testing...";const S=await Bt(w,d);p.textContent=S.success?"✓ Delivered!":"✕ Failed",setTimeout(()=>{p.textContent=o},2500)};g==null||g.addEventListener("click",()=>{k(g,"slack",s)}),A==null||A.addEventListener("click",()=>{k(A,"discord",n)}),B==null||B.addEventListener("click",()=>{k(B,"custom",r)})}rt(),it(),dt(),ot(),ue(),M()}at();
