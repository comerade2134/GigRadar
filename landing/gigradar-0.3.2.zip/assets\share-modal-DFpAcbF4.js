import{E as H}from"./extpay-vendor-CwkHEbPA.js";import{E as $,r as U,s as W,w as O}from"./extpay-core-6aOhiK5e.js";import{t as u}from"./metrics-CxlbnKT_.js";const X=[{code:"en",name:"English",nativeName:"English",flag:"🇬🇧",sublabel:"Global"},{code:"es",name:"Spanish",nativeName:"Español",flag:"🇪🇸",sublabel:"LatAm / España"},{code:"de",name:"German",nativeName:"Deutsch",flag:"🇩🇪",sublabel:"DACH / Europa"},{code:"pt",name:"Portuguese",nativeName:"Português",flag:"🇵🇹",sublabel:"Brasil / Portugal"},{code:"fr",name:"French",nativeName:"Français",flag:"🇫🇷",sublabel:"France & Global"},{code:"ru",name:"Russian",nativeName:"Русский",flag:"🇷🇺",sublabel:"Global"},{code:"ur",name:"Urdu",nativeName:"اردو",flag:"🇵🇰",sublabel:"Pakistan / پاکستان"},{code:"hi",name:"Hindi",nativeName:"हिन्दी",flag:"🇮🇳",sublabel:"India / भारत"}],E={en:`
    <svg viewBox="0 0 60 40" class="h-4 w-6 flex-none overflow-hidden rounded-[3px] shadow-[0_1px_3px_rgba(0,0,0,0.5)] border border-white/10" aria-hidden="true">
      <clipPath id="uk-clip"><rect width="60" height="40" rx="3"/></clipPath>
      <g clip-path="url(#uk-clip)">
        <path fill="#012169" d="M0 0h60v40H0z"/>
        <path stroke="#fff" stroke-width="6" d="M0 0l60 40M60 0L0 40"/>
        <path stroke="#C8102E" stroke-width="3.5" d="M0 0l60 40M60 0L0 40"/>
        <path stroke="#fff" stroke-width="10" d="M30 0v40M0 20h60"/>
        <path stroke="#C8102E" stroke-width="6" d="M30 0v40M0 20h60"/>
      </g>
    </svg>`,es:`
    <svg viewBox="0 0 60 40" class="h-4 w-6 flex-none overflow-hidden rounded-[3px] shadow-[0_1px_3px_rgba(0,0,0,0.5)] border border-white/10" aria-hidden="true">
      <rect width="60" height="40" fill="#AA151B"/>
      <rect y="10" width="60" height="20" fill="#F1BF00"/>
    </svg>`,de:`
    <svg viewBox="0 0 60 40" class="h-4 w-6 flex-none overflow-hidden rounded-[3px] shadow-[0_1px_3px_rgba(0,0,0,0.5)] border border-white/10" aria-hidden="true">
      <rect width="60" height="13.33" fill="#111827"/>
      <rect y="13.33" width="60" height="13.34" fill="#DD0000"/>
      <rect y="26.67" width="60" height="13.33" fill="#FFCE00"/>
    </svg>`,pt:`
    <svg viewBox="0 0 60 40" class="h-4 w-6 flex-none overflow-hidden rounded-[3px] shadow-[0_1px_3px_rgba(0,0,0,0.5)] border border-white/10" aria-hidden="true">
      <rect width="24" height="40" fill="#046A38"/>
      <rect x="24" width="36" height="40" fill="#DA291C"/>
      <circle cx="24" cy="20" r="7.5" fill="#FFC72C" stroke="#DA291C" stroke-width="1.5"/>
    </svg>`,fr:`
    <svg viewBox="0 0 60 40" class="h-4 w-6 flex-none overflow-hidden rounded-[3px] shadow-[0_1px_3px_rgba(0,0,0,0.5)] border border-white/10" aria-hidden="true">
      <rect width="20" height="40" fill="#002395"/>
      <rect x="20" width="20" height="40" fill="#FFFFFF"/>
      <rect x="40" width="20" height="40" fill="#ED2939"/>
    </svg>`,ru:`
    <svg viewBox="0 0 60 40" class="h-4 w-6 flex-none overflow-hidden rounded-[3px] shadow-[0_1px_3px_rgba(0,0,0,0.5)] border border-white/10" aria-hidden="true">
      <rect width="60" height="13.33" fill="#FFFFFF"/>
      <rect y="13.33" width="60" height="13.34" fill="#0039A6"/>
      <rect y="26.67" width="60" height="13.33" fill="#D52B1E"/>
    </svg>`,ur:`
    <svg viewBox="0 0 60 40" class="h-4 w-6 flex-none overflow-hidden rounded-[3px] shadow-[0_1px_3px_rgba(0,0,0,0.5)] border border-white/10" aria-hidden="true">
      <rect width="60" height="40" fill="#01411C"/>
      <rect width="15" height="40" fill="#FFFFFF"/>
      <circle cx="37" cy="20" r="8.5" fill="#FFFFFF"/>
      <circle cx="39" cy="18.5" r="7.5" fill="#01411C"/>
      <polygon points="41,15 42,17.5 45,17.5 43,19.5 44,22 41,20.5 38,22 39,19.5 37,17.5 40,17.5" fill="#FFFFFF"/>
    </svg>`,hi:`
    <svg viewBox="0 0 60 40" class="h-4 w-6 flex-none overflow-hidden rounded-[3px] shadow-[0_1px_3px_rgba(0,0,0,0.5)] border border-white/10" aria-hidden="true">
      <rect width="60" height="13.33" fill="#FF9933"/>
      <rect y="13.33" width="60" height="13.34" fill="#FFFFFF"/>
      <rect y="26.67" width="60" height="13.33" fill="#138808"/>
      <circle cx="30" cy="20" r="4.5" fill="none" stroke="#000080" stroke-width="1.2"/>
      <circle cx="30" cy="20" r="1.5" fill="#000080"/>
    </svg>`};function Y(i){return E[i]||E.en}(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))o(a);new MutationObserver(a=>{for(const r of a)if(r.type==="childList")for(const c of r.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&o(c)}).observe(document,{childList:!0,subtree:!0});function e(a){const r={};return a.integrity&&(r.integrity=a.integrity),a.referrerPolicy&&(r.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?r.credentials="include":a.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function o(a){if(a.ep)return;a.ep=!0;const r=e(a);fetch(a.href,r)}})();const L=H($);async function Z(i=!1){const t=await U();if(!W(t,i))return t.paid;let e;try{const o=await L.getUser();e=!!o.paid||o.subscriptionStatus==="active"}catch{return!!(t!=null&&t.paid)}return await O(e),e}function K(){try{return L.openPaymentPage(),!0}catch{return!1}}const P="https://chromewebstore.google.com/detail/nheegeimgmgkbklpgbhipdkmfoedflnm?utm_source=item-share-cb",x=1200,m=630;function I(i){const t=i.dollarsSaved.toFixed(2),e=i.proRoiMultiplier?` (${i.proRoiMultiplier}x ROI on Pro)`:"";return`Upwork Connects are getting out of hand.

GigRadar just protected ${i.connectsSaved} Connects (~$${t}${e}) from ghost listings and scam jobs for me so far.

Get GigRadar on Chrome Web Store: ${P}

#Upwork #Freelancing #GigRadar`}function R(i,t){i.width=x,i.height=m;const e=i.getContext("2d");if(!e)return;e.fillStyle="#0D0F12",e.fillRect(0,0,x,m);const o=e.createRadialGradient(950,150,10,950,150,480);o.addColorStop(0,"rgba(16, 185, 129, 0.18)"),o.addColorStop(.5,"rgba(5, 150, 105, 0.06)"),o.addColorStop(1,"rgba(13, 15, 18, 0)"),e.fillStyle=o,e.fillRect(0,0,x,m);const a=e.createRadialGradient(250,500,10,250,500,360);a.addColorStop(0,"rgba(52, 211, 153, 0.10)"),a.addColorStop(1,"rgba(13, 15, 18, 0)"),e.fillStyle=a,e.fillRect(0,0,x,m);const r=48,c=x-r*2,w=m-r*2,h=24;e.save(),e.beginPath(),e.roundRect(r,r,c,w,h),e.fillStyle="#12151C",e.fill(),e.lineWidth=2,e.strokeStyle="#1F242D",e.stroke(),e.clip(),e.beginPath(),e.moveTo(r+h,r+1),e.lineTo(r+c-h,r+1),e.strokeStyle="rgba(255, 255, 255, 0.08)",e.lineWidth=1.5,e.stroke();const n=r+44,l=r+44,p=64,v=18;e.beginPath(),e.roundRect(n,l,p,p,v),e.fillStyle="#161A22",e.fill(),e.lineWidth=2,e.strokeStyle="rgba(16, 185, 129, 0.45)",e.stroke(),e.save();const f=e.createLinearGradient(n+20,l+12,n+44,l+52);f.addColorStop(0,"#34D399"),f.addColorStop(1,"#10B981"),e.fillStyle=f,e.beginPath(),e.moveTo(n+37,l+14),e.lineTo(n+21,l+34),e.lineTo(n+33,l+34),e.lineTo(n+27,l+50),e.lineTo(n+45,l+28),e.lineTo(n+33,l+28),e.closePath(),e.fill(),e.restore(),e.fillStyle="#FFFFFF",e.font="bold 36px Inter, system-ui, -apple-system, sans-serif",e.fillText("GigRadar",n+p+20,l+36),e.fillStyle="#10B981",e.font="bold 13px Inter, system-ui, -apple-system, sans-serif",e.fillText("UPWORK CLIENT INSPECTOR",n+p+22,l+57);const b=210,y=40,g=r+c-44-b,s=l+12;e.beginPath(),e.roundRect(g,s,b,y,20),e.fillStyle="rgba(16, 185, 129, 0.12)",e.fill(),e.strokeStyle="rgba(52, 211, 153, 0.35)",e.lineWidth=1.5,e.stroke(),e.beginPath(),e.arc(g+22,s+20,5.5,0,Math.PI*2),e.fillStyle="#34D399",e.fill(),e.fillStyle="#A7F3D0",e.font="bold 14px Inter, system-ui, -apple-system, sans-serif",e.fillText("VERIFIED SAVINGS",g+38,s+25);const d=l+135;e.fillStyle="#94A3B8",e.font="bold 15px Inter, system-ui, -apple-system, sans-serif",e.fillText("CUMULATIVE BIDDING INTEL",n,d);const F=String(t.connectsSaved);e.fillStyle="#FFFFFF",e.font="bold 88px Inter, system-ui, -apple-system, sans-serif",e.fillText(F,n,d+84);const B=e.measureText(F).width;e.fillStyle="#34D399",e.font="bold 40px Inter, system-ui, -apple-system, sans-serif",e.fillText(" Connects Protected",n+B,d+84);const D=`$${t.dollarsSaved.toFixed(2)}`;e.fillStyle="#E2E8F0",e.font="500 24px Inter, system-ui, -apple-system, sans-serif";const M=`Saved ~${D} USD by avoiding ghost listings and low-hire clients`;if(e.fillText(M,n,d+130),t.proRoiMultiplier){const _=n,T=d+155,G=200,N=42;e.beginPath(),e.roundRect(_,T,G,N,12),e.fillStyle="rgba(251, 191, 36, 0.12)",e.fill(),e.strokeStyle="rgba(251, 191, 36, 0.35)",e.lineWidth=1.5,e.stroke(),e.fillStyle="#FDE68A",e.font="bold 16px Inter, system-ui, -apple-system, sans-serif",e.fillText(`⚡ ${t.proRoiMultiplier}x Pro ROI`,_+22,T+27)}const S=r+w-56;e.beginPath(),e.moveTo(r+44,S-24),e.lineTo(r+c-44,S-24),e.strokeStyle="rgba(255, 255, 255, 0.08)",e.lineWidth=1,e.stroke(),e.fillStyle="#64748B",e.font="500 15px Inter, system-ui, -apple-system, sans-serif",e.fillText("100% Deterministic Verification · Zero Telemetry · Upwork Inspector",r+44,S+8);const k="#Upwork #Freelancing #GigRadar";e.fillStyle="#94A3B8",e.font="bold 15px Inter, system-ui, -apple-system, sans-serif";const A=e.measureText(k).width;e.fillText(k,r+c-44-A,S+8),e.restore()}function j(i){const t=document.createElement("canvas");return R(t,i),t.toDataURL("image/png")}async function C(i){const t=document.createElement("canvas");return R(t,i),new Promise((e,o)=>{t.toBlob(a=>{a?e(a):o(new Error("Failed to generate canvas blob"))},"image/png")})}function J(i,t){var v,f,b,y,g;const e=document.getElementById("gigradar-share-modal-overlay");e&&e.remove();const o=document.createElement("div");o.id="gigradar-share-modal-overlay",o.className="fixed inset-0 z-[100] flex flex-col bg-[#0D0F12] text-ink overflow-y-auto custom-scrollbar animate-fade-in";const a=j(i),w=I(i).split(`
`).filter(s=>s.trim().length>0).slice(0,2).join(" ");o.innerHTML=`
    <!-- Top Navigation Header -->
    <header class="flex h-12 flex-none items-center justify-between border-b border-edge/80 bg-panel/90 px-4">
      <button id="share-modal-back" type="button" class="group flex items-center gap-1.5 rounded-lg py-1 px-2 text-xs font-bold text-slate-300 hover:bg-white/5 hover:text-white transition-colors">
        <svg viewBox="0 0 16 16" fill="none" class="h-3.5 w-3.5 transition-transform group-hover:-translate-x-0.5" aria-hidden="true">
          <path d="M10 3.5L5.5 8l4.5 4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>${u("back_btn",t)}</span>
      </button>

      <span class="text-xs font-black uppercase tracking-wider text-brand-300">
        ${u("share_modal_title",t)}
      </span>

      <button id="share-modal-close" type="button" class="flex h-7 w-7 items-center justify-center rounded-lg text-slate-400 hover:bg-white/5 hover:text-white transition-colors" aria-label="Close">
        ✕
      </button>
    </header>

    <!-- Main Content Body -->
    <div class="flex-1 p-4 space-y-3.5 flex flex-col justify-between">
      <div class="space-y-3">
        <p class="text-[11px] text-mute text-center leading-relaxed max-w-[280px] mx-auto [text-wrap:balance]">
          ${u("share_modal_subtitle",t)}
        </p>

        <!-- Live High-Resolution Card Preview -->
        <div class="relative overflow-hidden rounded-xl border border-white/10 shadow-[0_8px_30px_rgba(0,0,0,0.6)] bg-panel">
          <img id="share-card-preview" src="${a}" alt="GigRadar Savings Card" class="w-full h-auto block select-none" />
        </div>

        <!-- Tweet Snippet Preview -->
        <div class="rounded-xl border border-white/5 bg-raised/70 p-2.5 text-[10.5px] text-slate-300 leading-relaxed select-text">
          <div class="text-[9px] font-bold uppercase tracking-wider text-brand-400 mb-1 flex items-center gap-1">
            <svg viewBox="0 0 16 16" fill="currentColor" class="h-2.5 w-2.5"><path d="M13.5 1a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 2.5a2.5 2.5 0 0 1 2.5-2.5 2.5 2.5 0 0 1 2.5 2.5c0 1.25-.92 2.3-2.12 2.47l-5.6 2.8a2.5 2.5 0 0 1 0 .46l5.6 2.8c1.2-.17 2.12.88 2.12 2.47a2.5 2.5 0 1 1-5 0c0-.16.02-.31.05-.46l-5.6-2.8A2.5 2.5 0 1 1 5.5 8c0 .16-.02.31-.05.46l5.6 2.8A2.5 2.5 0 0 1 11 13.5"/></svg>
            ${u("share_savings_btn",t)}
          </div>
          <p class="text-slate-300 italic line-clamp-2">"${w}"</p>
        </div>
      </div>

      <!-- Action Buttons -->
      <div class="space-y-2 pt-1">
        <!-- Primary 1-Click Copy -->
        <button id="share-copy-image" type="button"
          class="group relative w-full overflow-hidden rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 py-2.5 text-xs font-black text-slate-950 shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all hover:scale-[1.01] active:scale-95">
          <span class="absolute inset-x-0 top-0 h-px bg-white/60"></span>
          <div class="relative flex items-center justify-center gap-2">
            <span class="text-sm">📋</span>
            <span id="copy-btn-text">${u("copy_image_btn",t)}</span>
          </div>
        </button>

        <!-- Secondary Multi-Share Grid -->
        <div class="grid grid-cols-3 gap-2">
          <button id="share-download" type="button"
            class="flex flex-col items-center justify-center gap-1 rounded-xl border border-edge bg-raised/90 py-2.5 px-1 text-[10px] font-bold text-slate-200 hover:border-brand-500/40 hover:text-white active:scale-95 transition-all">
            <svg viewBox="0 0 16 16" fill="none" class="h-3.5 w-3.5" aria-hidden="true">
              <path d="M8 2v8m0 0l-3-3m3 3l3-3M2 13h12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span>Save PNG</span>
          </button>

          <button id="share-x" type="button"
            class="flex flex-col items-center justify-center gap-1 rounded-xl border border-slate-700 bg-slate-900 py-2.5 px-1 text-[10px] font-bold text-white hover:bg-slate-800 active:scale-95 transition-all">
            <svg viewBox="0 0 24 24" fill="currentColor" class="h-3.5 w-3.5">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
            </svg>
            <span>Post to X</span>
          </button>

          <button id="share-linkedin" type="button"
            class="flex flex-col items-center justify-center gap-1 rounded-xl border border-[#0A66C2]/40 bg-[#0A66C2]/15 py-2.5 px-1 text-[10px] font-bold text-[#70B5F9] hover:bg-[#0A66C2]/25 active:scale-95 transition-all">
            <svg viewBox="0 0 24 24" fill="currentColor" class="h-3.5 w-3.5">
              <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 10.9v8.37H9.25V10.9H6.46M7.86 6.31a1.63 1.63 0 0 0-1.63 1.63c0 .9.73 1.63 1.63 1.63.9 0 1.63-.73 1.63-1.63 0-.9-.73-1.63-1.63-1.63Z"/>
            </svg>
            <span>LinkedIn</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Sleek Bottom Footer -->
    <footer class="mt-auto flex h-8 flex-none items-center justify-between border-t border-edge/80 bg-white/[0.01] px-4 text-[10px] text-mute">
      <span class="flex items-center gap-1.5 text-slate-400">
        <span class="h-1.5 w-1.5 rounded-full bg-brand-400"></span>
        Zero Telemetry · 100% Deterministic
      </span>
      <span class="font-mono text-[9.5px] text-slate-500">gigradar.io</span>
    </footer>
  `,document.body.appendChild(o);const h=()=>{o.classList.add("opacity-0","pointer-events-none"),setTimeout(()=>o.remove(),160)};(v=o.querySelector("#share-modal-close"))==null||v.addEventListener("click",h),(f=o.querySelector("#share-modal-back"))==null||f.addEventListener("click",h),document.addEventListener("keydown",function s(d){d.key==="Escape"&&(h(),document.removeEventListener("keydown",s))});const n=o.querySelector("#share-copy-image"),l=o.querySelector("#copy-btn-text");n==null||n.addEventListener("click",async()=>{try{const s=await C(i);if(navigator.clipboard&&window.ClipboardItem){if(await navigator.clipboard.write([new ClipboardItem({"image/png":s})]),l){const d=l.textContent;l.textContent=u("image_copied",t),n.classList.add("ring-2","ring-brand-400"),setTimeout(()=>{l&&(l.textContent=d),n.classList.remove("ring-2","ring-brand-400")},2e3)}}else p()}catch{p()}});const p=()=>{const s=document.createElement("a");s.href=a,s.download=`gigradar-savings-${i.connectsSaved}-connects.png`,document.body.appendChild(s),s.click(),s.remove()};(b=o.querySelector("#share-download"))==null||b.addEventListener("click",p),(y=o.querySelector("#share-x"))==null||y.addEventListener("click",async()=>{try{const F=await C(i);navigator.clipboard&&window.ClipboardItem&&await navigator.clipboard.write([new ClipboardItem({"image/png":F})])}catch{}const s=I(i),d=`https://twitter.com/intent/tweet?text=${encodeURIComponent(s)}`;chrome.tabs.create({url:d})}),(g=o.querySelector("#share-linkedin"))==null||g.addEventListener("click",async()=>{try{const d=await C(i);navigator.clipboard&&window.ClipboardItem&&await navigator.clipboard.write([new ClipboardItem({"image/png":d})])}catch{}const s=`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(P)}`;chrome.tabs.create({url:s})})}export{X as S,K as a,Y as g,J as o,Z as s};
