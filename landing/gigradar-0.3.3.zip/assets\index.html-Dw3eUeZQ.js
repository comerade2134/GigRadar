import{S as st,g as Ct,a as Lt,s as ot,o as It}from"./share-modal-DFpAcbF4.js";import{t as xt,u as At,v as nt,w as at,x as Tt,b as rt,y as Bt,z as jt,A as Pt,B as Nt,C as Rt,l as we,D as Ne,E as Ut,F as Mt,e as qt,G as it,H as de,j as lt,I as dt,J as Ot,K as Dt,k as Vt,i as Ft}from"./bid-intelligence-Mh-5b8Gv.js";import{a as Ht,l as Wt,D as Kt}from"./feed-scanner-Bj8E6RR6.js";import{a as mt,g as zt,t,s as Gt,D as Jt}from"./metrics-CxlbnKT_.js";import{e as pe,P as Yt,g as ct}from"./extpay-core-6aOhiK5e.js";import{l as Qt,r as pt,s as Xt,f as ce,a as Zt}from"./webhooks-BI-TsU2V.js";import{s as es,l as ts,d as ss}from"./client-notes-BibSRGwY.js";import"./extpay-vendor-CwkHEbPA.js";const Re="gigradar:team_intel",Ue="gigradar:sync_state",Me={lastSyncedAt:null,syncStatus:"offline"};async function os(){if(!pe())return{...Me};try{const k=(await chrome.storage.local.get(Ue))[Ue];if(k&&typeof k.syncStatus=="string")return k}catch{}return{...Me}}async function ke(e){pe()&&await chrome.storage.local.set({[Ue]:e})}async function qe(){if(!pe())return[];try{const k=(await chrome.storage.local.get(Re))[Re];if(Array.isArray(k))return k}catch{}return[]}async function ut(e){if(!pe())return;const k=await qe();if(k.some(x=>x.clientKey===e.clientKey))return;const K=[{...e,flaggedAt:Date.now()},...k.slice(0,99)];await chrome.storage.local.set({[Re]:K})}async function bt(){if(!pe())return{...Me};const e=await xt();if(e.tier==="free"){const k={lastSyncedAt:null,syncStatus:"offline"};return await ke(k),k}await ke({lastSyncedAt:e.syncedAt??null,syncStatus:"syncing"});try{await mt(),e.syncedAt=Date.now(),await At(e),e.tier==="agency"&&(await qe()).length===0&&(await ut({clientKey:"org_acme_ghost",clientName:"Acme Digital Labs",flaggedBy:"Sarah (Lead BD)",reason:"Never hires after sending tests (0/14 hires on $50k listed)"}),await ut({clientKey:"org_crypto_scam",clientName:"Web3 Global Ventures",flaggedBy:"Alex (Agency Dev)",reason:"Attempts off-platform Telegram interview redirection"}));const k={lastSyncedAt:e.syncedAt,syncStatus:"synced"};return await ke(k),k}catch(k){const C={lastSyncedAt:e.syncedAt??null,syncStatus:"error",errorMessage:k instanceof Error?k.message:"Cloud synchronization failed"};return await ke(C),C}}function S(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const g=document.querySelector("#app");async function ft(){var Ye,Qe,Xe,Ze,et,tt;if(!g)return;const e=await zt();g.innerHTML=`
    <header class="mb-8 flex animate-fade-up items-center gap-3.5">
      <div class="relative flex h-12 w-12 items-center justify-center rounded-2xl border border-brand-500/35 bg-gradient-to-b from-brand-500/20 to-brand-500/5 shadow-[0_0_20px_rgba(16,185,129,0.25)]">
        <svg viewBox="0 0 24 24" fill="none" class="h-7 w-7" aria-hidden="true">
          <rect x="1.25" y="1.25" width="21.5" height="21.5" rx="6.5" fill="url(#gr-logo-g)" stroke="#10B981" stroke-opacity=".35"/>
          <path d="M13.4 4.8 7.2 12.9h3.6l-1.1 6.3 6.9-8.7h-3.9l.7-5.7z" fill="#0D0F12"/>
          <defs>
            <linearGradient id="gr-logo-g" x1="2" y1="2" x2="22" y2="22">
              <stop stop-color="#34D399"/><stop offset="1" stop-color="#059669"/>
            </linearGradient>
          </defs>
        </svg>
      </div>
      <div>
        <div class="flex items-center gap-2">
          <h1 class="text-xl font-black tracking-tight text-white">${t("settings_title",e)}</h1>
          <span class="rounded-md border border-white/10 bg-white/5 px-2 py-0.5 font-mono text-[10px] text-slate-400">
            v${chrome.runtime.getManifest().version}
          </span>
        </div>
        <p class="text-xs text-mute">${t("settings_sub",e)}</p>
      </div>
    </header>

    <!-- Language Selector Section -->
    <section class="mb-6 space-y-4 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("language_section_title",e)}</h2>
          <p class="mt-0.5 text-xs text-mute">${t("language_section_desc",e)}</p>
        </div>
        <span id="lang-save-status" class="text-xs font-bold text-brand-400"></span>
      </div>

      <!-- Visual Interactive Language Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
        ${st.map(s=>`
          <button type="button" data-option-lang="${s.code}"
            class="group relative flex flex-col justify-between rounded-xl border p-3 text-left transition-all duration-150 active:scale-95 ${s.code===e?"border-brand-500 bg-brand-500/15 shadow-[0_0_18px_rgba(16,185,129,0.22)]":"border-edge bg-obsidian/70 hover:border-brand-500/40 hover:bg-raised"}">
            <div class="flex items-center justify-between">
              ${Ct(s.code)}
              ${s.code===e?`<span class="inline-flex items-center gap-1 rounded-full bg-brand-500/20 px-2 py-0.5 text-[9.5px] font-black text-brand-300 border border-brand-500/40 shadow-[0_0_8px_rgba(16,185,129,0.3)]">
                      <svg viewBox="0 0 16 16" fill="none" class="h-2.5 w-2.5"><path d="M3.5 8.5L6.5 11.5L12.5 4.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg> ${t("connects_saved_active",e)}
                    </span>`:`<span class="rounded-md border border-white/5 bg-white/5 px-1.5 py-0.5 font-mono text-[9.5px] font-extrabold text-slate-400 group-hover:text-slate-200 transition-colors">${s.code.toUpperCase()}</span>`}
            </div>
            <div class="mt-3 min-w-0">
              <div class="text-xs font-bold text-white truncate group-hover:text-brand-300 transition-colors">${s.nativeName}</div>
              <div class="text-[10px] text-slate-400 truncate mt-0.5">${s.sublabel}</div>
            </div>
          </button>
        `).join("")}
      </div>

      <!-- Hidden select for compatibility -->
      <select id="setting-language" class="hidden">
        ${st.map(s=>`
          <option value="${s.code}" ${s.code===e?"selected":""}>
            ${s.name}
          </option>
        `).join("")}
      </select>
    </section>

    <!-- License Section -->
    <section class="mb-6 space-y-4 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("license",e)}</h2>
        <span class="text-[10px] font-mono text-slate-400">ExtensionPay</span>
      </div>

      <div class="flex items-start gap-3 rounded-xl border border-white/5 bg-obsidian/40 p-3.5">
        <div class="flex h-8 w-8 flex-none items-center justify-center rounded-lg border border-brand-500/30 bg-brand-500/15 text-brand-400">
          <svg viewBox="0 0 16 16" fill="currentColor" class="h-4 w-4">
            <path d="M8 1a7 7 0 100 14A7 7 0 008 1zm-.8 4h1.6v4H7.2V5zm.8 7a1 1 0 110-2 1 1 0 010 2z"/>
          </svg>
        </div>
        <p id="license-status" class="text-sm leading-relaxed text-slate-300 pt-0.5">${t("license_status_checking",e)}</p>
      </div>

      <div class="flex flex-wrap gap-2.5 pt-1">
        <button id="buy"
          class="group relative overflow-hidden rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-5 py-2.5 text-sm font-black text-slate-950 shadow-[0_0_20px_rgba(16,185,129,0.3)] transition-all duration-150 hover:brightness-105 active:scale-[.98]">
          <span class="absolute inset-x-0 top-0 h-px bg-white/60"></span>
          ${t("get_pro",e)} — ${Yt} early bird
        </button>
        <button id="recheck"
          class="rounded-xl border border-edge bg-raised px-4 py-2.5 text-sm font-semibold text-mute transition-colors duration-150 hover:border-brand-500/40 hover:text-white active:scale-[.99]">
          ${t("recheck_license",e)}
        </button>
      </div>
    </section>

    <!-- Account & Cloud Sync Section -->
    <section class="mb-6 space-y-4 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("account_section_title",e)}</h2>
          <p class="mt-0.5 text-xs text-mute">${t("account_section_desc",e)}</p>
        </div>
        <span id="account-tier-badge" class="inline-flex items-center gap-1.5 rounded-full border border-slate-700 bg-slate-800/80 px-2.5 py-1 text-xs font-bold text-slate-400">
          <span class="h-1.5 w-1.5 rounded-full bg-brand-400"></span>
          <span id="account-tier-label">${t("tier_free",e)}</span>
        </span>
      </div>

      <div class="rounded-xl border border-white/5 bg-obsidian/40 p-4 space-y-3">
        <div class="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div class="flex items-center gap-2">
            <span class="text-mute font-medium">Status:</span>
            <span id="cloud-sync-status" class="font-bold text-slate-400 flex items-center gap-1.5">
              <span class="h-2 w-2 rounded-full bg-slate-500"></span>
              ${t("sync_status_offline",e)}
            </span>
          </div>
          <div id="account-user-email" class="text-slate-400 font-mono text-[11px]">
            local_anonymous
          </div>
        </div>

        <div id="team-info-box" class="hidden rounded-lg border border-brand-500/20 bg-brand-500/5 p-3 text-xs">
          <div class="flex items-center justify-between text-brand-300 font-bold mb-1">
            <span id="team-name-label">Agency Workspace</span>
            <span id="team-seats-badge" class="rounded bg-brand-500/20 px-2 py-0.5 text-[10px] font-mono">1 / 10 seats</span>
          </div>
          <div class="text-[11px] text-slate-400 flex items-center justify-between">
            <span>${t("team_intel_shared",e)}:</span>
            <span id="team-intel-count" class="font-mono font-bold text-white">0</span>
          </div>
        </div>
      </div>

      <div class="grid gap-3 sm:grid-cols-2">
        <input id="account-token-input" type="text" placeholder="Enter license or agency team token…" autocomplete="off" spellcheck="false"
          class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 text-xs text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20" />
        <div class="flex items-center gap-2">
          <button id="account-connect-btn" type="button"
            class="rounded-xl border border-edge bg-raised px-4 py-2.5 text-xs font-semibold text-white transition-colors duration-150 hover:border-brand-500/40 hover:bg-raised/80 active:scale-[.99]">
            Connect
          </button>
          <button id="account-sync-btn" type="button"
            class="flex-1 rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-4 py-2.5 text-xs font-black text-slate-950 shadow-[0_0_16px_rgba(16,185,129,0.2)] transition-all duration-150 hover:scale-[1.01] active:scale-[.98]">
            ${t("sync_now_btn",e)}
          </button>
          <button id="account-disconnect-btn" type="button" class="hidden rounded-xl border border-red-500/30 bg-red-500/10 px-3 py-2.5 text-xs font-semibold text-red-400 transition-colors duration-150 hover:bg-red-500/20 active:scale-[.99]">
            Disconnect
          </button>
        </div>
      </div>
      <span id="account-status-msg" class="text-xs font-bold text-brand-400"></span>

      <!-- Module A: Live Team Proposal Pipeline & Collision Ledger -->
      <div id="team-pipeline-section" class="mt-4 pt-4 border-t border-white/5 space-y-3">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <div class="flex items-center gap-2">
            <span class="flex h-2 w-2 rounded-full bg-purple-400 shadow-[0_0_8px_rgba(168,85,247,0.6)]"></span>
            <h3 class="text-xs font-black uppercase tracking-wider text-purple-300">
              ${t("active_team_pipeline",e)}
            </h3>
          </div>
          <div class="flex items-center gap-2">
            <button id="simulate-team-activity-btn" type="button"
              class="rounded-lg border border-purple-500/30 bg-purple-500/10 px-2.5 py-1 text-[11px] font-bold text-purple-300 hover:bg-purple-500/20 hover:border-purple-500/50 transition-colors">
              ${t("simulate_team_activity_btn",e)}
            </button>
            <button id="clear-team-pipeline-btn" type="button"
              class="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] font-semibold text-slate-400 hover:text-white transition-colors">
              ${t("clear_team_pipeline_btn",e)}
            </button>
          </div>
        </div>

        <!-- Metrics Row -->
        <div class="grid grid-cols-3 gap-2.5">
          <div class="rounded-xl border border-white/5 bg-obsidian/60 p-3">
            <div class="text-[10px] uppercase font-bold text-mute tracking-wider">${t("collisions_prevented_label",e)}</div>
            <div id="metric-collisions-prevented" class="text-lg font-black text-white font-mono mt-0.5">0</div>
          </div>
          <div class="rounded-xl border border-white/5 bg-obsidian/60 p-3">
            <div class="text-[10px] uppercase font-bold text-mute tracking-wider">${t("connects_saved_label",e)}</div>
            <div id="metric-connects-saved" class="text-lg font-black text-emerald-400 font-mono mt-0.5">0</div>
          </div>
          <div class="rounded-xl border border-white/5 bg-obsidian/60 p-3">
            <div class="text-[10px] uppercase font-bold text-mute tracking-wider">${t("capital_protected_label",e)}</div>
            <div id="metric-dollars-saved" class="text-lg font-black text-brand-300 font-mono mt-0.5">$0.00</div>
          </div>
        </div>
        <div class="mt-2.5">
          <button id="options-share-savings-btn" type="button" class="w-full flex items-center justify-center gap-2 rounded-xl border border-brand-400/40 bg-brand-500/10 hover:bg-brand-500/20 py-2 px-3 text-xs font-bold text-brand-300 shadow-sm transition-all active:scale-[0.99]">
            <svg viewBox="0 0 16 16" fill="currentColor" class="h-3.5 w-3.5 flex-none"><path d="M13.5 1a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zM11 2.5a2.5 2.5 0 0 1 2.5-2.5 2.5 2.5 0 0 1 2.5 2.5c0 1.25-.92 2.3-2.12 2.47l-5.6 2.8a2.5 2.5 0 0 1 0 .46l5.6 2.8c1.2-.17 2.12.88 2.12 2.47a2.5 2.5 0 1 1-5 0c0-.16.02-.31.05-.46l-5.6-2.8A2.5 2.5 0 1 1 5.5 8c0 .16-.02.31-.05.46l5.6 2.8A2.5 2.5 0 0 1 11 13.5"/></svg>
            <span>${t("share_savings_btn",e)} — LinkedIn / X Badge</span>
          </button>
        </div>

        <!-- Active Team Proposals List -->
        <div id="team-pipeline-list" class="space-y-2">
          <!-- Dynamically populated -->
        </div>
      </div>
    </section>

    <!-- Proposal Autopilot & Custom Voice Profile Studio (Module B) -->
    <section class="mb-6 space-y-5 rounded-2xl border border-indigo-500/30 bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-indigo-400">
              🚀 ${t("voice_profile_title",e)}
            </h2>
            <span class="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[9px] font-extrabold text-indigo-300 border border-indigo-500/30">
              PRO FREELANCER
            </span>
          </div>
          <p class="mt-0.5 text-xs text-mute">${t("voice_profile_desc",e)}</p>
        </div>
        <span id="voice-save-status" class="text-xs font-bold text-indigo-400"></span>
      </div>

      <!-- Tone Selector & Custom Instructions -->
      <div class="grid gap-4 sm:grid-cols-2">
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("default_voice_tone_label",e)}</span>
          <div class="relative">
            <select id="voice-tone-select"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-indigo-500/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/20">
              <option value="direct_engineer">${t("tone_direct",e)}</option>
              <option value="consultative_partner">${t("tone_consultative",e)}</option>
              <option value="velocity_exec">${t("tone_velocity",e)}</option>
              <option value="custom">${t("tone_custom",e)}</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>

        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("custom_tone_instructions",e)}</span>
          <input id="voice-custom-instructions" type="text"
            placeholder="${t("custom_tone_placeholder",e)}"
            class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 text-sm text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-indigo-500/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/20" />
        </label>
      </div>

      <!-- Interactive Tone Analyzer -->
      <div class="rounded-xl border border-white/5 bg-obsidian/70 p-4 space-y-3">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-slate-300">${t("auto_tone_analyzer_title",e)}</span>
          <span id="tone-analysis-badge" class="text-[10px] font-bold text-slate-400">${t("tone_calibration_hint",e)}</span>
        </div>
        <textarea id="tone-sample-input" rows="3"
          placeholder="${t("paste_sample_proposal_placeholder",e)}"
          class="w-full rounded-xl border border-edge bg-obsidian/90 px-3.5 py-2.5 text-xs text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-indigo-500/60 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"></textarea>
        <div class="flex items-center justify-between">
          <button id="tone-analyze-btn" type="button"
            class="rounded-xl border border-indigo-500/40 bg-indigo-500/15 px-4 py-1.5 text-xs font-bold text-indigo-300 transition-all duration-150 hover:bg-indigo-500/25 active:scale-95">
            ${t("analyze_tone_btn",e)}
          </button>
          <div id="tone-traits-display" class="text-xs text-slate-300 font-mono hidden"></div>
        </div>
      </div>

      <!-- Portfolio Case Studies Manager -->
      <div class="space-y-3 pt-2">
        <div class="flex items-center justify-between">
          <div>
            <h3 class="text-xs font-bold text-slate-200">💼 ${t("case_studies_title",e)}</h3>
            <p class="text-[11px] text-mute">${t("case_studies_sub",e)}</p>
          </div>
          <button id="seed-case-studies-btn" type="button"
            class="rounded-lg border border-edge bg-raised px-3 py-1 text-xs font-semibold text-slate-300 hover:border-brand-500/40 hover:text-white transition-all">
            ${t("seed_case_studies_btn",e)}
          </button>
        </div>

        <!-- Add Case Study Form -->
        <div class="rounded-xl border border-white/5 bg-obsidian/50 p-3.5 space-y-2.5">
          <div class="grid gap-2.5 sm:grid-cols-2">
            <input id="cs-title-input" type="text" placeholder="${t("case_study_title_label",e)}"
              class="rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
            <input id="cs-tags-input" type="text" placeholder="${t("case_study_tags_label",e)}"
              class="rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
          </div>
          <div class="grid gap-2.5 sm:grid-cols-2">
            <input id="cs-problem-input" type="text" placeholder="${t("case_study_problem_label",e)}"
              class="rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
            <input id="cs-metrics-input" type="text" placeholder="${t("case_study_metrics_label",e)}"
              class="rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
          </div>
          <div class="flex items-center gap-2">
            <input id="cs-link-input" type="url" placeholder="${t("case_study_link_label",e)}"
              class="flex-1 rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
            <button id="add-case-study-btn" type="button"
              class="rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-bold text-white hover:bg-indigo-500 active:scale-95 transition-all">
              ${t("add_case_study_btn",e)}
            </button>
          </div>
        </div>

        <!-- Case Studies List -->
        <div id="case-studies-list" class="space-y-2">
          <!-- Dynamically populated -->
        </div>
      </div>

      <!-- Custom Proposal Structure & Template Editor -->
      <div class="space-y-3 pt-4 border-t border-white/5">
        <div class="flex items-center justify-between">
          <div>
            <div class="flex items-center gap-2">
              <h3 class="text-xs font-bold text-slate-200">📝 Custom Proposal Structure & Dynamic Variables</h3>
              <span class="rounded bg-indigo-500/20 px-1.5 py-0.5 text-[9px] font-bold text-indigo-300">CUSTOM TEMPLATE</span>
            </div>
            <p class="text-[11px] text-mute">Customize the 4-part proposal engine using signature frameworks and dynamic variables.</p>
          </div>
          <label class="flex cursor-pointer items-center gap-2">
            <span class="text-xs font-semibold text-slate-300">Enable</span>
            <input id="template-enabled" type="checkbox" class="peer sr-only" />
            <span class="relative h-5 w-9 flex-none rounded-full bg-slate-700 transition-colors duration-200 after:absolute after:left-0.5 after:top-0.5 after:h-4 after:w-4 after:rounded-full after:bg-white after:shadow-md after:transition-transform after:duration-200 peer-checked:bg-indigo-500 peer-checked:after:translate-x-4"></span>
          </label>
        </div>

        <div id="custom-template-fields" class="space-y-3 rounded-xl border border-white/5 bg-obsidian/50 p-4">
          <!-- Variable Helper Badges -->
          <div>
            <div class="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">Click to insert variables:</div>
            <div class="flex flex-wrap gap-1.5">
              <button type="button" class="tmpl-var-pill rounded bg-indigo-500/15 border border-indigo-500/30 px-2 py-0.5 font-mono text-[10px] font-bold text-indigo-300 hover:bg-indigo-500/30 transition-colors" data-var="{{client_name}}">{{client_name}}</button>
              <button type="button" class="tmpl-var-pill rounded bg-indigo-500/15 border border-indigo-500/30 px-2 py-0.5 font-mono text-[10px] font-bold text-indigo-300 hover:bg-indigo-500/30 transition-colors" data-var="{{subject}}">{{subject}}</button>
              <button type="button" class="tmpl-var-pill rounded bg-indigo-500/15 border border-indigo-500/30 px-2 py-0.5 font-mono text-[10px] font-bold text-indigo-300 hover:bg-indigo-500/30 transition-colors" data-var="{{challenge}}">{{challenge}}</button>
              <button type="button" class="tmpl-var-pill rounded bg-indigo-500/15 border border-indigo-500/30 px-2 py-0.5 font-mono text-[10px] font-bold text-indigo-300 hover:bg-indigo-500/30 transition-colors" data-var="{{case_study}}">{{case_study}}</button>
              <button type="button" class="tmpl-var-pill rounded bg-indigo-500/15 border border-indigo-500/30 px-2 py-0.5 font-mono text-[10px] font-bold text-indigo-300 hover:bg-indigo-500/30 transition-colors" data-var="{{tech_stack}}">{{tech_stack}}</button>
            </div>
          </div>

          <label class="block space-y-1.5">
            <span class="text-xs font-semibold text-slate-300">Hook / Opening Statement</span>
            <input id="tmpl-hook" type="text" placeholder="Hi {{client_name}}, saw you're looking for help with {{challenge}}."
              class="w-full rounded-lg border border-edge bg-obsidian px-3 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
          </label>

          <div class="grid gap-2.5 sm:grid-cols-3">
            <label class="block space-y-1.5">
              <span class="text-xs font-semibold text-slate-300">Step 1: Audit & Discovery</span>
              <textarea id="tmpl-step1" rows="2" placeholder="1. Audit existing architecture and identify bottlenecks."
                class="w-full rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none"></textarea>
            </label>
            <label class="block space-y-1.5">
              <span class="text-xs font-semibold text-slate-300">Step 2: Build & Delivery</span>
              <textarea id="tmpl-step2" rows="2" placeholder="2. Implement core deliverables with tests and documentation."
                class="w-full rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none"></textarea>
            </label>
            <label class="block space-y-1.5">
              <span class="text-xs font-semibold text-slate-300">Step 3: QA & Handoff</span>
              <textarea id="tmpl-step3" rows="2" placeholder="3. QA verification, handoff walkthrough, and 14-day warranty."
                class="w-full rounded-lg border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none"></textarea>
            </label>
          </div>

          <label class="block space-y-1.5">
            <span class="text-xs font-semibold text-slate-300">Closing Call-To-Action (CTA)</span>
            <input id="tmpl-cta" type="text" placeholder="Open to a quick 10-minute sync this week to review?"
              class="w-full rounded-lg border border-edge bg-obsidian px-3 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-indigo-500/60 focus:outline-none" />
          </label>

          <div class="flex items-center justify-between pt-1">
            <button id="tmpl-reset-btn" type="button" class="text-xs font-semibold text-slate-400 hover:text-white transition-colors">
              Reset to Defaults
            </button>
            <button id="tmpl-save-btn" type="button" class="rounded-lg bg-indigo-600 px-4 py-1.5 text-xs font-bold text-white hover:bg-indigo-500 active:scale-95 transition-all">
              Save Template
            </button>
          </div>
        </div>
      </div>
    </section>

    <!-- Predictive Bid Intelligence & Connects ROI Simulator (Module C) -->
    <section class="mb-6 space-y-5 rounded-2xl border border-sky-500/30 bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex items-center justify-between">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-sky-400">
              📈 ${t("bid_simulator_title",e)}
            </h2>
            <span class="rounded bg-sky-500/20 px-1.5 py-0.5 text-[9px] font-extrabold text-sky-300 border border-sky-500/30">
              ${t("bid_intel_badge",e)}
            </span>
          </div>
          <p class="mt-0.5 text-xs text-mute">${t("bid_simulator_desc",e)}</p>
        </div>
      </div>

      <!-- Controls Grid -->
      <div class="grid gap-4 sm:grid-cols-3">
        <label class="block space-y-1.5">
          <div class="flex justify-between text-xs">
            <span class="font-semibold text-slate-300">${t("contract_value_label",e)}</span>
            <span id="sim-budget-val" class="font-mono font-bold text-sky-400">$1,500</span>
          </div>
          <input id="sim-budget-slider" type="range" min="100" max="10000" step="100" value="1500"
            class="w-full accent-sky-500 cursor-pointer" />
        </label>

        <label class="block space-y-1.5">
          <div class="flex justify-between text-xs">
            <span class="font-semibold text-slate-300">${t("client_hire_rate_label",e)}</span>
            <span id="sim-hirerate-val" class="font-mono font-bold text-emerald-400">65%</span>
          </div>
          <input id="sim-hirerate-slider" type="range" min="0" max="100" step="5" value="65"
            class="w-full accent-emerald-500 cursor-pointer" />
        </label>

        <label class="block space-y-1.5">
          <div class="flex justify-between text-xs">
            <span class="font-semibold text-slate-300">${t("competition_label",e)}</span>
            <span id="sim-proposals-val" class="font-mono font-bold text-indigo-400">18 proposals</span>
          </div>
          <input id="sim-proposals-slider" type="range" min="1" max="60" step="1" value="18"
            class="w-full accent-indigo-500 cursor-pointer" />
        </label>
      </div>

      <!-- Output Simulation Dashboard -->
      <div class="rounded-xl border border-white/5 bg-obsidian/70 p-4 space-y-3.5">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span id="sim-strategy-badge" class="rounded px-2 py-0.5 text-[10px] font-black uppercase font-mono border"></span>
            <span id="sim-recommended-bid" class="text-xs font-bold text-white"></span>
          </div>
          <span id="sim-roi-ratio" class="text-xs font-mono font-extrabold text-amber-400"></span>
        </div>

        <div class="grid grid-cols-2 gap-2 sm:grid-cols-4">
          <div class="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
            <div class="text-[9.5px] font-bold text-mute uppercase tracking-wider">${t("win_probability_label",e)}</div>
            <div id="sim-win-prob" class="text-base font-black text-emerald-400 font-mono mt-0.5">0%</div>
          </div>
          <div class="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
            <div class="text-[9.5px] font-bold text-mute uppercase tracking-wider">${t("organic_win_label",e)}</div>
            <div id="sim-org-prob" class="text-base font-black text-slate-300 font-mono mt-0.5">0%</div>
          </div>
          <div class="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
            <div class="text-[9.5px] font-bold text-mute uppercase tracking-wider">${t("expected_value_label",e)}</div>
            <div id="sim-expected-value" class="text-base font-black text-brand-300 font-mono mt-0.5">$0</div>
          </div>
          <div class="rounded-lg border border-white/5 bg-white/[0.02] p-2.5">
            <div class="text-[9.5px] font-bold text-mute uppercase tracking-wider">${t("break_even_win_label",e)}</div>
            <div id="sim-breakeven" class="text-base font-black text-slate-400 font-mono mt-0.5">0%</div>
          </div>
        </div>

        <p id="sim-verdict" class="text-xs text-slate-300 leading-relaxed bg-white/[0.02] border border-white/5 p-3 rounded-lg"></p>

        <!-- Dynamic Visual Curve -->
        <div class="space-y-1">
          <div class="text-[10px] uppercase font-bold text-mute tracking-wider">Win Probability & EV by Boost Bid</div>
          <div id="sim-curve-container" class="flex gap-1.5 items-end h-20 pt-2 border-b border-white/10 pb-1">
            <!-- Dynamically populated bars -->
          </div>
        </div>
      </div>
    </section>

    <!-- AI Proposal Polisher (BYOK) Section -->
    <section class="mb-6 space-y-5 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("ai_polish_title",e)}</h2>

      <label class="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-edge bg-raised/80 px-4 py-3 transition-colors duration-150 hover:border-brand-500/30">
        <span class="text-sm font-semibold text-white">
          ${t("enable_ai_polish",e)}
          <span class="mt-0.5 block text-xs font-normal text-mute">${t("ai_polish_note",e)}</span>
        </span>
        <input id="byok-enabled" type="checkbox" class="peer sr-only" />
        <span class="relative h-6 w-11 flex-none rounded-full bg-slate-700 transition-colors duration-200 after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow-md after:transition-transform after:duration-200 peer-checked:bg-brand-500 peer-checked:after:translate-x-5 peer-focus-visible:ring-2 peer-focus-visible:ring-brand-400"></span>
      </label>

      <p class="-mt-2 text-xs leading-relaxed text-mute">
        ${t("ai_polish_help",e)}
      </p>

      <div class="grid gap-4 sm:grid-cols-2">
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("provider",e)}</span>
          <div class="relative">
            <select id="provider"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
              <option value="openai">OpenAI</option>
              <option value="anthropic">Anthropic</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>

        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("api_key",e)}</span>
          <input id="api-key" type="password" placeholder="sk-…" autocomplete="off" spellcheck="false"
            class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 text-sm text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20" />
        </label>
      </div>

      <div class="flex flex-wrap items-center gap-3 pt-1">
        <button id="save"
          class="rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-5 py-2 text-sm font-black text-slate-950 shadow-[0_0_16px_rgba(16,185,129,0.25)] transition-all duration-150 hover:shadow-[0_0_24px_rgba(16,185,129,0.45)] hover:scale-[1.01] active:scale-[.98]">
          ${t("save",e)}
        </button>
        <button id="byok-test" type="button"
          class="rounded-xl border border-edge bg-raised px-4 py-2 text-sm font-semibold text-slate-200 transition-colors duration-150 hover:border-brand-500/40 hover:bg-raised/80 hover:text-white active:scale-[.99]">
          ${t("test_connection",e)}
        </button>
        <span id="save-status" class="text-xs font-bold text-brand-400"></span>
      </div>
    </section>

    <!-- Background RSS Scanner Section -->
    <section class="space-y-5 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("scanner_title",e)}</h2>

      <label class="flex cursor-pointer items-center justify-between gap-4 rounded-xl border border-edge bg-raised/80 px-4 py-3 transition-colors duration-150 hover:border-brand-500/30">
        <span class="text-sm font-semibold text-white">
          ${t("scanner_toggle",e)}
          <span class="mt-0.5 block text-xs font-normal text-mute">${t("scanner_note",e)}</span>
        </span>
        <input id="scanner-enabled" type="checkbox" class="peer sr-only" />
        <span class="relative h-6 w-11 flex-none rounded-full bg-slate-700 transition-colors duration-200 after:absolute after:left-0.5 after:top-0.5 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow-md after:transition-transform after:duration-200 peer-checked:bg-brand-500 peer-checked:after:translate-x-5 peer-focus-visible:ring-2 peer-focus-visible:ring-brand-400"></span>
      </label>

      <label class="block space-y-2">
        <span class="text-xs font-semibold text-mute">${t("scanner_rss_label",e)}</span>
        <input id="scanner-rss" type="url" placeholder="https://www.upwork.com/nx/search/jobs/rss?q=…" autocomplete="off" spellcheck="false"
          class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 text-sm text-ink placeholder:text-slate-600 transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20" />
        <span class="block text-xs leading-relaxed text-mute">${t("scanner_rss_help",e)}</span>
      </label>

      <div class="grid gap-4 sm:grid-cols-3">
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("check_every",e)}</span>
          <div class="relative">
            <select id="scanner-interval"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
              <option value="3">3 minutes</option>
              <option value="5">5 minutes</option>
              <option value="10">10 minutes</option>
              <option value="15">15 minutes</option>
              <option value="30">30 minutes</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("min_score",e)}</span>
          <div class="relative">
            <select id="scanner-min-score"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
              <option value="80">80 (strict)</option>
              <option value="70">70</option>
              <option value="60">60 (loose)</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>
        <label class="block space-y-2">
          <span class="text-xs font-semibold text-mute">${t("posted_within",e)}</span>
          <div class="relative">
            <select id="scanner-fresh"
              class="w-full cursor-pointer appearance-none rounded-xl border border-edge bg-obsidian px-3.5 py-2.5 pr-8 text-sm text-ink transition-colors duration-150 focus:border-brand-500/60 focus:outline-none focus:ring-2 focus:ring-brand-500/20">
              <option value="5">5 minutes</option>
              <option value="10">10 minutes</option>
              <option value="30">30 minutes</option>
              <option value="60">1 hour</option>
            </select>
            <svg class="pointer-events-none absolute right-3 top-3.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
              <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
        </label>
      </div>

      <!-- Instant Webhook Lead Pings -->
      <div class="rounded-xl border border-white/5 bg-obsidian/40 p-4 space-y-3">
        <label class="flex cursor-pointer items-center justify-between gap-4">
          <span class="text-xs font-semibold text-white">
            🔔 Instant Webhook Lead Pings (Slack / Discord)
            <span class="mt-0.5 block text-[11px] font-normal text-mute">Automatically dispatch new high-intent jobs to configured webhooks as soon as they are detected.</span>
          </span>
          <input id="scanner-webhook-alerts" type="checkbox" class="peer sr-only" />
          <span class="relative h-5 w-9 flex-none rounded-full bg-slate-700 transition-colors duration-200 after:absolute after:left-0.5 after:top-0.5 after:h-4 after:w-4 after:rounded-full after:bg-white after:shadow-md after:transition-transform after:duration-200 peer-checked:bg-brand-500 peer-checked:after:translate-x-4"></span>
        </label>
        <div class="grid gap-3 sm:grid-cols-2 pt-1 border-t border-white/5">
          <label class="block space-y-1.5">
            <span class="text-[11px] font-semibold text-mute">Min Intent Score for Webhooks</span>
            <div class="relative">
              <select id="scanner-min-score-webhook"
                class="w-full cursor-pointer appearance-none rounded-lg border border-edge bg-obsidian px-3 py-1.5 pr-8 text-xs text-ink focus:border-brand-500/60 focus:outline-none">
                <option value="75">75+ (Recommended)</option>
                <option value="80">80+ (High Quality)</option>
                <option value="85">85+ (Exceptional)</option>
                <option value="70">70+ (Inclusive)</option>
              </select>
              <svg class="pointer-events-none absolute right-2.5 top-2.5 h-3 w-3 text-slate-400" fill="none" viewBox="0 0 10 6">
                <path d="M1 1.5L5 4.5L9 1.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </label>
        </div>
      </div>

      <div class="flex flex-wrap items-center gap-3 pt-1">
        <button id="scanner-save"
          class="rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-5 py-2 text-sm font-black text-slate-950 shadow-[0_0_16px_rgba(16,185,129,0.25)] transition-all duration-150 hover:shadow-[0_0_24px_rgba(16,185,129,0.45)] hover:scale-[1.01] active:scale-[.98]">
          ${t("save",e)}
        </button>
        <button id="scanner-test"
          class="rounded-xl border border-edge bg-raised px-4 py-2 text-sm font-semibold text-slate-200 transition-colors duration-150 hover:border-brand-500/40 hover:bg-raised/80 hover:text-white active:scale-[.99]">
          ${t("run_test_scan",e)}
        </button>
        <span id="scanner-status" class="text-xs font-bold text-brand-400"></span>
      </div>
    </section>

    <!-- Agency Lead Inbox & Pipeline (Module D) -->
    <section class="space-y-5 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-edge/60 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("lead_inbox_title",e)}</h2>
            <span class="rounded bg-indigo-500/20 px-1.5 py-0.5 font-mono text-[9px] font-bold text-indigo-400 border border-indigo-500/30">AGENCY CRM</span>
          </div>
          <p class="mt-0.5 text-xs text-mute">${t("lead_inbox_desc",e)}</p>
        </div>
        <div class="flex items-center gap-2">
          <button id="export-csv-btn" class="rounded-xl border border-edge bg-raised px-3 py-1.5 text-xs font-bold text-slate-200 hover:border-brand-500/40 hover:text-white transition-all">
            ${t("export_csv_btn",e)}
          </button>
          <button id="export-json-btn" class="rounded-xl border border-edge bg-raised px-3 py-1.5 text-xs font-bold text-slate-200 hover:border-brand-500/40 hover:text-white transition-all">
            ${t("export_json_btn",e)}
          </button>
          <button id="refresh-pipeline-btn" class="rounded-xl border border-edge bg-raised px-3 py-1.5 text-xs font-bold text-slate-200 hover:border-brand-500/40 hover:text-white transition-all">
            ${t("refresh_leads_btn",e)}
          </button>
        </div>
      </div>

      <!-- Pipeline KPIs -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div class="rounded-xl border border-edge/80 bg-raised/50 p-3">
          <div class="text-[10px] font-bold uppercase text-slate-400">${t("active_claims_count",e)}</div>
          <div id="kpi-active-claims" class="text-lg font-black text-white mt-0.5">0</div>
        </div>
        <div class="rounded-xl border border-edge/80 bg-raised/50 p-3">
          <div class="text-[10px] font-bold uppercase text-slate-400">${t("pipeline_total_value",e)}</div>
          <div id="kpi-pipeline-value" class="text-lg font-black text-emerald-400 mt-0.5">$0</div>
        </div>
        <div class="rounded-xl border border-edge/80 bg-raised/50 p-3">
          <div class="text-[10px] font-bold uppercase text-slate-400">${t("connects_saved_label",e)}</div>
          <div id="kpi-connects-saved" class="text-lg font-black text-sky-400 mt-0.5">0</div>
        </div>
        <div class="rounded-xl border border-edge/80 bg-raised/50 p-3">
          <div class="text-[10px] font-bold uppercase text-slate-400">${t("capital_protected_label",e)}</div>
          <div id="kpi-dollars-saved" class="text-lg font-black text-brand-400 mt-0.5">$0</div>
        </div>
      </div>

      <!-- Filters & Search -->
      <div class="flex flex-wrap items-center gap-3">
        <input id="lead-search" type="text" placeholder="Search by title, client, or BD…" class="flex-1 min-w-[200px] rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-brand-500/60 focus:outline-none" />
        <select id="lead-status-filter" class="rounded-xl border border-edge bg-obsidian px-3 py-2 text-xs text-ink focus:border-brand-500/60 focus:outline-none">
          <option value="all">${t("filter_all_status",e)}</option>
          <option value="drafting">${t("status_drafting",e)}</option>
          <option value="applied">${t("status_applied",e)}</option>
          <option value="viewing">${t("status_viewing",e)}</option>
          <option value="passed">${t("status_passed",e)}</option>
        </select>
      </div>

      <!-- Leads List Container -->
      <div id="leads-container" class="space-y-3 max-h-[420px] overflow-y-auto pr-1"></div>
    </section>

    <!-- Client Blacklist / Whitelist & Notes Manager -->
    <section class="space-y-5 rounded-2xl border border-rose-500/30 bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-edge/60 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-rose-400">
              🛡️ Client Radar: Blacklist & VIP Favorites
            </h2>
            <span class="rounded bg-rose-500/20 px-1.5 py-0.5 font-mono text-[9px] font-bold text-rose-300 border border-rose-500/30">CLIENT RADAR</span>
          </div>
          <p class="mt-0.5 text-xs text-mute">Flag problem clients (scope creep, payment disputes) or mark top partners. Blacklisted clients dim in search results and trigger SKIP in the tactical drawer.</p>
        </div>
        <button id="toggle-add-client-btn" type="button" class="rounded-xl border border-rose-500/40 bg-rose-500/10 px-3 py-1.5 text-xs font-bold text-rose-300 hover:bg-rose-500/20 transition-all">
          + Add Client Record
        </button>
      </div>

      <!-- Add / Edit Client Form (Collapsible) -->
      <div id="client-record-form" class="hidden rounded-xl border border-white/5 bg-obsidian/60 p-4 space-y-3">
        <h3 class="text-xs font-bold text-slate-200">New Client Record</h3>
        <div class="grid gap-3 sm:grid-cols-2">
          <input id="cr-form-name" type="text" placeholder="Client Name (e.g. John Doe)"
            class="rounded-lg border border-edge bg-obsidian px-3 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-rose-500/60 focus:outline-none" />
          <input id="cr-form-company" type="text" placeholder="Company Name (optional)"
            class="rounded-lg border border-edge bg-obsidian px-3 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-rose-500/60 focus:outline-none" />
        </div>
        <div class="grid gap-3 sm:grid-cols-2">
          <select id="cr-form-status" class="rounded-lg border border-edge bg-obsidian px-3 py-2 text-xs text-ink focus:border-rose-500/60 focus:outline-none">
            <option value="blacklisted">⛔ Blacklist (Low intent / Scope creep / Disputed)</option>
            <option value="favorite">⭐ Favorite (VIP Client / High paying / Great partner)</option>
          </select>
          <input id="cr-form-note" type="text" placeholder="Reason or Note (e.g. Scope creep, disputes milestones)"
            class="rounded-lg border border-edge bg-obsidian px-3 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-rose-500/60 focus:outline-none" />
        </div>
        <div class="flex justify-end gap-2">
          <button id="cr-form-cancel" type="button" class="rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs font-semibold text-slate-400 hover:text-white">Cancel</button>
          <button id="cr-form-save" type="button" class="rounded-lg bg-rose-600 px-4 py-1.5 text-xs font-bold text-white hover:bg-rose-500">Save Record</button>
        </div>
      </div>

      <!-- Filters & Search -->
      <div class="flex flex-wrap items-center gap-3">
        <input id="client-record-search" type="text" placeholder="Search by name, company, or notes…"
          class="flex-1 min-w-[200px] rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-rose-500/60 focus:outline-none" />
        <select id="client-record-filter" class="rounded-xl border border-edge bg-obsidian px-3 py-2 text-xs text-ink focus:border-rose-500/60 focus:outline-none">
          <option value="all">All Records</option>
          <option value="blacklisted">⛔ Blacklisted Only</option>
          <option value="favorite">⭐ Favorites Only</option>
        </select>
      </div>

      <!-- Client Records List -->
      <div id="client-records-list" class="space-y-2.5 max-h-[380px] overflow-y-auto pr-1"></div>
    </section>

    <!-- Real-time Webhooks & CRM Sync (Module D) -->
    <section class="space-y-5 rounded-2xl border border-edge bg-panel/90 p-5 shadow-card animate-fade-up">
      <div class="border-b border-edge/60 pb-3">
        <div class="flex items-center gap-2">
          <h2 class="text-[11px] font-extrabold uppercase tracking-widest text-slate-300">${t("webhook_settings_title",e)}</h2>
          <span class="rounded bg-sky-500/20 px-1.5 py-0.5 font-mono text-[9px] font-bold text-sky-400 border border-sky-500/30">SLACK / DISCORD / CRM</span>
        </div>
        <p class="mt-0.5 text-xs text-mute">${t("webhook_settings_desc",e)}</p>
      </div>

      <!-- Slack Endpoint -->
      <div class="space-y-2">
        <div class="flex items-center justify-between">
          <label for="slack-url" class="text-xs font-semibold text-mute">${t("slack_webhook_label",e)}</label>
          <button id="test-slack-btn" type="button" class="text-[11px] font-bold text-sky-400 hover:text-sky-300 transition-colors">
            ${t("test_webhook_btn",e)}
          </button>
        </div>
        <input id="slack-url" type="url" placeholder="https://hooks.slack.com/services/T.../B.../X..." autocomplete="off" spellcheck="false" class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-brand-500/60 focus:outline-none" />
      </div>

      <!-- Discord Endpoint -->
      <div class="space-y-2">
        <div class="flex items-center justify-between">
          <label for="discord-url" class="text-xs font-semibold text-mute">${t("discord_webhook_label",e)}</label>
          <button id="test-discord-btn" type="button" class="text-[11px] font-bold text-indigo-400 hover:text-indigo-300 transition-colors">
            ${t("test_webhook_btn",e)}
          </button>
        </div>
        <input id="discord-url" type="url" placeholder="https://discord.com/api/webhooks/123.../..." autocomplete="off" spellcheck="false" class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-brand-500/60 focus:outline-none" />
      </div>

      <!-- Custom Webhook Endpoint -->
      <div class="space-y-2">
        <div class="flex items-center justify-between">
          <label for="custom-url" class="text-xs font-semibold text-mute">${t("custom_webhook_label",e)}</label>
          <button id="test-custom-btn" type="button" class="text-[11px] font-bold text-teal-400 hover:text-teal-300 transition-colors">
            ${t("test_webhook_btn",e)}
          </button>
        </div>
        <input id="custom-url" type="url" placeholder="https://api.youragency.com/leads/webhook" autocomplete="off" spellcheck="false" class="w-full rounded-xl border border-edge bg-obsidian px-3.5 py-2 text-xs text-ink placeholder:text-slate-600 focus:border-brand-500/60 focus:outline-none" />
      </div>

      <!-- Trigger Rules & Threshold -->
      <div class="grid sm:grid-cols-2 gap-3 pt-2">
        <label class="flex items-center gap-3 cursor-pointer rounded-xl border border-edge/80 bg-raised/40 p-3 hover:border-brand-500/30 transition-colors">
          <input id="notify-claim" type="checkbox" class="h-4 w-4 rounded border-edge text-brand-500 focus:ring-0 focus:outline-none" />
          <span class="text-xs text-slate-200">${t("notify_claim_label",e)}</span>
        </label>
        <label class="flex items-center gap-3 cursor-pointer rounded-xl border border-edge/80 bg-raised/40 p-3 hover:border-brand-500/30 transition-colors">
          <input id="notify-applied" type="checkbox" class="h-4 w-4 rounded border-edge text-brand-500 focus:ring-0 focus:outline-none" />
          <span class="text-xs text-slate-200">${t("notify_applied_label",e)}</span>
        </label>
        <label class="flex items-center gap-3 cursor-pointer rounded-xl border border-edge/80 bg-raised/40 p-3 hover:border-brand-500/30 transition-colors">
          <input id="notify-high-value" type="checkbox" class="h-4 w-4 rounded border-edge text-brand-500 focus:ring-0 focus:outline-none" />
          <span class="text-xs text-slate-200">${t("notify_high_value_label",e)}</span>
        </label>
        <label class="flex items-center gap-3 cursor-pointer rounded-xl border border-edge/80 bg-raised/40 p-3 hover:border-brand-500/30 transition-colors">
          <input id="notify-collision" type="checkbox" class="h-4 w-4 rounded border-edge text-brand-500 focus:ring-0 focus:outline-none" />
          <span class="text-xs text-slate-200">${t("notify_collision_label",e)}</span>
        </label>
      </div>

      <div class="flex items-center justify-between gap-4 pt-1">
        <label class="flex items-center gap-3">
          <span class="text-xs font-semibold text-mute">${t("high_value_threshold_label",e)}</span>
          <input id="high-value-threshold" type="number" min="100" step="100" value="1000" class="w-28 rounded-xl border border-edge bg-obsidian px-3 py-1.5 text-xs text-ink font-mono" />
        </label>

        <div class="flex items-center gap-3">
          <button id="save-webhooks-btn" class="rounded-xl bg-gradient-to-r from-brand-300 via-teal-300 to-brand-500 px-4 py-2 text-xs font-black text-slate-950 shadow hover:shadow-lg transition-all">
            ${t("save",e)}
          </button>
          <span id="webhook-save-status" class="text-xs font-bold text-brand-400"></span>
        </div>
      </div>
    </section>
  `;const k=document.getElementById("lang-save-status");document.querySelectorAll("button[data-option-lang]").forEach(s=>{s.addEventListener("click",async()=>{const o=s.dataset.optionLang;o&&(await Gt(o),k&&(k.textContent=`${t("saved",o)} ✓`),ft())})});const C=document.getElementById("license-status"),K=document.getElementById("buy"),x=document.getElementById("save-status"),Y=document.getElementById("byok-enabled"),z=document.getElementById("provider"),V=document.getElementById("api-key");async function Oe(){if(C)try{const s=await ot();K&&(K.hidden=s),C.textContent=s?t("license_status_pro",e):t("license_status_free",e)}catch{const s=await ct();K&&(K.hidden=s),C.textContent=s?t("license_status_pro",e):t("license_status_unknown",e)}}(Ye=document.getElementById("buy"))==null||Ye.addEventListener("click",()=>{Lt()||C&&(C.textContent="Payment window unavailable — verify the ExtensionPay extension ID in src/monetization/extpay.ts.")}),(Qe=document.getElementById("recheck"))==null||Qe.addEventListener("click",()=>{ot(!0).then(s=>{C&&(C.textContent=s?t("license_status_pro",e):t("license_status_free",e))}).catch(()=>void Oe())}),(Xe=document.getElementById("save"))==null||Xe.addEventListener("click",async()=>{if(!Y||!z||!V||!x)return;const s=Y.checked,o=V.value.trim();if(s&&!o){x.className="text-xs text-red-400",x.textContent="Add an API key or disable the toggle.";return}if(s&&!(await nt()?!0:await at())){Y.checked=!1,x.className="text-xs text-amber-300",x.textContent="Host permission denied — AI polish stays off.";return}await Tt({enabled:s,provider:z.value,apiKey:o}),!o&&s===!1&&(V.value=""),x.className="text-xs font-bold text-brand-400",x.textContent="Saved ✓",window.setTimeout(()=>{x&&(x.textContent="")},1600)}),(Ze=document.getElementById("byok-test"))==null||Ze.addEventListener("click",async()=>{if(!x||!z||!V)return;if(!(await nt()?!0:await at())){x.className="text-xs text-amber-300",x.textContent="Host permission denied — cannot test.";return}let a=V.value.trim();if(a||(a=(await rt()).apiKey),!a){x.className="text-xs text-red-400",x.textContent="Enter an API key first.";return}x.className="text-xs text-mute",x.textContent="Testing connection…";try{const l=await chrome.runtime.sendMessage({type:"BYOK_POLISH",prompt:"Connection verification ping. Respond with: OK",provider:z.value,apiKey:a});if(!l)throw new Error("No response from background worker.");l.ok?(x.className="text-xs font-bold text-brand-400",x.textContent="Connection verified ✓",window.setTimeout(()=>{x&&x.textContent==="Connection verified ✓"&&(x.textContent="")},3200)):(x.className="text-xs text-red-400",x.textContent=`Test failed: ${l.text||"API rejected key"}`)}catch(l){x.className="text-xs text-red-400",x.textContent=`Error: ${l instanceof Error?l.message:String(l)}`}}),(async()=>{const s=await rt();Y&&(Y.checked=s.enabled),z&&(z.value=s.provider),V&&s.apiKey&&(V.placeholder="•••• saved ••••")})();const Q=document.getElementById("scanner-enabled"),X=document.getElementById("scanner-rss"),ue=document.getElementById("scanner-interval"),be=document.getElementById("scanner-min-score"),xe=document.getElementById("scanner-fresh"),Z=document.getElementById("scanner-webhook-alerts"),ee=document.getElementById("scanner-min-score-webhook"),N=document.getElementById("scanner-status");function F(s,o){N&&(N.className=o?"text-xs text-red-400":"text-xs font-bold text-brand-400",N.textContent=s,window.setTimeout(()=>{N&&(N.textContent="")},3200))}(et=document.getElementById("scanner-save"))==null||et.addEventListener("click",async()=>{if(!Q||!X||!ue||!be||!xe)return;const s=Q.checked,o=X.value.trim();if(s&&!o.startsWith("https://")){F("Paste a valid https RSS URL first.",!0);return}if(s&&!(await chrome.permissions.contains({origins:["https://www.upwork.com/*"]})?!0:await chrome.permissions.request({origins:["https://www.upwork.com/*"]}))){Q.checked=!1,F("Upwork host permission denied — scanner stays off.",!0);return}await Ht({enabled:s,rssUrl:o,intervalMin:parseInt(ue.value,10),minScore:parseInt(be.value,10),freshMinutes:parseInt(xe.value,10),webhookAlerts:(Z==null?void 0:Z.checked)??!1,minScoreWebhook:parseInt((ee==null?void 0:ee.value)||"75",10)});try{await chrome.runtime.sendMessage({type:"SCANNER_SETTINGS_UPDATED"})}catch{return}F(s?"Scanner armed ✓":"Scanner off",!1)}),(tt=document.getElementById("scanner-test"))==null||tt.addEventListener("click",async()=>{if(N){N.className="text-xs text-mute",N.textContent="Scanning…";try{const s=await chrome.runtime.sendMessage({type:"SCANNER_SCAN_NOW"});if(!s)throw new Error("no response");s.error?F(`Scan failed: ${s.error}`,!0):s.fetched?F(`Feed OK — ${s.notified} new high-intent job${s.notified===1?"":"s"}`,!1):F("Scanner is disabled — save it enabled first.",!0)}catch{F("No response from background worker.",!0)}}}),(async()=>{const s=await Wt();Q&&(Q.checked=s.enabled),X&&(X.value=s.rssUrl),ue&&(ue.value=String(s.intervalMin)),be&&(be.value=String(s.minScore)),xe&&(xe.value=String(s.freshMinutes)),Z&&(Z.checked=!!s.webhookAlerts),ee&&(ee.value=String(s.minScoreWebhook??75)),X&&!s.rssUrl&&Kt.rssUrl})(),Oe();const me=document.getElementById("account-tier-label"),fe=document.getElementById("account-tier-badge"),j=document.getElementById("cloud-sync-status"),De=document.getElementById("account-user-email"),_e=document.getElementById("team-info-box"),Ve=document.getElementById("team-name-label"),Fe=document.getElementById("team-seats-badge"),He=document.getElementById("team-intel-count"),te=document.getElementById("account-token-input"),Se=document.getElementById("account-connect-btn"),$e=document.getElementById("account-sync-btn"),G=document.getElementById("account-disconnect-btn"),se=document.getElementById("account-status-msg"),We=document.getElementById("metric-collisions-prevented"),Ke=document.getElementById("metric-connects-saved"),ze=document.getElementById("metric-dollars-saved"),ge=document.getElementById("team-pipeline-list"),Ee=document.getElementById("simulate-team-activity-btn"),Ce=document.getElementById("clear-team-pipeline-btn");function A(s,o){se&&(se.className=o?"text-xs text-red-400":"text-xs font-bold text-brand-400",se.textContent=s,window.setTimeout(()=>{se&&(se.textContent="")},3200))}async function H(){const s=await xt(),o=await qt(),a=await os(),l=await qe(),m=await it(),c=await de();if(me&&fe&&(o==="agency"?(me.textContent=t("tier_agency",e),fe.className="inline-flex items-center gap-1.5 rounded-full border border-purple-500/40 bg-purple-500/15 px-2.5 py-1 text-xs font-bold text-purple-300 shadow-[0_0_12px_rgba(168,85,247,0.25)]"):o==="pro_freelancer"?(me.textContent=t("tier_pro",e),fe.className="inline-flex items-center gap-1.5 rounded-full border border-brand-500/40 bg-brand-500/15 px-2.5 py-1 text-xs font-bold text-brand-300 shadow-[0_0_12px_rgba(16,185,129,0.25)]"):(me.textContent=t("tier_free",e),fe.className="inline-flex items-center gap-1.5 rounded-full border border-slate-700 bg-slate-800/80 px-2.5 py-1 text-xs font-bold text-slate-400")),De&&(De.textContent=s.email||s.userId),j)if(a.syncStatus==="synced"){const d=a.lastSyncedAt?new Date(a.lastSyncedAt).toLocaleTimeString():"";j.className="font-bold text-brand-400 flex items-center gap-1.5",j.innerHTML=`<span class="h-2 w-2 rounded-full bg-brand-400 shadow-[0_0_6px_rgba(16,185,129,0.6)]"></span> ${t("sync_status_synced",e)} ${d?`(${d})`:""}`}else a.syncStatus==="syncing"?(j.className="font-bold text-amber-300 flex items-center gap-1.5",j.innerHTML='<span class="h-2 w-2 rounded-full bg-amber-400 animate-ping"></span> Syncing…'):a.syncStatus==="error"?(j.className="font-bold text-red-400 flex items-center gap-1.5",j.innerHTML=`<span class="h-2 w-2 rounded-full bg-red-400"></span> ${a.errorMessage||"Sync error"}`):(j.className="font-bold text-slate-400 flex items-center gap-1.5",j.innerHTML=`<span class="h-2 w-2 rounded-full bg-slate-500"></span> ${t("sync_status_offline",e)}`);_e&&(o==="agency"?(_e.classList.remove("hidden"),Ve&&(Ve.textContent=s.teamName||"Agency Workspace"),Fe&&(Fe.textContent=`${s.activeSeats??1} / ${s.seatLimit??10} seats`),He&&(He.textContent=`${l.length} flagged clients`)):_e.classList.add("hidden")),We&&(We.textContent=String(m.collisionsPrevented)),Ke&&(Ke.textContent=String(m.connectsSaved)),ze&&(ze.textContent=`$${m.dollarsSaved.toFixed(2)}`);const p=document.getElementById("options-share-savings-btn");p&&!p.dataset.bound&&(p.dataset.bound="true",p.addEventListener("click",async()=>{const d=await mt(),b=d*Jt,f=await ct()&&b>=9.99?(b/9.99).toFixed(1):void 0;It({connectsSaved:d,dollarsSaved:b,proRoiMultiplier:f,locale:e},e)})),ge&&(c.length===0?ge.innerHTML=`
          <div class="rounded-xl border border-white/5 bg-obsidian/30 p-4 text-center text-xs text-mute">
            ${t("team_pipeline_empty",e)}
          </div>`:(ge.innerHTML=c.map(d=>{const b=d.status==="applied"?"bg-emerald-500/20 text-emerald-300 border-emerald-500/30":d.status==="drafting"?"bg-purple-500/20 text-purple-300 border-purple-500/30":"bg-slate-500/20 text-slate-300 border-slate-500/30",v=lt(d.updatedAt);return`
              <div class="flex items-center justify-between gap-3 rounded-xl border border-white/5 bg-obsidian/50 p-3 hover:border-purple-500/30 transition-colors">
                <div class="min-w-0 flex-1">
                  <div class="flex items-center gap-2">
                    <span class="rounded px-1.5 py-0.5 text-[9.5px] font-black uppercase font-mono border ${b}">
                      ${d.status}
                    </span>
                    <span class="text-xs font-bold text-white truncate">${S(d.jobTitle)}</span>
                  </div>
                  <div class="text-[11px] text-mute flex items-center gap-2 mt-1">
                    <span>👤 <b class="text-slate-200">${S(d.memberName)}</b></span>
                    <span>•</span>
                    <span>${S(v)}</span>
                    ${d.clientName?`<span>•</span><span>🏢 ${S(d.clientName)}</span>`:""}
                  </div>
                </div>
                <button type="button" data-release-job="${S(d.jobId)}"
                  class="flex-none rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-[10.5px] font-semibold text-slate-400 hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300 transition-colors">
                  ${t("clear_btn",e)}
                </button>
              </div>`}).join(""),ge.querySelectorAll("[data-release-job]").forEach(d=>{d.addEventListener("click",async b=>{b.stopPropagation();const v=d.getAttribute("data-release-job");v&&(await dt(v),await H())})}))),G&&(s.tier!=="free"||s.licenseToken?G.classList.remove("hidden"):G.classList.add("hidden"))}Se==null||Se.addEventListener("click",async()=>{const s=te==null?void 0:te.value.trim();if(!s){A("Enter a token first.",!0);return}const o=await Bt(s);o.success?(te&&(te.value=""),A(`Connected as ${o.profile.tier==="agency"?"Agency Team":"Pro Freelancer"} ✓`,!1),await bt(),await H()):A(o.error||"Connection failed",!0)}),$e==null||$e.addEventListener("click",async()=>{A("Syncing cloud data…",!1);const s=await bt();s.syncStatus==="synced"?A("Cloud sync completed ✓",!1):s.syncStatus==="offline"?A("Offline mode (Upgrade to Pro/Agency for cloud sync)",!1):A(s.errorMessage||"Sync failed",!0),await H()}),G==null||G.addEventListener("click",async()=>{await jt(),A("Account disconnected",!1),await H()}),Ee==null||Ee.addEventListener("click",async()=>{await Pt(),A("Simulated agency team activity seeded ✓",!1),await H()}),Ce==null||Ce.addEventListener("click",async()=>{await Nt(),A("Team pipeline cleared",!1),await H()});const T=g.querySelector("#voice-tone-select"),R=g.querySelector("#voice-custom-instructions"),Le=g.querySelector("#voice-save-status"),Ie=g.querySelector("#tone-sample-input"),B=g.querySelector("#tone-analyze-btn"),ve=g.querySelector("#tone-analysis-badge"),J=g.querySelector("#tone-traits-display"),Ae=g.querySelector("#seed-case-studies-btn"),oe=g.querySelector("#cs-title-input"),ne=g.querySelector("#cs-tags-input"),ae=g.querySelector("#cs-problem-input"),re=g.querySelector("#cs-metrics-input"),ie=g.querySelector("#cs-link-input"),Te=g.querySelector("#add-case-study-btn"),ye=g.querySelector("#case-studies-list"),U=g.querySelector("#template-enabled"),P=g.querySelector("#tmpl-hook"),M=g.querySelector("#tmpl-step1"),q=g.querySelector("#tmpl-step2"),O=g.querySelector("#tmpl-step3"),D=g.querySelector("#tmpl-cta"),Be=g.querySelector("#tmpl-reset-btn"),je=g.querySelector("#tmpl-save-btn"),gt=g.querySelectorAll(".tmpl-var-pill");let Ge=null;[P,M,q,O,D].forEach(s=>{s==null||s.addEventListener("focus",()=>{Ge=s})}),gt.forEach(s=>{s.addEventListener("click",()=>{const o=s.dataset.var;if(!o)return;const a=Ge||P;if(a){const l=a.selectionStart??a.value.length,m=a.selectionEnd??a.value.length,c=a.value.slice(0,l),p=a.value.slice(m);a.value=c+o+p,a.focus(),a.setSelectionRange(l+o.length,l+o.length)}})});function W(s){Le&&(Le.textContent=s,window.setTimeout(()=>{Le.textContent=""},2500))}async function vt(){const s=await we();T&&(T.value=s.tone),R&&(R.value=s.customInstructions||""),s.derivedTraits&&J&&(J.classList.remove("hidden"),J.textContent=`Pace: ${s.derivedTraits.sentenceLength} · Style: ${s.derivedTraits.formality} · Focus: ${s.derivedTraits.focusAngle}`),s.customTemplate&&(U&&(U.checked=s.customTemplate.enabled),P&&(P.value=s.customTemplate.hookFormat||""),M&&(M.value=s.customTemplate.planStep1||""),q&&(q.value=s.customTemplate.planStep2||""),O&&(O.value=s.customTemplate.planStep3||""),D&&(D.value=s.customTemplate.ctaFormat||""))}async function Pe(){const s=await we(),o={enabled:(U==null?void 0:U.checked)??!1,hookFormat:(P==null?void 0:P.value.trim())||void 0,planStep1:(M==null?void 0:M.value.trim())||void 0,planStep2:(q==null?void 0:q.value.trim())||void 0,planStep3:(O==null?void 0:O.value.trim())||void 0,ctaFormat:(D==null?void 0:D.value.trim())||void 0};await Ne({...s,customTemplate:o}),W("Proposal template saved ✓")}U==null||U.addEventListener("change",()=>{Pe()}),je==null||je.addEventListener("click",()=>{Pe()}),Be==null||Be.addEventListener("click",async()=>{P&&(P.value="Hi {{client_name}}, saw you need help with {{subject}}. Having delivered similar projects recently, I can take ownership of this build from day one."),M&&(M.value="Audit existing requirements, technical dependencies, and edge cases."),q&&(q.value="Implement {{subject}} architecture with milestone demos and automated verification."),O&&(O.value="Production deployment, documentation, and zero-downtime handoff."),D&&(D.value="What does your target milestone timeline look like? If you'd like, I can walk you through the technical approach tomorrow."),await Pe()});async function Je(){const s=await we(),o=(T==null?void 0:T.value)||"direct_engineer",a=(R==null?void 0:R.value.trim())||void 0;await Ne({...s,tone:o,customInstructions:a}),W(t("saved",e))}T==null||T.addEventListener("change",()=>{Je()}),R==null||R.addEventListener("blur",()=>{Je()}),B==null||B.addEventListener("click",async()=>{const s=Ie==null?void 0:Ie.value.trim();if(!s){ve&&(ve.textContent="Paste proposal text first.");return}B&&(B.disabled=!0,B.textContent=t("analyzing_tone",e));const o=Rt(s);ve&&(ve.textContent=`Tone: ${o.derivedTone.toUpperCase()} · ${o.metricsFrequency.toUpperCase()} Proof`),J&&(J.classList.remove("hidden"),J.textContent=`Sentences: ${o.detectedSentences} (avg ${o.avgSentenceLength} wps) · Formality: ${o.formality} · Focus: ${o.focusAngle}`),T&&(T.value=o.derivedTone);const a=await we();await Ne({...a,tone:o.derivedTone,sampleText:s.slice(0,1e3),derivedTraits:o}),B&&(B.disabled=!1,B.textContent=`✓ ${t("tone_analyzed_success",e)}`,setTimeout(()=>{B.textContent=t("analyze_tone_btn",e)},2500)),W(t("tone_analyzed_success",e))});async function he(){if(!ye)return;const s=await Ot();if(s.length===0){ye.innerHTML=`
        <div class="rounded-xl border border-dashed border-edge p-6 text-center text-xs text-mute">
          ${t("case_studies_empty",e)}
        </div>`;return}ye.innerHTML=s.map(o=>{const l=(Array.isArray(o.tags)?o.tags:[]).map(m=>`<span class="rounded bg-white/5 border border-white/10 px-1.5 py-0.5 text-[10px] text-slate-300">${S(m)}</span>`).join("");return`
          <div class="flex items-start justify-between gap-3 rounded-xl border border-white/10 bg-obsidian/70 p-3 hover:border-indigo-500/40 transition-colors">
            <div class="space-y-1 min-w-0">
              <div class="flex items-center gap-2 flex-wrap">
                <span class="text-xs font-bold text-white">${S(o.title)}</span>
                ${l}
              </div>
              <p class="text-[11.5px] text-slate-300 leading-snug">
                <span class="text-mute font-semibold">${t("case_study_problem_prefix",e)}</span> ${S(o.problemSolved)}
              </p>
              <p class="text-[11.5px] text-emerald-300 font-medium leading-snug">
                <span class="text-mute font-semibold">${t("case_study_receipts_prefix",e)}</span> ${S(o.metricsOutcome)}
              </p>
              ${o.proofLink?`<a href="${S(o.proofLink)}" target="_blank" rel="noreferrer" class="text-[10.5px] text-indigo-400 hover:underline">${t("case_study_proof_link",e)}</a>`:""}
            </div>
            <button type="button" data-delete-cs="${S(o.id)}"
              class="flex-none rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] font-semibold text-slate-400 hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300 transition-colors"
              title="${t("clear_btn",e)}">
              🗑️
            </button>
          </div>`}).join(""),ye.querySelectorAll("[data-delete-cs]").forEach(o=>{o.addEventListener("click",async()=>{const a=o.getAttribute("data-delete-cs");a&&(await Dt(a),W(t("case_study_deleted",e)),await he())})})}Ae==null||Ae.addEventListener("click",async()=>{await Ut(),W(t("seed_case_studies_success",e)),await he()}),Te==null||Te.addEventListener("click",async()=>{const s=oe==null?void 0:oe.value.trim(),o=ae==null?void 0:ae.value.trim(),a=re==null?void 0:re.value.trim(),l=(ne==null?void 0:ne.value.trim())||"",m=(ie==null?void 0:ie.value.trim())||void 0;if(!s||!o||!a){W("Title, Problem, and Metrics are required.");return}const c=l.split(/[,]+/).map(p=>p.trim()).filter(p=>p.length>0);await Mt({title:s,tags:c.length>0?c:["General"],problemSolved:o,metricsOutcome:a,proofLink:m}),oe&&(oe.value=""),ne&&(ne.value=""),ae&&(ae.value=""),re&&(re.value=""),ie&&(ie.value=""),W(t("case_study_saved",e)),await he()});function yt(){const s=document.querySelector("#sim-budget-slider"),o=document.querySelector("#sim-hirerate-slider"),a=document.querySelector("#sim-proposals-slider"),l=document.querySelector("#sim-budget-val"),m=document.querySelector("#sim-hirerate-val"),c=document.querySelector("#sim-proposals-val"),p=document.querySelector("#sim-strategy-badge"),d=document.querySelector("#sim-recommended-bid"),b=document.querySelector("#sim-roi-ratio"),v=document.querySelector("#sim-win-prob"),f=document.querySelector("#sim-org-prob"),$=document.querySelector("#sim-expected-value"),E=document.querySelector("#sim-breakeven"),h=document.querySelector("#sim-verdict"),_=document.querySelector("#sim-curve-container");if(!s||!o||!a)return;const u=()=>{const y=Number(s.value),r=Number(o.value),i=Number(a.value);l&&(l.textContent=`$${y.toLocaleString()}`),m&&(m.textContent=`${r}%`),c&&(c.textContent=`${i} proposals`);const n=Vt({budget:{type:"fixed",minUsd:y,maxUsd:y},clientHireRatePct:r,clientPaymentVerified:!0,clientTotalSpendUsd:y*3,proposalCount:i}),w=n.strategy==="AGGRESSIVE_TOP_SLOT"?"bid_strategy_aggressive":n.strategy==="TACTICAL_BOOST"?"bid_strategy_tactical":n.strategy==="ORGANIC_SWEET_SPOT"?"bid_strategy_organic":"bid_strategy_skip",L=n.strategy==="AGGRESSIVE_TOP_SLOT"?"bg-amber-500/20 text-amber-300 border-amber-500/40":n.strategy==="TACTICAL_BOOST"?"bg-sky-500/20 text-sky-300 border-sky-500/40":n.strategy==="ORGANIC_SWEET_SPOT"?"bg-emerald-500/20 text-emerald-300 border-emerald-500/40":"bg-red-500/20 text-red-300 border-red-500/40";if(p&&(p.className=`rounded px-2 py-0.5 text-[10px] font-black uppercase font-mono border ${L}`,p.textContent=t(w,e)),d&&(d.textContent=n.recommendedBid>0?`Recommended: ${n.recommendedBid} Connects ($${n.connectsCostUsd.toFixed(2)})`:"Recommended: 0 Connects (Organic)"),b&&(b.textContent=`${n.roiRatio}x Projected ROI`),v&&(v.textContent=`${n.winProbabilityPct}%`),f&&(f.textContent=`${n.organicWinProbabilityPct}%`),$&&($.textContent=`+$${n.expectedValueUsd>0?n.expectedValueUsd.toFixed(0):"0"}`),E&&(E.textContent=`${n.breakEvenWinRatePct}%`),h&&(h.textContent=n.verdictSummary),_){const le=Math.max(...n.curve.map(I=>I.winProbabilityPct),1);_.innerHTML=n.curve.map(I=>{const _t=Math.max(10,Math.round(I.winProbabilityPct/le*100)),St=I.bidConnects===n.recommendedBid,$t=I.bidConnects===0,Et=St?"bg-sky-500 shadow-[0_0_10px_rgba(14,165,233,0.5)]":$t?"bg-emerald-500":"bg-slate-700";return`
              <div class="flex-1 flex flex-col items-center justify-end h-full group relative cursor-pointer"
                   title="${I.bidConnects} Connects: ${I.winProbabilityPct}% win, +$${I.expectedValueUsd} EV">
                <div class="w-full rounded-t transition-all duration-200 ${Et}" style="height:${_t}%"></div>
                <span class="text-[9px] font-mono text-slate-400 mt-1">${I.bidConnects}c</span>
              </div>`}).join("")}};s.addEventListener("input",u),o.addEventListener("input",u),a.addEventListener("input",u),u()}async function ht(){const s=document.getElementById("leads-container"),o=document.getElementById("kpi-active-claims"),a=document.getElementById("kpi-pipeline-value"),l=document.getElementById("kpi-connects-saved"),m=document.getElementById("kpi-dollars-saved"),c=document.getElementById("lead-search"),p=document.getElementById("lead-status-filter"),d=document.getElementById("export-csv-btn"),b=document.getElementById("export-json-btn"),v=document.getElementById("refresh-pipeline-btn");if(!s)return;let f=await de();const $=await it(),E=_=>{const u=_.filter(r=>r.status==="drafting"||r.status==="applied"),y=_.reduce((r,i)=>r+(i.dealValueUsd??500),0);o&&(o.textContent=String(u.length)),a&&(a.textContent=ce(y)),l&&(l.textContent=String($.connectsSaved)),m&&(m.textContent=ce($.dollarsSaved))},h=()=>{const _=(p==null?void 0:p.value)||"all",u=((c==null?void 0:c.value)||"").toLowerCase().trim(),y=f.filter(r=>{if(_!=="all"&&r.status!==_)return!1;if(u){const i=r.jobTitle.toLowerCase().includes(u),n=(r.clientName||"").toLowerCase().includes(u),w=r.memberName.toLowerCase().includes(u);if(!i&&!n&&!w)return!1}return!0});if(E(f),y.length===0){s.innerHTML=`
          <div class="rounded-xl border border-dashed border-edge/80 p-6 text-center text-xs text-mute">
            ${t("team_pipeline_empty",e)}
          </div>`;return}s.innerHTML=y.map(r=>{const i=r.status==="applied",n=r.status==="drafting",w=r.status==="viewing",L=i?"bg-emerald-500/15 border-emerald-500/40 text-emerald-300":n?"bg-amber-500/15 border-amber-500/40 text-amber-300":w?"bg-sky-500/15 border-sky-500/40 text-sky-300":"bg-slate-700/40 border-slate-600 text-slate-400",le=ce(r.dealValueUsd??500),I=lt(r.updatedAt);return`
            <div class="rounded-xl border border-edge bg-raised/50 p-4 transition-all hover:border-brand-500/30">
              <div class="flex flex-wrap items-center justify-between gap-2 mb-2">
                <div class="flex items-center gap-2">
                  <span class="rounded px-2 py-0.5 text-[10px] font-extrabold uppercase border ${L}">
                    ${r.status}
                  </span>
                  <span class="text-xs font-bold text-emerald-400 font-mono">${le}</span>
                </div>
                <div class="text-[11px] text-slate-400">
                  Claimed by <b class="text-slate-200">${S(r.memberName)}</b> (${I})
                </div>
              </div>

              <div class="text-sm font-bold text-white mb-1">
                ${r.jobUrl?`<a href="${r.jobUrl}" target="_blank" class="hover:text-brand-400 hover:underline transition-colors">${S(r.jobTitle)} ↗</a>`:S(r.jobTitle)}
              </div>

              <div class="text-xs text-mute flex flex-wrap items-center gap-3 mb-3">
                ${r.clientName?`<span>Client: <b class="text-slate-300">${S(r.clientName)}</b></span>`:""}
                ${r.hireRatePct!==void 0&&r.hireRatePct!==null?`<span>Hire Rate: <b class="text-slate-300">${r.hireRatePct}%</b></span>`:""}
                ${r.totalSpendUsd!==void 0&&r.totalSpendUsd!==null?`<span>Spend: <b class="text-slate-300">${ce(r.totalSpendUsd)}</b></span>`:""}
              </div>

              <div class="flex flex-wrap items-center gap-2 pt-1 border-t border-edge/40">
                ${r.status!=="applied"?`<button type="button" data-act-applied="${r.jobId}" class="rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 text-[11px] font-bold transition-all">
                        ✓ ${t("status_applied",e)}
                      </button>`:""}
                <button type="button" data-act-release="${r.jobId}" class="rounded-lg border border-edge bg-raised hover:bg-rose-500/20 hover:border-rose-500/40 hover:text-rose-300 px-2.5 py-1 text-[11px] font-bold text-slate-300 transition-all">
                  ✕ ${t("status_passed",e)}
                </button>
                <button type="button" data-act-copy="${r.jobId}" class="rounded-lg border border-edge bg-raised hover:border-brand-500/40 px-2.5 py-1 text-[11px] font-bold text-slate-300 transition-all">
                  📋 Copy Lead
                </button>
              </div>
            </div>`}).join(""),s.querySelectorAll("button[data-act-applied]").forEach(r=>{r.addEventListener("click",async()=>{const i=r.dataset.actApplied;if(!i)return;const n=f.find(w=>w.jobId===i);n&&(await Ft({jobId:n.jobId,jobTitle:n.jobTitle,status:"applied",jobUrl:n.jobUrl,clientName:n.clientName,dealValueUsd:n.dealValueUsd,budget:n.budget,hireRatePct:n.hireRatePct,totalSpendUsd:n.totalSpendUsd,paymentVerified:n.paymentVerified}),f=await de(),h())})}),s.querySelectorAll("button[data-act-release]").forEach(r=>{r.addEventListener("click",async()=>{const i=r.dataset.actRelease;i&&(await dt(i),f=await de(),h())})}),s.querySelectorAll("button[data-act-copy]").forEach(r=>{r.addEventListener("click",async()=>{const i=r.dataset.actCopy;if(!i)return;const n=f.find(L=>L.jobId===i);if(!n)return;const w=`Upwork Lead: ${n.jobTitle}
Value: ${ce(n.dealValueUsd??500)}
Status: ${n.status}
Assigned: ${n.memberName}
URL: ${n.jobUrl||"N/A"}`;await navigator.clipboard.writeText(w),r.textContent="✓ Copied!",setTimeout(()=>{r.textContent="📋 Copy Lead"},1500)})})};c==null||c.addEventListener("input",h),p==null||p.addEventListener("change",h),v==null||v.addEventListener("click",async()=>{f=await de(),h()}),d==null||d.addEventListener("click",()=>{if(f.length===0)return;const _=["Job ID","Job Title","Client Name","Deal Value USD","Status","Assigned BD","Member Email","Upwork URL","Updated At"],u=f.map(n=>[`"${n.jobId}"`,`"${(n.jobTitle||"").replace(/"/g,'""')}"`,`"${(n.clientName||"Anonymous").replace(/"/g,'""')}"`,n.dealValueUsd??500,`"${n.status}"`,`"${(n.memberName||"").replace(/"/g,'""')}"`,`"${n.memberEmail||""}"`,`"${n.jobUrl||""}"`,`"${new Date(n.updatedAt).toISOString()}"`]),y="data:text/csv;charset=utf-8,"+[_.join(","),...u.map(n=>n.join(","))].join(`
`),r=encodeURI(y),i=document.createElement("a");i.setAttribute("href",r),i.setAttribute("download",`gigradar-agency-leads-${new Date().toISOString().slice(0,10)}.csv`),document.body.appendChild(i),i.click(),i.remove()}),b==null||b.addEventListener("click",async()=>{f.length!==0&&(await navigator.clipboard.writeText(JSON.stringify(f,null,2)),b&&(b.textContent="✓ Copied JSON!",setTimeout(()=>{b.textContent=t("export_json_btn",e)},1800)))}),h()}async function wt(){const s=document.getElementById("slack-url"),o=document.getElementById("discord-url"),a=document.getElementById("custom-url"),l=document.getElementById("notify-claim"),m=document.getElementById("notify-applied"),c=document.getElementById("notify-high-value"),p=document.getElementById("notify-collision"),d=document.getElementById("high-value-threshold"),b=document.getElementById("save-webhooks-btn"),v=document.getElementById("webhook-save-status"),f=document.getElementById("test-slack-btn"),$=document.getElementById("test-discord-btn"),E=document.getElementById("test-custom-btn"),h=await Qt();s&&(s.value=h.slackWebhookUrl||""),o&&(o.value=h.discordWebhookUrl||""),a&&(a.value=h.customWebhookUrl||""),l&&(l.checked=h.notifyOnClaim),m&&(m.checked=h.notifyOnApplied),c&&(c.checked=h.notifyOnHighValue),p&&(p.checked=h.notifyOnCollision),d&&(d.value=String(h.highValueThresholdUsd||1e3)),b==null||b.addEventListener("click",async()=>{const u=(s==null?void 0:s.value.trim())||"",y=(o==null?void 0:o.value.trim())||"",r=(a==null?void 0:a.value.trim())||"";await pt([u,y,r]);const i={slackWebhookUrl:u,discordWebhookUrl:y,customWebhookUrl:r,notifyOnClaim:(l==null?void 0:l.checked)??!0,notifyOnApplied:(m==null?void 0:m.checked)??!0,notifyOnHighValue:(c==null?void 0:c.checked)??!0,notifyOnCollision:(p==null?void 0:p.checked)??!0,highValueThresholdUsd:Number(d==null?void 0:d.value)||1e3};await Xt(i),v&&(v.textContent=t("webhook_saved",e),setTimeout(()=>{v.textContent=""},2200))});const _=async(u,y,r)=>{if(!u||!r)return;const i=r.value.trim();if(!i){alert("Please enter a webhook URL first");return}await pt([i]);const n=u.textContent;u.textContent="⏳ Testing...";const w=await Zt(y,i);u.textContent=w.success?"✓ Delivered!":"✕ Failed",setTimeout(()=>{u.textContent=n},2500)};f==null||f.addEventListener("click",()=>{_(f,"slack",s)}),$==null||$.addEventListener("click",()=>{_($,"discord",o)}),E==null||E.addEventListener("click",()=>{_(E,"custom",a)})}async function kt(){const s=document.getElementById("toggle-add-client-btn"),o=document.getElementById("client-record-form"),a=document.getElementById("cr-form-name"),l=document.getElementById("cr-form-company"),m=document.getElementById("cr-form-status"),c=document.getElementById("cr-form-note"),p=document.getElementById("cr-form-cancel"),d=document.getElementById("cr-form-save"),b=document.getElementById("client-record-search"),v=document.getElementById("client-record-filter"),f=document.getElementById("client-records-list");let $=[],E=null;const h=async()=>{$=await ts(),_()},_=()=>{if(!f)return;const u=((b==null?void 0:b.value)||"").toLowerCase().trim(),y=(v==null?void 0:v.value)||"all",r=$.filter(i=>{if(y==="blacklisted"&&i.status!=="blacklisted"||y==="favorite"&&i.status!=="favorite")return!1;if(!u)return!0;const n=i.clientName.toLowerCase().includes(u),w=(i.companyName||"").toLowerCase().includes(u),L=(i.note||"").toLowerCase().includes(u);return n||w||L});if(r.length===0){f.innerHTML=`
          <div class="rounded-xl border border-white/5 bg-obsidian/40 p-6 text-center text-xs text-mute">
            ${$.length===0?"No clients saved yet. Add clients to your blacklist or favorites list using the button above or from the tactical drawer.":"No client records match your search filter."}
          </div>`;return}f.innerHTML=r.map(i=>{const n=i.status==="blacklisted",w=n?"bg-rose-500/20 text-rose-400 border-rose-500/40":"bg-amber-500/20 text-amber-300 border-amber-500/40",L=n?"⛔ Blacklisted":"⭐ Favorite",le=new Date(i.updatedAt||i.createdAt).toLocaleDateString();return`
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-xl border border-white/5 bg-obsidian/60 p-3.5 hover:border-white/10 transition-colors">
            <div class="min-w-0 flex-1 space-y-1">
              <div class="flex items-center gap-2 flex-wrap">
                <span class="rounded px-2 py-0.5 text-[10px] font-black uppercase font-mono border ${w}">
                  ${L}
                </span>
                <span class="font-bold text-white text-xs truncate">${S(i.clientName)}</span>
                ${i.companyName?`<span class="text-slate-400 text-xs font-medium">(${S(i.companyName)})</span>`:""}
              </div>
              <p class="text-xs text-slate-300 leading-relaxed">${i.note?S(i.note):'<span class="text-slate-500 italic">No notes recorded</span>'}</p>
              <div class="text-[10px] text-slate-500 font-mono">Added: ${le}</div>
            </div>
            <div class="flex items-center gap-2 flex-none">
              <button type="button" class="cr-edit-btn rounded-lg border border-white/10 bg-white/5 px-2.5 py-1 text-xs font-semibold text-slate-300 hover:text-white transition-colors" data-id="${i.id}">
                Edit
              </button>
              <button type="button" class="cr-delete-btn rounded-lg border border-red-500/30 bg-red-500/10 px-2.5 py-1 text-xs font-semibold text-red-400 hover:bg-red-500/20 transition-colors" data-id="${i.id}">
                Remove
              </button>
            </div>
          </div>`}).join(""),f.querySelectorAll(".cr-delete-btn").forEach(i=>{i.addEventListener("click",async()=>{const n=i.dataset.id;n&&(await ss(n),await h())})}),f.querySelectorAll(".cr-edit-btn").forEach(i=>{i.addEventListener("click",()=>{const n=i.dataset.id,w=$.find(L=>L.id===n);!w||!o||(E=w.id,a&&(a.value=w.clientName),l&&(l.value=w.companyName||""),m&&(m.value=w.status),c&&(c.value=w.note||""),o.classList.remove("hidden"),a==null||a.focus())})})};s==null||s.addEventListener("click",()=>{o&&(E=null,a&&(a.value=""),l&&(l.value=""),c&&(c.value=""),o.classList.toggle("hidden"),o.classList.contains("hidden")||a==null||a.focus())}),p==null||p.addEventListener("click",()=>{o==null||o.classList.add("hidden"),E=null}),d==null||d.addEventListener("click",async()=>{const u=(a==null?void 0:a.value.trim())||"",y=(l==null?void 0:l.value.trim())||"",r=(m==null?void 0:m.value)||"blacklisted",i=(c==null?void 0:c.value.trim())||"";if(!u&&!y){alert("Please enter a client name or company name.");return}await es({id:E||void 0,clientName:u||y,companyName:y||void 0,status:r,note:i||void 0}),o==null||o.classList.add("hidden"),E=null,await h()}),b==null||b.addEventListener("input",_),v==null||v.addEventListener("change",_),await h()}yt(),ht(),wt(),kt(),vt(),he(),H()}ft();
