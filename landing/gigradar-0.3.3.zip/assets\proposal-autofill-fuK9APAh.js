import{l as q,m as U,d as X,c as Z,a as E,b as tt,p as et,q as ot,g as H,e as nt,f as at,h as A,i as F,j as it,k as rt,n as st,S as V,o as z,r as lt,s as ct}from"./bid-intelligence-Mh-5b8Gv.js";import{e as P}from"./extpay-core-6aOhiK5e.js";import{g as dt,t as h}from"./metrics-CxlbnKT_.js";function C(e,t){let n=e;for(const[o,i]of Object.entries(t))n=n.replace(new RegExp(`\\{\\{\\s*${o}\\s*\\}\\}`,"gi"),i);return n}async function G(e){var f,y,m,x;const t=e.voiceProfile??await q(),n=(f=e.clientName)!=null&&f.trim()?e.clientName.trim():"there";let o=e.caseStudy;o===void 0&&(o=(await U({title:e.jobMeta.title,description:e.jobMeta.descriptionSnippet,techStack:e.techStack})).matched);const i=X(e.jobMeta.title,e.jobMeta.descriptionSnippet,e.techStack),s=Z(e.jobMeta.title),r=s?` for your ${s}`:"";let l="";const c={client_name:n,subject:i.subject,challenge:i.challenge,solution_type:i.solutionType,project_ref:s||i.subject,case_study_title:(o==null?void 0:o.title)||"proven delivery benchmarks",case_study_metrics:(o==null?void 0:o.metricsOutcome)||"",tech_stack:(e.techStack||[]).join(", ")};if((y=t.customTemplate)!=null&&y.enabled&&t.customTemplate.hookFormat)l=C(t.customTemplate.hookFormat,c);else switch(t.tone){case"consultative_partner":l=`Hi ${n}, the biggest challenge with ${i.subject} projects like this is usually ${i.challenge}. Here is how we tackle this cleanly without technical debt or unexpected scope creep.`;break;case"velocity_exec":l=`Hi ${n}, saw your requirements${r}. I specialize in ${i.subject} and can jump in immediately with fast turnaround and daily production updates.`;break;case"custom":t.customInstructions?l=`Hi ${n}, reviewing your requirements${r} — ${t.customInstructions.slice(0,140)}`:l=`Hi ${n}, saw your posting${r}. I specialize in ${i.subject} and have delivered comparable implementations.`;break;case"direct_engineer":default:l=`Hi ${n}, saw you need help with ${i.subject}${r}. Having delivered similar ${i.solutionType} recently, I can take ownership of this build from day one.`;break}let a="";o?a=`Relevant implementation: I previously delivered "${o.title}" (${o.problemSolved}). Outcome: ${o.metricsOutcome}`+(o.proofLink?` [${o.proofLink}]`:"")+".":a=`I've engineered comparable ${i.solutionType} with strict attention to performance, automated testing, and reliable architecture.`,c.case_study=a;let u="Audit existing requirements, technical dependencies, and edge cases.",d=`Implement ${i.subject} architecture with milestone demos and automated verification.`,b="Production deployment, documentation, and zero-downtime handoff.";(m=t.customTemplate)!=null&&m.enabled&&(t.customTemplate.planStep1&&(u=C(t.customTemplate.planStep1,c)),t.customTemplate.planStep2&&(d=C(t.customTemplate.planStep2,c)),t.customTemplate.planStep3&&(b=C(t.customTemplate.planStep3,c)));const p=[u,d,b];let g="What does your target milestone timeline look like? If you'd like, I can walk you through the technical approach or jump on a brief 10-minute scope alignment call tomorrow.";(x=t.customTemplate)!=null&&x.enabled&&t.customTemplate.ctaFormat&&(g=C(t.customTemplate.ctaFormat,c));const w=[l,a,`Proposed roadmap:
1. ${u}
2. ${d}
3. ${b}`,g].join(`

`),k=E(w,t.bannedPhrases);return{hook:E(l,t.bannedPhrases),caseStudyInjection:E(a,t.bannedPhrases),executionPlan:p,closingCta:E(g,t.bannedPhrases),fullText:k,matchedCaseStudyId:o==null?void 0:o.id,matchedCaseStudyTitle:o==null?void 0:o.title}}async function Ft(e){const t=await G(e),n=await tt();if(!n.enabled||!n.apiKey)return{ok:!0,proposal:t,polishedByAi:!1};try{const o=e.voiceProfile??await q(),i=[e.jobMeta.descriptionSnippet.slice(0,600),o.customInstructions?`Voice Guidelines: ${o.customInstructions}`:"",`Voice Tone: ${o.tone}`].filter(Boolean).join(`
`),s=await et(t.hook,{title:e.jobMeta.title,description:i,clientName:e.clientName,techStack:e.techStack});if(s.ok&&s.text)return{ok:!0,proposal:{...t,hook:s.text,fullText:`${s.text}

${t.caseStudyInjection}

Proposed roadmap:
1. ${t.executionPlan[0]}
2. ${t.executionPlan[1]}
3. ${t.executionPlan[2]}

${t.closingCta}`},polishedByAi:!0}}catch{}return{ok:!0,proposal:t,polishedByAi:!1}}const pt="gigradar:intel:",ut=7*864e5,j="gigradar-autofill-toolbar";function $(){try{const e=/~([0-9a-z]{8,})/i.exec(window.location.pathname);return e?z(e[1]):z(window.location.pathname.split("/").filter(Boolean).pop()??"")}catch{return""}}async function L(e){if(!e||!P())return null;try{const t=`${pt}${e}`,o=(await chrome.storage.local.get(t))[t];return!o||typeof o.title!="string"||o.title.length===0||Date.now()-(o.savedAt??0)>ut?null:o}catch{return null}}function v(){var n;const e=document.querySelector("h1")??document.querySelector('[data-test="job-title"]')??document.querySelector("h2"),t=document.querySelector('[data-test="job-description"]')??document.querySelector('[class*="job-description"]');return{title:((n=e==null?void 0:e.textContent)==null?void 0:n.trim().slice(0,200))||"Upwork job",description:((t==null?void 0:t.textContent)??"").trim().slice(0,1200)}}function O(e,t){var o;const n=(o=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value"))==null?void 0:o.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}function bt(e,t,n){const o=e.trim().replace(/\s+/g," "),i=o.length>90?`${o.slice(0,89)}…`:o,s=lt(t,`${t} ${n} ${o}`),r=ct[s[0]??"web"];return`Regarding "${i}" — I've worked extensively on ${r}, and this maps directly to how I would approach your project. I can walk you through relevant specifics on a quick call, start immediately, and keep you updated daily.`}const mt=`
  :host { all: initial; }
  * { box-sizing: border-box; }
  .bar {
    display: flex; align-items: center; gap: 7px; flex-wrap: wrap;
    margin: 8px 0;
    padding: 9px 12px;
    border-radius: 12px;
    background: #0D0F12;
    border: 1px solid rgba(16,185,129,.35);
    box-shadow: 0 4px 18px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.05);
    font-family: Inter, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    width: max-content; max-width: 100%;
  }
  .brand {
    font-weight: 800; font-size: 10.5px; letter-spacing: .04em;
    background: linear-gradient(90deg, #34D399, #10B981);
    -webkit-background-clip: text; background-clip: text; color: transparent;
    margin-right: 2px;
  }
  button {
    font-family: inherit;
    border-radius: 9px; cursor: pointer;
    transition: all .14s ease;
  }
  .autopilot {
    padding: 8px 15px;
    border: 1px solid rgba(129,140,248,.5);
    background: linear-gradient(180deg, #6366F1, #4338CA);
    color: #FFFFFF;
    font-size: 12px; font-weight: 800;
    box-shadow: 0 3px 12px rgba(99,102,241,.32), inset 0 1px 0 rgba(255,255,255,.2);
  }
  .autopilot:hover { filter: brightness(1.1); transform: translateY(-1px); }
  .autopilot:active { transform: scale(.97); }
  .fill {
    padding: 8px 15px;
    border: none;
    background: linear-gradient(180deg, #34D399, #059669);
    color: #0D0F12;
    font-size: 12px; font-weight: 800;
    box-shadow: 0 3px 12px rgba(16,185,129,.28), inset 0 1px 0 rgba(255,255,255,.2);
  }
  .fill:hover { filter: brightness(1.08); transform: translateY(-1px); }
  .fill:active { transform: scale(.97); }
  .variant {
    padding: 6px 11px;
    border: 1px solid #262C37;
    background: #161A22;
    color: #E5E7EB;
    font-size: 11px; font-weight: 700;
  }
  .variant:hover { background: #1D222C; border-color: #3A4250; }
  .status { font-size: 11px; font-weight: 700; color: #6EE7B7; }
`,gt=["display:inline-flex;align-items:center;gap:5px","margin:4px 0 6px;padding:5px 11px","border-radius:999px;border:1px solid rgba(16,185,129,.45)","background:rgba(16,185,129,.09);color:#34D399",'font-family:Inter,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif',"font-size:11px;font-weight:800;cursor:pointer","transition:all .14s ease"].join(";");let S=[];async function ft(){const e=$(),t=await L(e),n=v(),o=t?{title:t.title,description:t.description||n.description}:n,i=(t==null?void 0:t.clientName)??null;return{hooks:H({jobId:e||o.title,title:o.title,description:o.description,clientName:i}),context:o}}function W(){const e=ot(document.body,V.coverLetter);return e instanceof HTMLTextAreaElement?e:document.querySelector('form textarea:not([id*="question" i])')}function M(e,t){const n=W();if(!n){t&&(t.textContent="Cover letter field not found");return}O(n,e.text),n.focus(),t&&(t.textContent=`Option ${e.label} filled ✓`,window.setTimeout(()=>{t.textContent=""},2200))}function T(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const _="gigradar-team-collision-banner";async function xt(e){var i,s;const t=$();if(!t||!P())return;const n=await nt(),o=await at(t);if(n==="agency"&&!o.isClaimed){const r=v(),l=I(),c=A(l);await F({jobId:t,jobTitle:r.title,status:"drafting",jobUrl:window.location.href,budget:l,dealValueUsd:c})}if(o.isClaimed&&!o.isCurrentMember){if(document.getElementById(_))return;const r=document.createElement("div");r.id=_;const l=r.attachShadow({mode:"closed"}),c=document.createElement("style");c.textContent=`
      :host { all: initial; display: block; width: 100%; margin: 12px 0 16px; }
      * { box-sizing: border-box; font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
      .box {
        padding: 14px 18px;
        border-radius: 12px;
        background: rgba(225, 29, 72, 0.12);
        border: 1px solid rgba(244, 63, 94, 0.6);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4), 0 0 18px rgba(244, 63, 94, 0.2);
        color: #F3F4F6;
      }
      .head {
        display: flex; align-items: center; justify-content: space-between;
        font-size: 13px; font-weight: 800; color: #FECDD3; margin-bottom: 6px;
      }
      .desc {
        font-size: 12px; line-height: 1.5; color: #E2E8F0; margin-bottom: 12px;
      }
      .desc b { color: #FFFFFF; font-weight: 700; }
      .btns { display: flex; gap: 8px; flex-wrap: wrap; }
      .btn {
        padding: 7px 14px; border-radius: 8px; font-size: 11.5px; font-weight: 700;
        cursor: pointer; border: none; transition: all 0.15s ease;
      }
      .btn-takeover {
        background: #8B5CF6; color: #FFFFFF;
      }
      .btn-takeover:hover { background: #7C3AED; }
      .btn-applied {
        background: #10B981; color: #07090C; font-weight: 800;
      }
      .btn-applied:hover { background: #059669; color: #FFFFFF; }
    `;const a=o.activity,u=it(a.updatedAt),d=document.createElement("div");d.className="box",d.innerHTML=`
      <div class="head">
        <span>🛑 TEAM COLLISION WARNING</span>
        <span style="font-size:10px;padding:3px 8px;border-radius:6px;background:rgba(244,63,94,0.25);border:1px solid rgba(244,63,94,0.5);">${a.status.toUpperCase()}</span>
      </div>
      <div class="desc">
        Teammate <b>${T(a.memberName)}</b> is already <b>${T(a.status)}</b> on this job (${T(u)}).
        Submitting this proposal will burn 12–16 Connects ($1.80–$2.40) and send duplicate agency proposals.
      </div>
      <div class="btns">
        <button type="button" id="gr-takeover-btn" class="btn btn-takeover">⚡ Take Over (Claim Drafting)</button>
        <button type="button" id="gr-mark-applied-btn" class="btn btn-applied">✅ Mark as Applied</button>
      </div>
    `,(i=d.querySelector("#gr-takeover-btn"))==null||i.addEventListener("click",async()=>{const b=v(),p=I(),g=A(p);await F({jobId:t,jobTitle:b.title,status:"drafting",jobUrl:window.location.href,budget:p,dealValueUsd:g}),r.remove()}),(s=d.querySelector("#gr-mark-applied-btn"))==null||s.addEventListener("click",async()=>{const b=v(),p=I(),g=A(p);await F({jobId:t,jobTitle:b.title,status:"applied",jobUrl:window.location.href,budget:p,dealValueUsd:g}),r.remove()}),l.append(c,d),e.insertAdjacentElement("beforebegin",r)}}const B="gigradar-bid-intelligence-card";function I(){try{const e=document.body.innerText,t=/\$([0-9.]+)\s*-\s*\$([0-9.]+)\s*\/hr/i.exec(e)||/\$([0-9.]+)\s*\/hr/i.exec(e);if(t){const o=parseFloat(t[1]),i=t[2]?parseFloat(t[2]):o;return{type:"hourly",minUsd:o,maxUsd:i}}const n=/(?:budget|fixed[- ]price)[:\s]*\$([0-9,]+)/i.exec(e)||/\$([0-9,]+)\s*(?:fixed[- ]price|budget)/i.exec(e);if(n){const o=parseFloat(n[1].replace(/,/g,""));return{type:"fixed",minUsd:o,maxUsd:o}}}catch{}return null}function ht(){try{const e=document.body.innerText,t=/proposals:\s*([0-9]+)\s*to\s*([0-9]+)/i.exec(e)||/([0-9]+)\+?\s*proposals/i.exec(e);if(t)return parseInt(t[2]||t[1],10)}catch{}return null}function yt(){const e=Array.from(document.querySelectorAll('input[type="number"], input[type="text"], input'));for(const t of e){const n=(t.getAttribute("name")??"").toLowerCase(),o=(t.getAttribute("aria-label")??"").toLowerCase(),i=(t.getAttribute("data-test")??"").toLowerCase(),s=(t.getAttribute("data-qa")??"").toLowerCase(),r=(t.getAttribute("placeholder")??"").toLowerCase();if(n.includes("boost")||n.includes("bid")||o.includes("boost")||o.includes("bid")||i.includes("boost")||i.includes("bid")||s.includes("boost")||s.includes("bid")||r.includes("bid"))return t}return null}function vt(e){var o;const t=yt();if(!t)return!1;const n=(o=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:o.set;return n?n.call(t,String(e)):t.value=String(e),t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0})),t.focus(),!0}async function wt(e){var y;if(document.getElementById(B))return;const t=$(),n=await L(t),o=await dt(),i=(n==null?void 0:n.budget)||I(),s=(n==null?void 0:n.proposalCount)||ht(),r=(n==null?void 0:n.hireRatePct)??null,l=(n==null?void 0:n.paymentVerified)??null,c=(n==null?void 0:n.totalSpendUsd)??null,a=rt({budget:i,clientHireRatePct:r,clientPaymentVerified:l,clientTotalSpendUsd:c,proposalCount:s}),u=document.createElement("div");u.id=B;const d=u.attachShadow({mode:"closed"}),b=document.createElement("style");b.textContent=`
    :host { all: initial; display: block; width: 100%; margin: 10px 0 16px; }
    * { box-sizing: border-box; font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
    .card {
      border-radius: 14px;
      background: #0B0E14;
      border: 1px solid rgba(99, 102, 241, 0.35);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.06);
      padding: 14px 16px;
      color: #E2E8F0;
    }
    .top-bar {
      display: flex; align-items: center; justify-content: space-between; gap: 8px;
      margin-bottom: 12px;
    }
    .brand-title {
      font-size: 11px; font-weight: 800; letter-spacing: .08em; text-transform: uppercase;
      color: #818CF8; display: flex; align-items: center; gap: 6px;
    }
    .badge {
      font-size: 9.5px; font-weight: 800; padding: 3px 8px; border-radius: 6px;
      text-transform: uppercase; letter-spacing: .04em; border: 1px solid;
    }
    .badge-tactical { background: rgba(99, 102, 241, 0.2); color: #A5B4FC; border-color: rgba(99, 102, 241, 0.4); }
    .badge-aggressive { background: rgba(245, 158, 11, 0.2); color: #FCD34D; border-color: rgba(245, 158, 11, 0.4); }
    .badge-organic { background: rgba(16, 185, 129, 0.2); color: #6EE7B7; border-color: rgba(16, 185, 129, 0.4); }
    .badge-skip { background: rgba(239, 68, 68, 0.2); color: #FCA5A5; border-color: rgba(239, 68, 68, 0.4); }

    .stats-grid {
      display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 8px;
      margin-bottom: 12px;
    }
    .tile {
      background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.06);
      border-radius: 10px; padding: 8px 10px;
    }
    .tile-lbl { font-size: 9.5px; font-weight: 700; color: #94A3B8; text-transform: uppercase; }
    .tile-val { font-size: 15px; font-weight: 900; margin-top: 2px; font-family: ui-monospace, monospace; }
    .tile-val small { font-size: 10px; font-weight: 600; color: #94A3B8; }

    .text-emerald { color: #34D399; }
    .text-brand { color: #60A5FA; }
    .text-indigo { color: #A5B4FC; }
    .text-amber { color: #FBBF24; }

    .verdict {
      font-size: 11.5px; line-height: 1.45; color: #CBD5E1;
      background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(255, 255, 255, 0.05);
      border-radius: 8px; padding: 8px 12px; margin-bottom: 12px;
    }

    .curve-row {
      display: flex; gap: 4px; align-items: flex-end; height: 48px; margin-bottom: 12px;
      padding: 0 4px; border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }
    .bar-col {
      flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: flex-end;
      height: 100%; position: relative; cursor: pointer;
    }
    .bar-col:hover .bar-fill { filter: brightness(1.25); }
    .bar-fill {
      width: 100%; border-radius: 3px 3px 0 0; background: #374151;
      transition: height 0.2s ease, background-color 0.2s ease;
    }
    .bar-fill.active { background: #6366F1; box-shadow: 0 0 8px rgba(99, 102, 241, 0.6); }
    .bar-fill.organic { background: #10B981; }
    .bar-lbl { font-size: 8px; color: #64748B; margin-top: 3px; font-family: ui-monospace, monospace; }

    .actions-bar {
      display: flex; align-items: center; justify-content: space-between; gap: 10px;
    }
    .apply-btn {
      padding: 8px 16px; border-radius: 9px; font-size: 12px; font-weight: 800; cursor: pointer;
      border: 1px solid rgba(129, 140, 248, 0.6);
      background: linear-gradient(180deg, #6366F1, #4338CA);
      color: #FFFFFF; box-shadow: 0 3px 12px rgba(99, 102, 241, 0.35);
      transition: all 0.14s ease;
    }
    .apply-btn:hover { filter: brightness(1.1); transform: translateY(-1px); }
    .apply-btn:active { transform: scale(0.97); }
    .organic-badge {
      font-size: 11.5px; font-weight: 700; color: #34D399;
      display: flex; align-items: center; gap: 5px;
    }
    .status-msg { font-size: 11px; font-weight: 700; color: #34D399; }
  `;const p=a.strategy==="AGGRESSIVE_TOP_SLOT"?"badge-aggressive":a.strategy==="TACTICAL_BOOST"?"badge-tactical":a.strategy==="ORGANIC_SWEET_SPOT"?"badge-organic":"badge-skip",g=a.strategy==="AGGRESSIVE_TOP_SLOT"?"bid_strategy_aggressive":a.strategy==="TACTICAL_BOOST"?"bid_strategy_tactical":a.strategy==="ORGANIC_SWEET_SPOT"?"bid_strategy_organic":"bid_strategy_skip",w=Math.max(...a.curve.map(m=>m.winProbabilityPct),1),k=a.curve.map(m=>{const x=Math.max(8,Math.round(m.winProbabilityPct/w*100)),N=m.bidConnects===a.recommendedBid,J=m.bidConnects===0,K=N?"active":J?"organic":"";return`
        <div class="bar-col" title="${m.bidConnects} Connects: ${m.winProbabilityPct}% win, +$${m.expectedValueUsd} EV">
          <div class="bar-fill ${K}" style="height:${x}%"></div>
          <span class="bar-lbl">${m.bidConnects}c</span>
        </div>`}).join(""),f=document.createElement("div");f.className="card",f.innerHTML=`
    <div class="top-bar">
      <div class="brand-title">
        <span>⚡ ${h("bid_intel_title",o)}</span>
      </div>
      <span class="badge ${p}">${h(g,o)}</span>
    </div>

    <div class="stats-grid">
      <div class="tile">
        <div class="tile-lbl">${h("win_probability_label",o)}</div>
        <div class="tile-val text-emerald">${a.winProbabilityPct}% <small>(${a.organicWinProbabilityPct}% org)</small></div>
      </div>
      <div class="tile">
        <div class="tile-lbl">${h("expected_value_label",o)}</div>
        <div class="tile-val text-brand">+${a.expectedValueUsd>0?"$":""}${a.expectedValueUsd.toFixed(0)}</div>
      </div>
      <div class="tile">
        <div class="tile-lbl">${h("optimal_bid_label",o)}</div>
        <div class="tile-val text-indigo">${a.recommendedBid}c <small>($${a.connectsCostUsd.toFixed(2)})</small></div>
      </div>
      <div class="tile">
        <div class="tile-lbl">${h("expected_roi_label",o)}</div>
        <div class="tile-val text-amber">${a.roiRatio}x <small>(BE ${a.breakEvenWinRatePct}%)</small></div>
      </div>
    </div>

    <div class="verdict">${T(a.verdictSummary)}</div>

    <div class="curve-row">
      ${k}
    </div>

    <div class="actions-bar">
      ${a.recommendedBid>0?`<button type="button" id="gr-apply-bid-btn" class="apply-btn">
              ${h("apply_optimal_bid_btn",o)} (${a.recommendedBid} Connects)
             </button>`:`<div class="organic-badge">
              🛡️ ${h("bid_strategy_organic",o)}: 0 Connects
             </div>`}
      <span id="gr-bid-status" class="status-msg"></span>
    </div>
  `,(y=f.querySelector("#gr-apply-bid-btn"))==null||y.addEventListener("click",()=>{const m=vt(a.recommendedBid),x=f.querySelector("#gr-bid-status");x&&(x.textContent=m?h("optimal_bid_applied",o):"Could not find Upwork bid field",setTimeout(()=>{x.textContent=""},2500))}),d.append(b,f),e.insertAdjacentElement("beforebegin",u)}function kt(e){if(document.getElementById(j))return;const t=document.createElement("div");t.id=j;const n=t.attachShadow({mode:"closed"}),o=document.createElement("style");o.textContent=mt;const i=document.createElement("div");i.className="bar";const s=document.createElement("span");s.className="brand",s.textContent="GigRadar";const r=document.createElement("button");r.type="button",r.className="autopilot",r.textContent="🚀 Auto-Fill Full Proposal";const l=document.createElement("button");l.type="button",l.className="fill",l.textContent="⚡ Quick Hook";const c=document.createElement("span");c.className="status",i.append(s,r,l),r.addEventListener("click",async u=>{u.preventDefault(),u.stopPropagation(),r.disabled=!0;const d=r.textContent;r.textContent="Generating…",c.textContent="Matching case studies…";try{const b=$(),p=await L(b),g=v(),w=(p==null?void 0:p.title)||g.title,k=(p==null?void 0:p.description)||g.description,f=(p==null?void 0:p.clientName)??null,y=await U({title:w,description:k}),m=await G({jobMeta:{jobId:b||"upwork-job",title:w,descriptionSnippet:k},clientName:f,caseStudy:y.matched});O(e,m.fullText),e.focus();const x=m.matchedCaseStudyTitle?` [Study: ${m.matchedCaseStudyTitle.slice(0,30)}…]`:"";c.textContent=`✓ Full Proposal Injected!${x}`,window.setTimeout(()=>{c.textContent=""},4e3)}catch{c.textContent="Generation failed"}finally{r.disabled=!1,r.textContent=d}}),l.addEventListener("click",u=>{if(u.preventDefault(),u.stopPropagation(),S.length===0){const d=v();S=H({jobId:$()||d.title,title:d.title,description:d.description,clientName:null})}M(S[0],c)}),(async()=>{const{hooks:u}=await ft();S=u;for(const d of u){const b=document.createElement("button");b.type="button",b.className="variant",b.textContent=`${d.label}`,b.title=`${d.style} — ${d.text.slice(0,80)}…`,b.addEventListener("click",p=>{p.preventDefault(),p.stopPropagation(),M(d,c)}),i.appendChild(b)}})(),i.appendChild(c),n.append(o,i);const a=e.closest('[data-test="cover-letter-section"]')??e.closest("form")??e.parentElement;a==null||a.insertAdjacentElement("beforebegin",t)}function Ct(){var o,i;const e=st(document.body,V.screeningQuestion),{title:t,description:n}=v();for(const s of e){if(s.querySelector("[data-gigradar-answer-btn]"))continue;const r=s.querySelector("textarea");if(!r)continue;const l=s.querySelector('label, h3, h4, [data-test="question-label"]')??s.firstElementChild,c=((o=l==null?void 0:l.textContent)==null?void 0:o.trim())||((i=s.textContent)==null?void 0:i.trim().slice(0,160))||"this question",a=document.createElement("button");a.type="button",a.dataset.gigradarAnswerBtn="",a.setAttribute("style",gt),a.textContent="✨ Auto-Draft Answer",a.addEventListener("click",u=>{u.preventDefault(),u.stopPropagation(),O(r,bt(c,t,n)),a.textContent="✓ Drafted",window.setTimeout(()=>{a.textContent="✨ Auto-Draft Answer"},1800)}),l&&l.parentElement===s?l.insertAdjacentElement("afterend",a):r.insertAdjacentElement("beforebegin",a)}}function $t(){return/\/(nx|ab)\/proposals\/job\//.test(window.location.pathname)}function jt(){D()}function D(){if(!P()){Y.disconnect();return}if(!$t())return;const e=W();if(e&&Et(e)){kt(e);const t=e.closest('[data-test="cover-letter-section"]')??e.closest("form")??e.parentElement;t&&(xt(t),wt(t))}Ct()}function Et(e){const t=e.getBoundingClientRect();return t.width>0&&t.height>0}function St(e,t){let n;return()=>{window.clearTimeout(n),n=window.setTimeout(e,t)}}const Q=St(D,400),Y=new MutationObserver(Q);function R(){Y.observe(document.body,{childList:!0,subtree:!0}),D();let e=window.location.href;window.setInterval(()=>{var t,n,o;window.location.href!==e&&(e=window.location.href,(t=document.getElementById(j))==null||t.remove(),(n=document.getElementById(_))==null||n.remove(),(o=document.getElementById(B))==null||o.remove(),Q())},800)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",R,{once:!0}):R();export{Ft as a,G as g,$t as i,jt as s};
